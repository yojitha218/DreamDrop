const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface StartupRequest {
  dream: string;
  userId: string;
}

interface StartupResponse {
  name: string;
  focus: string;
  targetUsers: string;
  summary: string;
  uniqueness: string;
  strength: 'Strong' | 'Moderate' | 'Weak';
  marketCheck: string;
}

// Alternative AI providers configuration
const AI_PROVIDERS = {
  openai: {
    name: 'OpenAI',
    endpoint: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-3.5-turbo',
    keyEnv: 'OPENAI_API_KEY'
  },
  anthropic: {
    name: 'Anthropic Claude',
    endpoint: 'https://api.anthropic.com/v1/messages',
    model: 'claude-3-haiku-20240307',
    keyEnv: 'ANTHROPIC_API_KEY'
  },
  groq: {
    name: 'Groq',
    endpoint: 'https://api.groq.com/openai/v1/chat/completions',
    model: 'llama3-8b-8192',
    keyEnv: 'GROQ_API_KEY'
  },
  together: {
    name: 'Together AI',
    endpoint: 'https://api.together.xyz/v1/chat/completions',
    model: 'meta-llama/Llama-2-7b-chat-hf',
    keyEnv: 'TOGETHER_API_KEY'
  }
}

async function callOpenAI(apiKey: string, dream: string): Promise<StartupResponse> {
  const response = await fetch(AI_PROVIDERS.openai.endpoint, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: AI_PROVIDERS.openai.model,
      messages: [
        {
          role: 'system',
          content: `You are a startup advisor. Generate a startup concept and return ONLY a JSON object with this exact structure:
          {
            "name": "Creative startup name",
            "focus": "What the startup focuses on",
            "targetUsers": "Target user demographics",
            "summary": "Detailed startup summary (2-3 sentences)",
            "uniqueness": "What makes it unique in the market",
            "strength": "Strong|Moderate|Weak",
            "marketCheck": "Market availability and competition analysis"
          }`
        },
        {
          role: 'user',
          content: `Generate a startup idea based on this dream: "${dream}"`
        }
      ],
      temperature: 0.8,
      max_tokens: 1000
    })
  })

  if (!response.ok) {
    throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`)
  }

  const data = await response.json()
  const content = data.choices[0]?.message?.content
  
  if (!content) {
    throw new Error('No response from OpenAI')
  }

  return JSON.parse(content)
}

async function callAnthropic(apiKey: string, dream: string): Promise<StartupResponse> {
  const response = await fetch(AI_PROVIDERS.anthropic.endpoint, {
    method: 'POST',
    headers: {
      'x-api-key': apiKey,
      'Content-Type': 'application/json',
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: AI_PROVIDERS.anthropic.model,
      max_tokens: 1000,
      messages: [
        {
          role: 'user',
          content: `You are a startup advisor. Generate a startup concept based on this dream: "${dream}"

Return ONLY a JSON object with this exact structure:
{
  "name": "Creative startup name",
  "focus": "What the startup focuses on", 
  "targetUsers": "Target user demographics",
  "summary": "Detailed startup summary (2-3 sentences)",
  "uniqueness": "What makes it unique in the market",
  "strength": "Strong|Moderate|Weak",
  "marketCheck": "Market availability and competition analysis"
}`
        }
      ]
    })
  })

  if (!response.ok) {
    throw new Error(`Anthropic API error: ${response.status} ${response.statusText}`)
  }

  const data = await response.json()
  const content = data.content[0]?.text
  
  if (!content) {
    throw new Error('No response from Anthropic')
  }

  return JSON.parse(content)
}

async function callGroq(apiKey: string, dream: string): Promise<StartupResponse> {
  const response = await fetch(AI_PROVIDERS.groq.endpoint, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: AI_PROVIDERS.groq.model,
      messages: [
        {
          role: 'system',
          content: `You are a startup advisor. Generate a startup concept and return ONLY a JSON object with this exact structure:
          {
            "name": "Creative startup name",
            "focus": "What the startup focuses on",
            "targetUsers": "Target user demographics", 
            "summary": "Detailed startup summary (2-3 sentences)",
            "uniqueness": "What makes it unique in the market",
            "strength": "Strong|Moderate|Weak",
            "marketCheck": "Market availability and competition analysis"
          }`
        },
        {
          role: 'user',
          content: `Generate a startup idea based on this dream: "${dream}"`
        }
      ],
      temperature: 0.8,
      max_tokens: 1000
    })
  })

  if (!response.ok) {
    throw new Error(`Groq API error: ${response.status} ${response.statusText}`)
  }

  const data = await response.json()
  const content = data.choices[0]?.message?.content
  
  if (!content) {
    throw new Error('No response from Groq')
  }

  return JSON.parse(content)
}

async function callTogetherAI(apiKey: string, dream: string): Promise<StartupResponse> {
  const response = await fetch(AI_PROVIDERS.together.endpoint, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: AI_PROVIDERS.together.model,
      messages: [
        {
          role: 'system',
          content: `You are a startup advisor. Generate a startup concept and return ONLY a JSON object with this exact structure:
          {
            "name": "Creative startup name",
            "focus": "What the startup focuses on",
            "targetUsers": "Target user demographics",
            "summary": "Detailed startup summary (2-3 sentences)", 
            "uniqueness": "What makes it unique in the market",
            "strength": "Strong|Moderate|Weak",
            "marketCheck": "Market availability and competition analysis"
          }`
        },
        {
          role: 'user',
          content: `Generate a startup idea based on this dream: "${dream}"`
        }
      ],
      temperature: 0.8,
      max_tokens: 1000
    })
  })

  if (!response.ok) {
    throw new Error(`Together AI error: ${response.status} ${response.statusText}`)
  }

  const data = await response.json()
  const content = data.choices[0]?.message?.content
  
  if (!content) {
    throw new Error('No response from Together AI')
  }

  return JSON.parse(content)
}

// Fallback local generation
function generateLocalStartup(dream: string): StartupResponse {
  const dreamLower = dream.toLowerCase()
  
  // Extract keywords
  const keywords = dreamLower.split(/\s+/).filter(word => 
    word.length > 3 && !['the', 'and', 'for', 'with', 'that', 'this', 'want', 'need'].includes(word)
  )
  
  // Generate based on keywords
  const themes = {
    health: ['health', 'medical', 'fitness', 'wellness', 'therapy'],
    tech: ['ai', 'tech', 'app', 'digital', 'software', 'platform'],
    environment: ['environment', 'green', 'eco', 'sustainable', 'climate'],
    education: ['education', 'learning', 'school', 'student', 'teach'],
    social: ['social', 'community', 'connect', 'people', 'network']
  }
  
  let primaryTheme = 'tech'
  let maxScore = 0
  
  Object.entries(themes).forEach(([theme, themeWords]) => {
    const score = themeWords.filter(word => dreamLower.includes(word)).length
    if (score > maxScore) {
      maxScore = score
      primaryTheme = theme
    }
  })
  
  const nameTemplates = {
    health: ['HealthSync', 'VitalTrack', 'WellnessHub', 'MedConnect', 'CareFlow'],
    tech: ['TechFlow', 'SmartSync', 'DataHub', 'AppForge', 'CodeCraft'],
    environment: ['EcoTrack', 'GreenFlow', 'SustainHub', 'CleanTech', 'EarthSync'],
    education: ['LearnHub', 'StudySync', 'EduFlow', 'KnowledgeBase', 'SkillForge'],
    social: ['ConnectHub', 'SocialSync', 'CommunityFlow', 'NetworkBase', 'PeopleLink']
  }
  
  const name = nameTemplates[primaryTheme as keyof typeof nameTemplates][
    Math.floor(Math.random() * nameTemplates[primaryTheme as keyof typeof nameTemplates].length)
  ]
  
  return {
    name,
    focus: `Innovative ${primaryTheme} solution addressing the core need described in your vision`,
    targetUsers: `${primaryTheme === 'health' ? 'Health-conscious individuals' : 
                   primaryTheme === 'education' ? 'Students and educators' :
                   primaryTheme === 'environment' ? 'Environmentally conscious users' :
                   primaryTheme === 'social' ? 'Community-minded individuals' :
                   'Tech-savvy early adopters'}`,
    summary: `${name} transforms your vision "${dream.substring(0, 100)}..." into a scalable, user-centered platform that delivers real value through innovative ${primaryTheme} solutions.`,
    uniqueness: `First platform to combine your specific approach with modern ${primaryTheme} technology and user experience design`,
    strength: keywords.length > 5 ? 'Strong' : keywords.length > 3 ? 'Moderate' : 'Weak',
    marketCheck: `Growing ${primaryTheme} market with clear demand for innovative solutions like ${name}. Strong opportunity for market entry and growth.`
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { dream, userId }: StartupRequest = await req.json()

    if (!dream || !userId) {
      throw new Error('Missing required fields: dream and userId')
    }

    console.log('🚀 Attempting startup generation with multiple AI providers...')

    // Try each AI provider in order
    const providers = [
      { name: 'OpenAI', call: callOpenAI, key: Deno.env.get('OPENAI_API_KEY') },
      { name: 'Anthropic', call: callAnthropic, key: Deno.env.get('ANTHROPIC_API_KEY') },
      { name: 'Groq', call: callGroq, key: Deno.env.get('GROQ_API_KEY') },
      { name: 'Together AI', call: callTogetherAI, key: Deno.env.get('TOGETHER_API_KEY') }
    ]

    let lastError = null
    let usedProvider = null

    for (const provider of providers) {
      if (!provider.key) {
        console.log(`⏭️ Skipping ${provider.name} - no API key configured`)
        continue
      }

      try {
        console.log(`🔄 Trying ${provider.name}...`)
        const result = await provider.call(provider.key, dream)
        console.log(`✅ Success with ${provider.name}!`)
        usedProvider = provider.name
        
        return new Response(
          JSON.stringify({
            ...result,
            _metadata: {
              provider: provider.name,
              timestamp: new Date().toISOString(),
              fallbackUsed: false
            }
          }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          },
        )
      } catch (error) {
        console.log(`❌ ${provider.name} failed:`, error.message)
        lastError = error
        continue
      }
    }

    // If all AI providers fail, use local generation
    console.log('🔧 All AI providers failed, using local generation fallback...')
    const localResult = generateLocalStartup(dream)
    
    return new Response(
      JSON.stringify({
        ...localResult,
        _metadata: {
          provider: 'Local Fallback',
          timestamp: new Date().toISOString(),
          fallbackUsed: true,
          lastError: lastError?.message || 'All AI providers unavailable'
        }
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )

  } catch (error) {
    console.error('❌ Complete startup generation failure:', error)
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Failed to generate startup idea',
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    )
  }
})