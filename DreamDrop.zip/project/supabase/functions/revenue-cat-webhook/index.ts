import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface RevenueCatWebhook {
  event: {
    type: string;
    app_user_id: string;
    product_id: string;
    period_type: string;
    purchased_at_ms: number;
    expiration_at_ms?: number;
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const webhook: RevenueCatWebhook = await req.json()
    const { event } = webhook

    console.log('RevenueCat webhook received:', event)

    // Handle different event types
    switch (event.type) {
      case 'INITIAL_PURCHASE':
      case 'RENEWAL':
        // Update user to Pro status
        const { error: updateError } = await supabase
          .from('profiles')
          .update({ is_pro: true })
          .eq('id', event.app_user_id)

        if (updateError) {
          throw updateError
        }

        // Create/update subscription record
        const { error: subscriptionError } = await supabase
          .from('subscriptions')
          .upsert({
            user_id: event.app_user_id,
            revenue_cat_customer_id: event.app_user_id,
            product_id: event.product_id,
            status: 'active',
            expires_at: event.expiration_at_ms ? new Date(event.expiration_at_ms) : null
          })

        if (subscriptionError) {
          throw subscriptionError
        }

        break

      case 'CANCELLATION':
      case 'EXPIRATION':
        // Downgrade user from Pro status
        const { error: downgradeError } = await supabase
          .from('profiles')
          .update({ is_pro: false })
          .eq('id', event.app_user_id)

        if (downgradeError) {
          throw downgradeError
        }

        // Update subscription status
        const { error: cancelError } = await supabase
          .from('subscriptions')
          .update({ status: 'cancelled' })
          .eq('user_id', event.app_user_id)

        if (cancelError) {
          throw cancelError
        }

        break
    }

    return new Response(
      JSON.stringify({ success: true }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )

  } catch (error) {
    console.error('RevenueCat webhook error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    )
  }
})