/*
  # Fix Dreams Table RLS Policy

  1. Security Updates
    - Drop existing INSERT policy that uses incorrect uid() function
    - Create new INSERT policy using correct auth.uid() function
    - Ensure authenticated users can insert their own dreams

  2. Policy Changes
    - Replace "Users can insert own dreams" policy with corrected version
    - Use auth.uid() instead of uid() for proper authentication reference
*/

-- Drop the existing INSERT policy that's causing issues
DROP POLICY IF EXISTS "Users can insert own dreams" ON dreams;

-- Create the corrected INSERT policy using auth.uid()
CREATE POLICY "Users can insert own dreams"
  ON dreams
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Also ensure the SELECT policies use auth.uid() consistently
DROP POLICY IF EXISTS "Users can read own dreams" ON dreams;
CREATE POLICY "Users can read own dreams"
  ON dreams
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Update the UPDATE policy as well for consistency
DROP POLICY IF EXISTS "Users can update own dreams" ON dreams;
CREATE POLICY "Users can update own dreams"
  ON dreams
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);