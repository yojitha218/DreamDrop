/*
  # Fix Dreams Table RLS Policies

  1. Security Updates
    - Drop existing RLS policies that may have incorrect syntax
    - Create new RLS policies with correct auth.uid() function
    - Ensure authenticated users can insert, select, and update their own dreams
    - Allow anyone to read published dreams

  2. Policy Details
    - Users can insert their own dreams
    - Users can read their own dreams (published or unpublished)
    - Anyone can read published dreams
    - Users can update their own dreams
*/

-- Drop existing policies to recreate them with correct syntax
DROP POLICY IF EXISTS "Users can insert own dreams" ON dreams;
DROP POLICY IF EXISTS "Users can read own dreams" ON dreams;
DROP POLICY IF EXISTS "Anyone can read published dreams" ON dreams;
DROP POLICY IF EXISTS "Users can update own dreams" ON dreams;

-- Create INSERT policy for authenticated users to insert their own dreams
CREATE POLICY "Users can insert own dreams"
  ON dreams
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create SELECT policy for users to read their own dreams
CREATE POLICY "Users can read own dreams"
  ON dreams
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create SELECT policy for anyone to read published dreams
CREATE POLICY "Anyone can read published dreams"
  ON dreams
  FOR SELECT
  TO authenticated
  USING (is_published = true);

-- Create UPDATE policy for users to update their own dreams
CREATE POLICY "Users can update own dreams"
  ON dreams
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);