import { OPENAI_KEY } from "./secrets";

export default async function handler(req, res) {
  const { dream } = await req.json();

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "gpt-4",
      messages: [
        { role: "system", content: "You are a startup advisor." },
        { role: "user", content: `Give a startup idea for: ${dream}` }
      ]
    })
  });

  const data = await response.json();
  return res.json({ idea: data.choices[0]?.message?.content });
}
