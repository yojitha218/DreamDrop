import { TAVUS_API_KEY } from "./secrets";

export default async function handler(req, res) {
  const { script } = await req.json();

  const response = await fetch("https://api.tavus.io/video", {
    method: "POST",
    headers: {
      "Authorization": TAVUS_API_KEY,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      script,
      template_id: "2d3a531a49"
    })
  });

  const data = await response.json();
  return res.json({ videoURL: data?.video_url });
}
