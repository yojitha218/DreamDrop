import { db } from "@bolt";

export default async function handler(req, res) {
  const { dream, idea, videoURL, userId } = await req.json();

  const result = await db.dreams.create({
    dream,
    idea,
    videoURL,
    userId,
    timestamp: Date.now()
  });

  return res.json({ success: true, id: result.id });
}
