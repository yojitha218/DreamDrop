import { REVENUECAT_KEY } from "./secrets";

export default async function handler(req, res) {
  const { userId } = await req.json();

  const response = await fetch(`https://api.revenuecat.com/v1/subscribers/${userId}`, {
    method: "GET",
    headers: {
      "Authorization": REVENUECAT_KEY,
      "Accept": "application/json"
    }
  });

  const data = await response.json();
  return res.json(data);
}
