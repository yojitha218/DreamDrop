// 🔐 Store all API keys here

export const OPENAI_KEY = "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";
export const TAVUS_API_KEY = "Bearer dfe56afa631a4907a04a7281588bbf62";
export const REVENUECAT_KEY = "Bearer proj2db69fc7";
