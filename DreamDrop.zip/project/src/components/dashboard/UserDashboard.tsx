import React from 'react';
import { Crown, Calendar, Mail, MapPin, Edit3, Star, Infinity, TrendingUp, Users, Award, Heart, Zap, Target, Settings } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const UserDashboard: React.FC = () => {
  const { user, logout } = useAuth();

  if (!user) {
    return (
      <div className="container mx-auto px-4 sm:px-6 py-8 pt-24 sm:pt-32 max-w-4xl">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">Please log in to access your dashboard</h1>
        </div>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getRemainingDreams = () => {
    if (user.isPro) return 'Unlimited';
    return Math.max(0, 10 - user.dreamCount);
  };

  const getPerformanceMetrics = () => {
    if (user.role === 'innovator') {
      return {
        totalViews: user.dreamCount * 234,
        avgRating: 4.7,
        successRate: Math.min(95, 60 + user.dreamCount * 5),
        engagement: Math.min(98, 70 + user.dreamCount * 3)
      };
    } else {
      return {
        totalInvestments: 8,
        avgReturn: 23.5,
        successRate: 87,
        portfolioGrowth: 15.2
      };
    }
  };

  const metrics = getPerformanceMetrics();

  const recentActivity = [
    {
      type: 'dream',
      title: user.role === 'innovator' ? 'New dream posted' : 'Investment opportunity viewed',
      description: user.role === 'innovator' ? 'EcoTrack Pro gained 45 new upvotes' : 'Reviewed HealthTech startup pitch',
      time: '2 hours ago',
      icon: user.role === 'innovator' ? Heart : TrendingUp,
      color: 'text-pink-500'
    },
    {
      type: 'achievement',
      title: user.role === 'innovator' ? 'Milestone reached' : 'Portfolio update',
      description: user.role === 'innovator' ? 'Reached 1000+ total upvotes' : 'Portfolio value increased by 12%',
      time: '1 day ago',
      icon: Award,
      color: 'text-yellow-500'
    },
    {
      type: 'social',
      title: 'Community engagement',
      description: user.role === 'innovator' ? 'Received 5 new followers' : 'Connected with 3 new innovators',
      time: '3 days ago',
      icon: Users,
      color: 'text-blue-500'
    }
  ];

  const quickActions = user.role === 'innovator' 
    ? [
        { title: 'Drop New Dream', description: 'Share your latest startup idea', icon: Zap, color: 'from-pink-500 to-purple-600' },
        { title: 'View Analytics', description: 'Check your dream performance', icon: TrendingUp, color: 'from-blue-500 to-indigo-600' },
        { title: 'Community Feed', description: 'Explore trending dreams', icon: Users, color: 'from-emerald-500 to-teal-600' }
      ]
    : [
        { title: 'Browse Startups', description: 'Discover new opportunities', icon: Target, color: 'from-purple-500 to-indigo-600' },
        { title: 'Portfolio Review', description: 'Analyze your investments', icon: TrendingUp, color: 'from-emerald-500 to-teal-600' },
        { title: 'Market Trends', description: 'Stay updated on trends', icon: Star, color: 'from-amber-500 to-orange-600' }
      ];

  return (
    <div className="container mx-auto px-4 sm:px-6 py-8 pt-24 sm:pt-32 max-w-7xl">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-4">
          Dashboard Overview
        </h1>
        <p className="text-lg text-gray-600">Welcome back, {user.fullName}! Here's your latest activity and insights.</p>
      </div>

      {/* Main Stats Grid */}
      <div className="grid lg:grid-cols-3 gap-8 mb-8">
        {/* Profile Summary Card */}
        <div className="lg:col-span-2 bg-white rounded-3xl shadow-xl p-6 sm:p-8 border border-gray-100">
          <div className="flex flex-col sm:flex-row items-start gap-6">
            {/* Avatar */}
            <div className="relative">
              <div className="w-24 h-24 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-2xl">
                {user.avatar || user.fullName.split(' ').map(n => n[0]).join('')}
              </div>
              {user.isPro && (
                <div className="absolute -top-2 -right-2 bg-yellow-500 p-2 rounded-full">
                  <Crown className="w-4 h-4 text-white" />
                </div>
              )}
            </div>

            {/* User Info */}
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-2xl font-bold text-gray-800">{user.fullName}</h2>
                {user.isPro && (
                  <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center gap-1">
                    <Crown className="w-4 h-4" />
                    Pro
                  </div>
                )}
              </div>
              
              <div className="space-y-2 text-gray-600 mb-4">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>{user.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4" />
                  <span className="capitalize">{user.role}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>Joined: {formatDate(user.createdAt)}</span>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-4">
                {user.role === 'innovator' ? (
                  <>
                    <div className="bg-purple-50 rounded-xl p-3 text-center">
                      <div className="text-2xl font-bold text-purple-600">{user.dreamCount}</div>
                      <div className="text-sm text-purple-700">Dreams</div>
                    </div>
                    <div className="bg-pink-50 rounded-xl p-3 text-center">
                      <div className="text-2xl font-bold text-pink-600">{metrics.totalViews}</div>
                      <div className="text-sm text-pink-700">Views</div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="bg-emerald-50 rounded-xl p-3 text-center">
                      <div className="text-2xl font-bold text-emerald-600">{metrics.totalInvestments}</div>
                      <div className="text-sm text-emerald-700">Investments</div>
                    </div>
                    <div className="bg-blue-50 rounded-xl p-3 text-center">
                      <div className="text-2xl font-bold text-blue-600">{metrics.avgReturn}%</div>
                      <div className="text-sm text-blue-700">Avg Return</div>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Edit Button */}
            <button className="bg-gray-100 hover:bg-gray-200 p-3 rounded-full transition-all duration-200">
              <Edit3 className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Account Status Card */}
        <div className="bg-white rounded-3xl shadow-xl p-6 border border-gray-100">
          <div className="flex items-center gap-4 mb-6">
            <div className={`p-3 rounded-xl ${user.isPro ? 'bg-gradient-to-r from-yellow-400 to-orange-500' : 'bg-gradient-to-r from-gray-400 to-gray-500'}`}>
              <Crown className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-800">Account Status</h3>
          </div>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Plan:</span>
              <span className={`font-bold text-lg ${user.isPro ? 'text-yellow-600' : 'text-gray-600'}`}>
                {user.isPro ? 'Pro' : 'Free'}
              </span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Status:</span>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="font-semibold text-green-600">Active</span>
              </div>
            </div>
            
            {user.role === 'innovator' && (
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Dreams Left:</span>
                <span className="font-bold text-2xl text-gray-800 flex items-center gap-1">
                  {user.isPro ? (
                    <>
                      <Infinity className="w-6 h-6 text-purple-600" />
                      <span className="text-purple-600">∞</span>
                    </>
                  ) : (
                    getRemainingDreams()
                  )}
                </span>
              </div>
            )}
            
            {user.isPro ? (
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <p className="text-yellow-800 text-sm font-semibold">
                  🎉 You have unlimited access to all features!
                </p>
              </div>
            ) : (
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <p className="text-blue-800 text-sm">
                  Upgrade to Pro for unlimited dreams and premium features.
                </p>
                <button className="mt-2 bg-gradient-to-r from-yellow-500 to-orange-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:from-yellow-600 hover:to-orange-700 transition-all duration-200">
                  Upgrade Now
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-gradient-to-r from-purple-500 to-indigo-600 p-3 rounded-xl">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Performance</h3>
              <p className="text-2xl font-bold text-purple-600">{metrics.successRate}%</p>
            </div>
          </div>
          <p className="text-sm text-gray-600">
            {user.role === 'innovator' ? 'Dream success rate' : 'Investment success rate'}
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-3 rounded-xl">
              <Star className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Rating</h3>
              <p className="text-2xl font-bold text-emerald-600">{metrics.avgRating || metrics.avgReturn}%</p>
            </div>
          </div>
          <p className="text-sm text-gray-600">
            {user.role === 'innovator' ? 'Average rating' : 'Average return'}
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-gradient-to-r from-pink-500 to-rose-600 p-3 rounded-xl">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Engagement</h3>
              <p className="text-2xl font-bold text-pink-600">{metrics.engagement || metrics.portfolioGrowth}%</p>
            </div>
          </div>
          <p className="text-sm text-gray-600">
            {user.role === 'innovator' ? 'Community engagement' : 'Portfolio growth'}
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-gradient-to-r from-amber-500 to-orange-600 p-3 rounded-xl">
              <Award className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-800">Rank</h3>
              <p className="text-2xl font-bold text-amber-600">#{Math.max(1, 100 - user.dreamCount * 5)}</p>
            </div>
          </div>
          <p className="text-sm text-gray-600">Global ranking</p>
        </div>
      </div>

      {/* Recent Activity & Quick Actions */}
      <div className="grid lg:grid-cols-2 gap-8 mb-8">
        {/* Recent Activity */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-3 rounded-xl">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-xl font-bold text-gray-800">Recent Activity</h2>
          </div>
          
          <div className="space-y-4">
            {recentActivity.map((activity, index) => {
              const Icon = activity.icon;
              return (
                <div key={index} className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-all duration-200">
                  <div className={`p-2 rounded-lg bg-white shadow-sm ${activity.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-1">{activity.title}</h3>
                    <p className="text-gray-600 text-sm mb-1">{activity.description}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-3 rounded-xl">
              <Target className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-xl font-bold text-gray-800">Quick Actions</h2>
          </div>
          
          <div className="space-y-4">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <button
                  key={index}
                  className={`w-full bg-gradient-to-r ${action.color} text-white p-4 rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-200 text-left flex items-center gap-3`}
                >
                  <Icon className="w-6 h-6" />
                  <div>
                    <div className="font-bold">{action.title}</div>
                    <div className="text-sm opacity-90">{action.description}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <button className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-200 flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Account Settings
        </button>
        
        {!user.isPro && (
          <button className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-yellow-600 hover:to-orange-700 transform hover:scale-105 transition-all duration-200 flex items-center gap-2">
            <Crown className="w-5 h-5" />
            Upgrade to Pro
          </button>
        )}
        
        <button
          onClick={logout}
          className="border-2 border-gray-300 text-gray-700 px-8 py-3 rounded-xl font-semibold hover:border-gray-400 hover:bg-gray-50 transition-all duration-200"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default UserDashboard;