import React, { useState } from 'react';
import { Lightbulb, Mail, Lock, Eye, EyeOff, ArrowLeft, CheckCircle, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { LoginCredentials } from '../../types/auth';

interface LoginPageProps {
  onBackToLanding: () => void;
  onSwitchToSignUp: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onBackToLanding, onSwitchToSignUp }) => {
  const { login, isLoading, error } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState<LoginCredentials>({
    email: '',
    password: '',
    rememberMe: false
  });

  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const errors: Record<string, string> = {};

    if (!formData.email.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!formData.password.trim()) {
      errors.password = 'Password is required';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      await login(formData);
      // Success - user will be redirected by AuthContext
    } catch (error) {
      // Error is handled by context and displayed in UI
      console.error('Login failed:', error);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear validation error when user starts typing
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleDemoLogin = async (role: 'innovator' | 'investor') => {
    const demoCredentials = {
      email: role === 'innovator' ? 'innovator@demo.com' : 'investor@demo.com',
      password: 'demo123',
      rememberMe: false
    };
    
    setFormData(demoCredentials);
    
    // Auto-submit the demo login
    try {
      await login(demoCredentials);
    } catch (error) {
      console.error('Demo login failed:', error);
    }
  };

  const getFieldStatus = (fieldName: string) => {
    if (validationErrors[fieldName]) return 'error';
    if (formData[fieldName as keyof LoginCredentials] && !validationErrors[fieldName]) return 'success';
    return 'default';
  };

  const getFieldBorderColor = (fieldName: string) => {
    const status = getFieldStatus(fieldName);
    switch (status) {
      case 'error': return 'border-red-500 focus:border-red-500';
      case 'success': return 'border-green-500 focus:border-green-500';
      default: return 'border-gray-200 focus:border-purple-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-500 to-indigo-600 flex items-center justify-center p-4 relative">
      {/* Bolt Badge - Fixed position in top right */}
      <div className="fixed top-4 right-4 z-[60] pointer-events-none">
        <div className="bg-white/95 backdrop-blur-sm rounded-full p-2 shadow-lg border border-gray-200">
          <img 
            src="/Screenshot 2025-06-29 212040.png" 
            alt="Powered by Bolt" 
            className="w-12 h-12 rounded-full"
          />
        </div>
      </div>

      <div className="w-full max-w-md">
        {/* Back Button */}
        <button
          onClick={onBackToLanding}
          className="mb-6 flex items-center gap-2 text-white hover:text-white/80 transition-all duration-200"
          disabled={isLoading}
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Home</span>
        </button>

        {/* Login Form */}
        <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl p-8 border border-white/50">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
              <Lightbulb className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Welcome Back</h1>
            <p className="text-gray-600">Sign in to continue your journey</p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              {error}
            </div>
          )}

          {/* Demo Credentials */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
            <h3 className="font-semibold text-blue-800 mb-3">Demo Accounts</h3>
            <div className="space-y-2">
              <button
                onClick={() => handleDemoLogin('innovator')}
                disabled={isLoading}
                className="w-full text-left p-2 rounded-lg bg-white hover:bg-blue-50 transition-all duration-200 border border-blue-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <p className="text-sm text-blue-700 font-semibold">
                  <strong>Innovator:</strong> innovator@demo.com
                </p>
              </button>
              <button
                onClick={() => handleDemoLogin('investor')}
                disabled={isLoading}
                className="w-full text-left p-2 rounded-lg bg-white hover:bg-blue-50 transition-all duration-200 border border-blue-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <p className="text-sm text-blue-700 font-semibold">
                  <strong>Investor:</strong> investor@demo.com
                </p>
              </button>
            </div>
            <p className="text-xs text-blue-600 mt-2">Password: demo123 (or any text)</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className={`w-full pl-10 pr-10 py-3 border-2 rounded-xl focus:outline-none transition-all duration-200 ${getFieldBorderColor('email')}`}
                  placeholder="Enter your email"
                  required
                  disabled={isLoading}
                />
                {getFieldStatus('email') === 'success' && (
                  <CheckCircle className="absolute right-3 top-1/2 transform -translate-y-1/2 text-green-500 w-5 h-5" />
                )}
                {getFieldStatus('email') === 'error' && (
                  <AlertCircle className="absolute right-3 top-1/2 transform -translate-y-1/2 text-red-500 w-5 h-5" />
                )}
              </div>
              {validationErrors.email && (
                <p className="text-red-500 text-sm mt-1">{validationErrors.email}</p>
              )}
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className={`w-full pl-10 pr-12 py-3 border-2 rounded-xl focus:outline-none transition-all duration-200 ${getFieldBorderColor('password')}`}
                  placeholder="Enter your password"
                  required
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  disabled={isLoading}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              {validationErrors.password && (
                <p className="text-red-500 text-sm mt-1">{validationErrors.password}</p>
              )}
            </div>

            {/* Remember Me */}
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  name="rememberMe"
                  checked={formData.rememberMe}
                  onChange={handleInputChange}
                  className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
                  disabled={isLoading}
                />
                <label className="ml-2 text-sm text-gray-700">
                  Remember me
                </label>
              </div>
              <button
                type="button"
                className="text-sm text-purple-600 hover:text-purple-700"
                disabled={isLoading}
              >
                Forgot password?
              </button>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 transition-all duration-200"
            >
              {isLoading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Signing In...
                </div>
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          {/* Switch to Sign Up */}
          <div className="text-center mt-6">
            <p className="text-gray-600">
              Don't have an account?{' '}
              <button
                onClick={onSwitchToSignUp}
                className="text-purple-600 hover:text-purple-700 font-semibold"
                disabled={isLoading}
              >
                Sign Up
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;