import React, { useEffect, useState } from 'react';
import { Sparkles, Star, Heart, Zap, Rocket, Lightbulb } from 'lucide-react';

interface InitialWelcomeProps {
  onComplete: () => void;
}

const InitialWelcome: React.FC<InitialWelcomeProps> = ({ onComplete }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [confettiPieces, setConfettiPieces] = useState<Array<{
    id: number;
    x: number;
    y: number;
    rotation: number;
    color: string;
    size: number;
    delay: number;
    type: 'circle' | 'square' | 'triangle' | 'star';
    velocity: number;
  }>>([]);

  useEffect(() => {
    // Generate confetti pieces
    const pieces = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: -10 - Math.random() * 20,
      rotation: Math.random() * 360,
      color: ['#ec4899', '#8b5cf6', '#f97316', '#eab308', '#ef4444', '#3b82f6'][Math.floor(Math.random() * 6)],
      size: Math.random() * 10 + 4,
      delay: Math.random() * 0.5,
      type: ['circle', 'square', 'triangle', 'star'][Math.floor(Math.random() * 4)] as any,
      velocity: Math.random() * 1.5 + 1
    }));
    setConfettiPieces(pieces);

    // Auto fade out after 2 seconds
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onComplete, 800);
    }, 2000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  const renderConfettiPiece = (piece: typeof confettiPieces[0]) => {
    const baseClasses = "absolute animate-confetti-fall opacity-90";
    const style = {
      left: `${piece.x}%`,
      top: `${piece.y}%`,
      backgroundColor: piece.color,
      width: `${piece.size}px`,
      height: `${piece.size}px`,
      transform: `rotate(${piece.rotation}deg)`,
      animationDelay: `${piece.delay}s`,
      animationDuration: `${2 + piece.velocity}s`,
    };

    switch (piece.type) {
      case 'circle':
        return (
          <div
            key={piece.id}
            className={`${baseClasses} rounded-full`}
            style={style}
          />
        );
      case 'square':
        return (
          <div
            key={piece.id}
            className={`${baseClasses} rounded-lg`}
            style={style}
          />
        );
      case 'triangle':
        return (
          <div
            key={piece.id}
            className={`${baseClasses}`}
            style={{
              ...style,
              width: 0,
              height: 0,
              backgroundColor: 'transparent',
              borderLeft: `${piece.size/2}px solid transparent`,
              borderRight: `${piece.size/2}px solid transparent`,
              borderBottom: `${piece.size}px solid ${piece.color}`,
            }}
          />
        );
      case 'star':
        return (
          <Star
            key={piece.id}
            className={`${baseClasses} text-yellow-400`}
            style={{
              left: `${piece.x}%`,
              top: `${piece.y}%`,
              width: `${piece.size}px`,
              height: `${piece.size}px`,
              animationDelay: `${piece.delay}s`,
              animationDuration: `${2 + piece.velocity}s`,
            }}
            fill="currentColor"
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-pink-400 via-purple-500 to-indigo-600 transition-all duration-800 ${
      isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
    }`}>
      {/* Confetti Layer */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {confettiPieces.map(renderConfettiPiece)}
        
        {/* Floating celebration elements */}
        <div className="absolute top-1/4 left-1/4 animate-float">
          <Sparkles className="w-8 h-8 text-yellow-300 animate-spin" style={{ animationDuration: '3s' }} />
        </div>
        <div className="absolute top-1/3 right-1/4 animate-float" style={{ animationDelay: '0.5s' }}>
          <Heart className="w-6 h-6 text-pink-300 animate-pulse" fill="currentColor" />
        </div>
        <div className="absolute bottom-1/3 left-1/3 animate-float" style={{ animationDelay: '1s' }}>
          <Zap className="w-7 h-7 text-purple-300 animate-bounce" />
        </div>
        <div className="absolute bottom-1/4 right-1/3 animate-float" style={{ animationDelay: '1.5s' }}>
          <Rocket className="w-8 h-8 text-blue-300 animate-pulse" />
        </div>
      </div>

      {/* Welcome Message */}
      <div className={`relative z-10 text-center transform transition-all duration-1000 welcome-container ${
        isVisible ? 'scale-100 opacity-100 translate-y-0' : 'scale-75 opacity-0 translate-y-8'
      }`}>
        <div className="bg-white/20 backdrop-blur-xl rounded-3xl p-12 md:p-16 shadow-2xl border border-white/30 max-w-2xl mx-auto relative overflow-hidden">
          {/* Icon Container */}
          <div className="relative bg-white/20 p-8 rounded-full w-32 h-32 mx-auto mb-8 flex items-center justify-center backdrop-blur-sm shadow-xl animate-celebration-bounce">
            <Lightbulb className="w-16 h-16 text-white animate-pulse" />
            <div className="absolute inset-0 rounded-full bg-white/20 animate-ping"></div>
          </div>

          {/* Emoji */}
          <div className="text-6xl md:text-7xl mb-6 animate-celebration-bounce" style={{ animationDelay: '0.2s' }}>
            🎉
          </div>

          {/* Title */}
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in leading-tight">
            Welcome to DreamDrop!
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-white/95 font-medium animate-fade-in leading-relaxed" style={{ animationDelay: '0.4s' }}>
            Where dreams become startups ✨
          </p>

          {/* Decorative elements */}
          <div className="flex justify-center gap-4 mt-8" style={{ animationDelay: '0.6s' }}>
            <div className="w-3 h-3 bg-white/50 rounded-full animate-pulse"></div>
            <div className="w-3 h-3 bg-white/70 rounded-full animate-pulse" style={{ animationDelay: '0.3s' }}></div>
            <div className="w-3 h-3 bg-white/50 rounded-full animate-pulse" style={{ animationDelay: '0.6s' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InitialWelcome;