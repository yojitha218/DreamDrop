import React, { useState } from 'react';
import { Lightbulb, TrendingUp, Users, Zap, Star, Heart, Sparkles, Rocket } from 'lucide-react';
import WelcomeAnimation from './WelcomeAnimation';

interface LandingPageProps {
  onRoleSelect: (role: 'innovator' | 'investor') => void;
  onSignIn: () => void;
  onSignUp: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onRoleSelect, onSignIn, onSignUp }) => {
  const [showWelcome, setShowWelcome] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'innovator' | 'investor' | null>(null);

  // Actual tools used in the platform
  const tools = [
    { name: 'OpenAI', description: 'AI-powered startup generation', icon: '🤖' },
    { name: 'Tavus', description: 'AI avatar pitch videos', icon: '🎥' },
    { name: 'Pica Labs', description: 'Animated explainer videos', icon: '🎬' },
    { name: 'Supabase', description: 'Database & authentication', icon: '🗄️' },
    { name: 'RevenueCat', description: 'Subscription management', icon: '💳' },
    { name: 'React', description: 'Modern web interface', icon: '⚛️' }
  ];

  const handleRoleClick = (role: 'innovator' | 'investor') => {
    setSelectedRole(role);
    setShowWelcome(true);
  };

  const handleWelcomeComplete = () => {
    setShowWelcome(false);
    if (selectedRole) {
      onRoleSelect(selectedRole);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-500 to-indigo-600 relative overflow-hidden">
      {/* Bolt Badge - Fixed position in top right */}
      <div className="fixed top-4 right-4 z-[60] pointer-events-none">
        <div className="bg-white/95 backdrop-blur-sm rounded-full p-2 shadow-lg border border-gray-200">
          <img 
            src="/Screenshot 2025-06-29 212040.png" 
            alt="Powered by Bolt" 
            className="w-12 h-12 rounded-full"
          />
        </div>
      </div>

      {/* Welcome Animation Overlay */}
      {showWelcome && selectedRole && (
        <WelcomeAnimation 
          userRole={selectedRole} 
          onComplete={handleWelcomeComplete}
        />
      )}

      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 opacity-20 animate-pulse">
          <Heart className="w-8 h-8 text-white" />
        </div>
        <div className="absolute top-40 right-20 opacity-20 animate-bounce">
          <Star className="w-6 h-6 text-white" />
        </div>
        <div className="absolute bottom-20 left-20 opacity-20 animate-pulse">
          <Lightbulb className="w-10 h-10 text-white" />
        </div>
        <div className="absolute top-1/2 right-10 opacity-20 animate-bounce delay-1000">
          <Rocket className="w-8 h-8 text-white" />
        </div>
      </div>

      {/* Hero Section */}
      <div className="container mx-auto px-6 py-12 relative z-10">
        {/* Auth Buttons */}
        <div className="absolute top-6 right-6 flex gap-4">
          <button
            onClick={onSignIn}
            className="bg-white/20 backdrop-blur-sm text-white px-6 py-2 rounded-full font-semibold hover:bg-white/30 transition-all duration-200"
          >
            Sign In
          </button>
          <button
            onClick={onSignUp}
            className="bg-white text-purple-600 px-6 py-2 rounded-full font-semibold hover:bg-gray-50 transition-all duration-200"
          >
            Sign Up
          </button>
        </div>

        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-8">
            <div className="bg-white/20 p-6 rounded-full backdrop-blur-sm">
              <Lightbulb className="w-16 h-16 text-white" />
            </div>
          </div>
          
          <h1 className="text-6xl md:text-8xl font-bold text-white mb-6 tracking-tight">
            DreamDrop
          </h1>
          
          <p className="text-2xl md:text-4xl text-white/90 mb-4 font-light">
            Turn Your Dreams into Startups
          </p>
          
          <p className="text-lg md:text-xl text-white/80 mb-12 max-w-2xl mx-auto">
            AI-powered platform where innovators create and investors discover the next unicorn startups
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center max-w-lg mx-auto">
            <button
              onClick={() => handleRoleClick('innovator')}
              disabled={showWelcome}
              className="w-full sm:w-auto bg-white text-purple-600 px-10 py-5 rounded-full font-bold text-xl hover:bg-gray-50 transform hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-3xl flex items-center justify-center gap-3 group disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Lightbulb className="w-7 h-7 group-hover:animate-pulse" />
              Sign in as Innovator
            </button>
            
            <button
              onClick={() => handleRoleClick('investor')}
              disabled={showWelcome}
              className="w-full sm:w-auto bg-transparent border-3 border-white text-white px-10 py-5 rounded-full font-bold text-xl hover:bg-white hover:text-purple-600 transform hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-3xl flex items-center justify-center gap-3 group disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <TrendingUp className="w-7 h-7 group-hover:animate-pulse" />
              Sign in as Investor
            </button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 text-center hover:bg-white/20 transition-all duration-300 transform hover:-translate-y-2">
            <div className="bg-white/20 p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
              <Zap className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">AI-Powered Generation</h3>
            <p className="text-white/80 text-lg">Transform your ideas into complete startup concepts with advanced AI assistance and market analysis</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 text-center hover:bg-white/20 transition-all duration-300 transform hover:-translate-y-2">
            <div className="bg-white/20 p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
              <Users className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Smart Matching</h3>
            <p className="text-white/80 text-lg">Connect with investors and innovators through our intelligent matching system and vibrant community</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 text-center hover:bg-white/20 transition-all duration-300 transform hover:-translate-y-2">
            <div className="bg-white/20 p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
              <Star className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Video Generation</h3>
            <p className="text-white/80 text-lg">Create professional pitch videos and animated explainers with cutting-edge AI technology</p>
          </div>
        </div>

        {/* Technology Stack */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-8">
            <Sparkles className="w-6 h-6 text-white/70" />
            <p className="text-white/70 text-xl font-medium">Built with Modern Technology</p>
            <Sparkles className="w-6 h-6 text-white/70" />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 max-w-6xl mx-auto">
            {tools.map((tool, index) => (
              <div
                key={tool.name}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 flex flex-col items-center justify-center hover:bg-white/20 transition-all duration-300 transform hover:-translate-y-1 group"
              >
                <div className="text-3xl mb-2 group-hover:scale-110 transition-transform duration-200">
                  {tool.icon}
                </div>
                <span className="text-white font-bold text-sm mb-1">{tool.name}</span>
                <span className="text-white/70 text-xs text-center leading-tight">{tool.description}</span>
              </div>
            ))}
          </div>
          <div className="mt-6">
            <p className="text-white/60 text-sm">
              Powered by industry-leading AI and development tools for the best user experience
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;