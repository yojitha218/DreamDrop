import React, { useState, useEffect } from 'react';
import FloatingNavbar from './FloatingNavbar';
import TopHoverZone from './TopHoverZone';
import NavbarHint from './NavbarHint';
import HomePage from './pages/HomePage';
import DropDreamPage from './pages/DropDreamPage';
import DiscoverPage from './pages/DiscoverPage';
import RankingsPage from './pages/RankingsPage';
import InvestorsPage from './pages/InvestorsPage';
import ProfilePage from './pages/ProfilePage';
import UserDashboard from './dashboard/UserDashboard';
import FunZonePage from './pages/FunZonePage';
import { useAuth } from '../contexts/AuthContext';

export type Page = 'home' | 'drop-dream' | 'discover' | 'rankings' | 'investors' | 'profile' | 'dashboard' | 'fun-zone';

interface MainAppProps {
  userRole: 'innovator' | 'investor';
  onLogout: () => void;
}

const MainApp: React.FC<MainAppProps> = ({ userRole, onLogout }) => {
  const { logout } = useAuth();
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isNavbarVisible, setIsNavbarVisible] = useState(true);
  const [hideTimeout, setHideTimeout] = useState<NodeJS.Timeout | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [hasSeenHint, setHasSeenHint] = useState(false);
  const [initialShowComplete, setInitialShowComplete] = useState(false);
  const [isNavbarHovered, setIsNavbarHovered] = useState(false);

  // Check if mobile and handle initial navbar display
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      
      // On mobile, always show navbar
      if (mobile) {
        setIsNavbarVisible(true);
        setShowHint(false);
        setInitialShowComplete(true);
      } else {
        // On desktop, show navbar initially for 5 seconds
        setIsNavbarVisible(true);
        
        const initialTimer = setTimeout(() => {
          setIsNavbarVisible(false);
          setInitialShowComplete(true);
          
          // Check if user has seen hint before
          const seenHint = localStorage.getItem('dreamdrop-seen-navbar-hint');
          if (!seenHint) {
            // Show hint after navbar disappears
            setTimeout(() => {
              setShowHint(true);
            }, 500);
          }
          setHasSeenHint(!!seenHint);
        }, 5000);

        return () => clearTimeout(initialTimer);
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleShowNavbar = () => {
    // Only allow hover control after initial show is complete
    if (!initialShowComplete && !isMobile) return;
    
    setIsNavbarVisible(true);
    // Clear any existing hide timeout
    if (hideTimeout) {
      clearTimeout(hideTimeout);
      setHideTimeout(null);
    }
  };

  const handleHideNavbar = () => {
    // Don't hide on mobile, during initial show, or when navbar is hovered
    if (isMobile || !initialShowComplete || isNavbarHovered) return;
    
    // Set timeout to hide navbar after 10 seconds (increased from 2 seconds)
    const timeout = setTimeout(() => {
      // Double-check that navbar is not hovered before hiding
      if (!isNavbarHovered) {
        setIsNavbarVisible(false);
      }
    }, 10000); // Changed to 10 seconds
    setHideTimeout(timeout);
  };

  const handleNavbarMouseEnter = () => {
    if (!initialShowComplete && !isMobile) return;
    
    setIsNavbarHovered(true);
    setIsNavbarVisible(true);
    
    // Clear any existing hide timeout when hovering navbar
    if (hideTimeout) {
      clearTimeout(hideTimeout);
      setHideTimeout(null);
    }
  };

  const handleNavbarMouseLeave = () => {
    if (!initialShowComplete && !isMobile) return;
    
    setIsNavbarHovered(false);
    
    // Start hide timer when leaving navbar
    handleHideNavbar();
  };

  const handleHintDismiss = () => {
    setShowHint(false);
    setHasSeenHint(true);
    localStorage.setItem('dreamdrop-seen-navbar-hint', 'true');
  };

  const handleManualShowNavbar = () => {
    handleShowNavbar();
    // Mark hint as seen when user manually triggers navbar
    if (!hasSeenHint) {
      localStorage.setItem('dreamdrop-seen-navbar-hint', 'true');
      setHasSeenHint(true);
    }
  };

  const handleLogout = async () => {
    await logout();
    onLogout();
  };

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (hideTimeout) {
        clearTimeout(hideTimeout);
      }
    };
  }, [hideTimeout]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage userRole={userRole} onPageChange={setCurrentPage} />;
      case 'drop-dream':
        return <DropDreamPage />;
      case 'discover':
        return <DiscoverPage userRole={userRole} />;
      case 'rankings':
        return <RankingsPage />;
      case 'investors':
        return <InvestorsPage userRole={userRole} />;
      case 'profile':
        return <ProfilePage />;
      case 'dashboard':
        return <UserDashboard />;
      case 'fun-zone':
        return <FunZonePage userRole={userRole} />;
      default:
        return <HomePage userRole={userRole} onPageChange={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50">
      {/* Show hint only on desktop for first-time users after initial show */}
      {!isMobile && showHint && !hasSeenHint && initialShowComplete && (
        <NavbarHint 
          onDismiss={handleHintDismiss}
          onManualShow={handleManualShowNavbar}
        />
      )}

      {/* Top hover zone - only on desktop and after initial show */}
      {!isMobile && initialShowComplete && (
        <TopHoverZone 
          onShowNavbar={handleShowNavbar}
          onHideNavbar={handleHideNavbar}
        />
      )}
      
      {/* Floating Navbar */}
      <FloatingNavbar
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        userRole={userRole}
        onLogout={handleLogout}
        isVisible={isNavbarVisible}
        onMouseEnter={handleNavbarMouseEnter}
        onMouseLeave={handleNavbarMouseLeave}
      />
      
      {/* Main Content */}
      <div className="min-h-screen">
        {renderPage()}
      </div>
    </div>
  );
};

export default MainApp;