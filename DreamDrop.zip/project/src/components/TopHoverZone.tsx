import React, { useState } from 'react';

interface TopHoverZoneProps {
  onShowNavbar: () => void;
  onHideNavbar: () => void;
}

const TopHoverZone: React.FC<TopHoverZoneProps> = ({ onShowNavbar, onHideNavbar }) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
    onShowNavbar();
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    // Don't immediately hide when leaving hover zone
    // Let the MainApp component handle the 10-second delay
    onHideNavbar();
  };

  return (
    <>
      {/* Invisible hover zone at the top */}
      <div
        className="fixed top-0 left-0 right-0 z-40 h-20 bg-transparent cursor-pointer"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      />
      
      {/* Visual indicator when hovered */}
      {isHovered && (
        <div className="fixed top-0 left-0 right-0 z-30 h-1 bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 animate-pulse shadow-lg" />
      )}
    </>
  );
};

export default TopHoverZone;