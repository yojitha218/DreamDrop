import React, { useState } from 'react';
import { X, Crown, Check, Zap, Star, Infinity } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const UpgradeModal: React.FC<UpgradeModalProps> = ({ isOpen, onClose }) => {
  const { purchasePro, isLoading } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('monthly');

  const handleUpgrade = async () => {
    try {
      await purchasePro();
      onClose();
    } catch (error) {
      // Error is handled by context
    }
  };

  if (!isOpen) return null;

  const plans = [
    {
      id: 'monthly',
      name: 'Monthly',
      price: '$9.99',
      period: '/month',
      savings: null,
      popular: false
    },
    {
      id: 'yearly',
      name: 'Yearly',
      price: '$59.99',
      period: '/year',
      savings: 'Save 40%',
      popular: true
    }
  ];

  const features = [
    'Unlimited dream submissions',
    'Priority AI processing',
    'Advanced analytics',
    'Premium video generation',
    'Early access to new features',
    'Priority customer support',
    'Custom branding options',
    'Export capabilities'
  ];

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        {/* Modal */}
        <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-6 rounded-t-3xl text-white relative">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-white/20 transition-all duration-200"
            >
              <X className="w-6 h-6" />
            </button>
            
            <div className="text-center">
              <div className="bg-white/20 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <Crown className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold mb-2">Upgrade to Pro</h2>
              <p className="text-white/90 text-lg">Unlock unlimited dreams and premium features</p>
            </div>
          </div>

          <div className="p-6">
            {/* Free Limit Reached Notice */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
              <div className="flex items-center gap-3">
                <div className="bg-amber-500 p-2 rounded-full">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-amber-800">Free Limit Reached!</h3>
                  <p className="text-amber-700 text-sm">You've used all 10 free dream submissions. Upgrade to continue creating!</p>
                </div>
              </div>
            </div>

            {/* Plan Selection */}
            <div className="mb-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4 text-center">Choose Your Plan</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {plans.map((plan) => (
                  <button
                    key={plan.id}
                    onClick={() => setSelectedPlan(plan.id as 'monthly' | 'yearly')}
                    className={`relative p-6 rounded-2xl border-2 transition-all duration-200 text-left ${
                      selectedPlan === plan.id
                        ? 'border-purple-500 bg-purple-50'
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                  >
                    {plan.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <div className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-4 py-1 rounded-full text-sm font-bold">
                          Most Popular
                        </div>
                      </div>
                    )}
                    
                    <div className="text-center">
                      <h4 className="font-bold text-lg text-gray-800 mb-2">{plan.name}</h4>
                      <div className="mb-2">
                        <span className="text-3xl font-bold text-gray-800">{plan.price}</span>
                        <span className="text-gray-600">{plan.period}</span>
                      </div>
                      {plan.savings && (
                        <div className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                          {plan.savings}
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Features */}
            <div className="mb-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Star className="w-6 h-6 text-yellow-500" />
                What's Included
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="bg-green-100 p-1 rounded-full">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Unlimited Dreams Highlight */}
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6 mb-6 text-center">
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Infinity className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Unlimited Dreams</h3>
              <p className="text-gray-600">Never worry about limits again. Create as many startup ideas as you want!</p>
            </div>

            {/* Upgrade Button */}
            <button
              onClick={handleUpgrade}
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-4 rounded-2xl font-bold text-lg hover:from-pink-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 transition-all duration-200 flex items-center justify-center gap-3"
            >
              {isLoading ? (
                <>
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Processing...
                </>
              ) : (
                <>
                  <Crown className="w-6 h-6" />
                  Upgrade with RevenueCat
                </>
              )}
            </button>

            {/* Fine Print */}
            <div className="text-center mt-4">
              <p className="text-xs text-gray-500">
                This is a demo. No actual payment will be processed.
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Cancel anytime. Powered by RevenueCat.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UpgradeModal;