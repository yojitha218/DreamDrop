import React, { useState } from 'react';
import { Home, Lightbulb, Compass, Trophy, TrendingUp, User, LogOut, ArrowLeft, MessageCircle, Menu, X, Bell, Settings, Gamepad2 } from 'lucide-react';
import { Page } from './MainApp';
import MessagingDrawer from './MessagingDrawer';
import NotificationsDrawer from './NotificationsDrawer';

interface FloatingNavbarProps {
  currentPage: Page;
  onPageChange: (page: Page) => void;
  userRole: 'innovator' | 'investor';
  onLogout: () => void;
  isVisible: boolean;
  onMouseEnter: () => void;
  onMouseLeave: () => void;
}

const FloatingNavbar: React.FC<FloatingNavbarProps> = ({ 
  currentPage, 
  onPageChange, 
  userRole, 
  onLogout,
  isVisible,
  onMouseEnter,
  onMouseLeave
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMessagingOpen, setIsMessagingOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const navItems = [
    { id: 'home' as Page, label: 'Home', icon: Home },
    ...(userRole === 'innovator' ? [{ id: 'drop-dream' as Page, label: 'Drop a Dream', icon: Lightbulb }] : []),
    { id: 'discover' as Page, label: userRole === 'investor' ? 'View Startups' : 'Discover', icon: Compass },
    { id: 'rankings' as Page, label: 'Rankings', icon: Trophy },
    ...(userRole === 'investor' ? [{ id: 'investors' as Page, label: 'Investors', icon: TrendingUp }] : []),
    { id: 'fun-zone' as Page, label: 'Fun Zone', icon: Gamepad2 },
  ];

  const handleBackClick = () => {
    if (currentPage === 'home') {
      onLogout();
    } else {
      onPageChange('home');
    }
  };

  return (
    <>
      {/* Bolt Badge - Fixed position in top right */}
      <div className="fixed top-4 right-4 z-[60] pointer-events-none">
        <div className="bg-white/95 backdrop-blur-sm rounded-full p-2 shadow-lg border border-gray-200">
          <img 
            src="/Screenshot 2025-06-29 212040.png" 
            alt="Powered by Bolt" 
            className="w-12 h-12 rounded-full"
          />
        </div>
      </div>

      <nav 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ease-out ${
          isVisible
            ? 'opacity-100 transform translate-y-0 pointer-events-auto' 
            : 'opacity-0 transform -translate-y-full pointer-events-none'
        }`}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
      >
        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/50 p-4 sm:p-6 hover:shadow-3xl transition-all duration-300">
            {/* Main Navigation Container */}
            <div className="flex items-center justify-between gap-4">
              {/* Left Section: Back Arrow + Logo */}
              <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                <button
                  onClick={handleBackClick}
                  className="p-2 sm:p-3 rounded-2xl text-gray-600 hover:text-purple-600 hover:bg-purple-50 transition-all duration-300 transform hover:scale-110 shadow-lg hover:shadow-xl flex-shrink-0"
                  title="Go back"
                >
                  <ArrowLeft className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
                
                <div className="flex items-center gap-2 sm:gap-4 min-w-0">
                  <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-2 sm:p-3 rounded-2xl shadow-lg flex-shrink-0">
                    <Lightbulb className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-xl sm:text-3xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent whitespace-nowrap">
                      DreamDrop
                    </span>
                    <div className="text-xs text-gray-500 font-semibold hidden sm:block">
                      {userRole === 'innovator' ? 'Innovator Dashboard' : 'Investor Portal'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Center Section: Navigation Items (Desktop) */}
              <div className="hidden lg:flex items-center gap-2 xl:gap-3 flex-1 justify-center max-w-4xl overflow-x-auto">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onPageChange(item.id)}
                      className={`flex items-center gap-2 xl:gap-3 px-4 xl:px-6 py-3 rounded-2xl transition-all duration-300 font-semibold whitespace-nowrap shadow-lg hover:shadow-xl transform hover:scale-105 ${
                        currentPage === item.id
                          ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-2xl scale-105'
                          : 'text-gray-700 hover:text-purple-600 bg-white/80 hover:bg-white backdrop-blur-sm'
                      }`}
                    >
                      <Icon className="w-4 h-4 xl:w-5 xl:h-5" />
                      <span className="text-sm xl:text-base font-bold">{item.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Right Section: User Actions */}
              <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
                {/* Role Badge */}
                <div className="hidden sm:flex items-center gap-2 sm:gap-3 bg-gradient-to-r from-pink-100 to-purple-100 px-3 sm:px-4 py-2 rounded-2xl shadow-lg">
                  <div className="w-2 h-2 sm:w-3 sm:h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs sm:text-sm font-bold text-purple-700 capitalize">{userRole}</span>
                </div>
                
                {/* Notifications */}
                <button
                  onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                  className="p-2 sm:p-3 rounded-2xl text-gray-600 hover:text-purple-600 bg-white/80 hover:bg-white transition-all duration-300 transform hover:scale-110 relative shadow-lg hover:shadow-xl"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5 sm:w-6 sm:h-6" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 bg-gradient-to-r from-red-500 to-pink-500 rounded-full flex items-center justify-center">
                    <span className="text-xs text-white font-bold">2</span>
                  </div>
                </button>
                
                {/* Messaging Icon */}
                <button
                  onClick={() => setIsMessagingOpen(!isMessagingOpen)}
                  className="p-2 sm:p-3 rounded-2xl text-gray-600 hover:text-purple-600 bg-white/80 hover:bg-white transition-all duration-300 transform hover:scale-110 relative shadow-lg hover:shadow-xl"
                  title="Messages"
                >
                  <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center">
                    <span className="text-xs text-white font-bold">3</span>
                  </div>
                </button>
                
                {/* Dashboard Button */}
                <button
                  onClick={() => onPageChange('dashboard')}
                  className={`p-2 sm:p-3 rounded-2xl transition-all duration-300 transform hover:scale-110 shadow-lg hover:shadow-xl ${
                    currentPage === 'dashboard'
                      ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-2xl scale-105'
                      : 'text-gray-600 hover:text-purple-600 bg-white/80 hover:bg-white'
                  }`}
                  title="Dashboard"
                >
                  <Settings className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
                
                {/* Profile Button */}
                <button
                  onClick={() => onPageChange('profile')}
                  className={`p-2 sm:p-3 rounded-2xl transition-all duration-300 transform hover:scale-110 shadow-lg hover:shadow-xl ${
                    currentPage === 'profile'
                      ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-2xl scale-105'
                      : 'text-gray-600 hover:text-purple-600 bg-white/80 hover:bg-white'
                  }`}
                >
                  <User className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
                
                {/* Logout Button */}
                <button
                  onClick={onLogout}
                  className="p-2 sm:p-3 rounded-2xl text-gray-600 hover:text-red-600 bg-white/80 hover:bg-red-50 transition-all duration-300 transform hover:scale-110 shadow-lg hover:shadow-xl"
                >
                  <LogOut className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>

                {/* Mobile Menu Toggle */}
                <button
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                  className="lg:hidden p-2 sm:p-3 rounded-2xl text-gray-600 hover:text-purple-600 bg-white/80 hover:bg-white transition-all duration-300 shadow-lg hover:shadow-xl"
                >
                  {isMobileMenuOpen ? <X className="w-5 h-5 sm:w-6 sm:h-6" /> : <Menu className="w-5 h-5 sm:w-6 sm:h-6" />}
                </button>
              </div>
            </div>

            {/* Mobile Navigation Menu */}
            {isMobileMenuOpen && (
              <div className="lg:hidden mt-6 pt-6 border-t border-gray-200 animate-fade-in">
                <div className="grid grid-cols-2 gap-3">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          onPageChange(item.id);
                          setIsMobileMenuOpen(false);
                        }}
                        className={`flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 ${
                          currentPage === item.id
                            ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-2xl'
                            : 'text-gray-700 hover:text-purple-600 bg-white/80 hover:bg-white'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="text-sm">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Messaging Drawer */}
      <MessagingDrawer 
        isOpen={isMessagingOpen} 
        onClose={() => setIsMessagingOpen(false)} 
      />

      {/* Notifications Drawer */}
      <NotificationsDrawer 
        isOpen={isNotificationsOpen} 
        onClose={() => setIsNotificationsOpen(false)} 
      />
    </>
  );
};

export default FloatingNavbar;