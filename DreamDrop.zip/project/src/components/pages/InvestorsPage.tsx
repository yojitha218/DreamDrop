import React, { useState } from 'react';
import { TrendingUp, Star, MessageCircle, Filter, Search, MapPin, Briefcase, DollarSign, Users, Eye, Bookmark, Calendar, Award, Target } from 'lucide-react';

interface TopIdea {
  id: string;
  name: string;
  summary: string;
  category: string;
  funding: string;
  stage: string;
  location: string;
  team: number;
  upvotes: number;
  views: number;
  author: string;
  avatar: string;
  tags: string[];
  isBookmarked: boolean;
  createdAt: string;
  strength: 'Strong' | 'Moderate' | 'Weak';
  marketTraction: string;
}

interface InvestorsPageProps {
  userRole: 'innovator' | 'investor';
}

const InvestorsPage: React.FC<InvestorsPageProps> = ({ userRole }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStage, setSelectedStage] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('trending');
  const [ideas, setIdeas] = useState<TopIdea[]>([
    {
      id: '1',
      name: 'FarmBot Connect',
      summary: 'Revolutionary IoT-enabled smart farming with automated crop monitoring, AI-powered yield optimization, and drone surveillance integration for sustainable agriculture.',
      category: 'AgTech',
      funding: '$2.5M',
      stage: 'Series A',
      location: 'Austin, TX',
      team: 12,
      upvotes: 1247,
      views: 8420,
      author: 'Emma Johnson',
      avatar: 'EJ',
      tags: ['Agriculture', 'IoT', 'AI', 'Sustainability'],
      isBookmarked: false,
      createdAt: '2024-01-15',
      strength: 'Strong',
      marketTraction: 'Growing 40% MoM with 150+ pilot farms'
    },
    {
      id: '2',
      name: 'MoodSpace VR',
      summary: 'Virtual reality therapy platform with AI-guided meditation, stress relief programs, and personalized mental health protocols for modern wellness.',
      category: 'HealthTech',
      funding: '$1.8M',
      stage: 'Seed',
      location: 'San Francisco, CA',
      team: 8,
      upvotes: 1156,
      views: 7890,
      author: 'Mike Rodriguez',
      avatar: 'MR',
      tags: ['VR', 'Mental Health', 'AI', 'Wellness'],
      isBookmarked: true,
      createdAt: '2024-01-20',
      strength: 'Strong',
      marketTraction: '$50K ARR with 500+ active users'
    },
    {
      id: '3',
      name: 'EcoTrack Pro',
      summary: 'AI-powered carbon footprint tracker with gamified community challenges, real-time environmental impact visualization, and corporate sustainability dashboards.',
      category: 'CleanTech',
      funding: '$3.2M',
      stage: 'Series A',
      location: 'Seattle, WA',
      team: 15,
      upvotes: 1089,
      views: 6540,
      author: 'Alex Chen',
      avatar: 'AC',
      tags: ['Environment', 'AI', 'Social Impact', 'Analytics'],
      isBookmarked: false,
      createdAt: '2024-01-25',
      strength: 'Strong',
      marketTraction: '10K+ users, partnerships with 5 Fortune 500s'
    },
    {
      id: '4',
      name: 'StudySync AI',
      summary: 'Personalized learning platform with AI tutors, collaborative study sessions, and adaptive curriculum for students and professionals.',
      category: 'EdTech',
      funding: '$1.2M',
      stage: 'Pre-Series A',
      location: 'Boston, MA',
      team: 6,
      upvotes: 834,
      views: 5210,
      author: 'David Park',
      avatar: 'DP',
      tags: ['EdTech', 'AI', 'Collaboration', 'Learning'],
      isBookmarked: true,
      createdAt: '2024-02-01',
      strength: 'Moderate',
      marketTraction: '2K students, 15% week-over-week growth'
    },
    {
      id: '5',
      name: 'WasteWise',
      summary: 'Smart waste management system for cities with predictive collection routes, IoT sensors, and sustainability analytics for municipal efficiency.',
      category: 'Smart Cities',
      funding: '$4.1M',
      stage: 'Series B',
      location: 'Denver, CO',
      team: 22,
      upvotes: 756,
      views: 4890,
      author: 'Maria Santos',
      avatar: 'MS',
      tags: ['Smart Cities', 'IoT', 'Sustainability', 'Analytics'],
      isBookmarked: false,
      createdAt: '2024-02-05',
      strength: 'Strong',
      marketTraction: 'Deployed in 8 cities, $200K+ MRR'
    },
    {
      id: '6',
      name: 'CraftConnect AR',
      summary: 'Marketplace for handmade goods with augmented reality try-before-buy features, artisan profiles, and sustainable craft promotion.',
      category: 'E-commerce',
      funding: '$900K',
      stage: 'Seed',
      location: 'Portland, OR',
      team: 4,
      upvotes: 689,
      views: 3420,
      author: 'Lisa Zhang',
      avatar: 'LZ',
      tags: ['E-commerce', 'AR', 'Handmade', 'Marketplace'],
      isBookmarked: false,
      createdAt: '2024-02-10',
      strength: 'Moderate',
      marketTraction: '500+ artisans, $25K GMV monthly'
    }
  ]);

  const handleBookmark = (ideaId: string) => {
    setIdeas(ideas.map(idea => 
      idea.id === ideaId 
        ? { ...idea, isBookmarked: !idea.isBookmarked }
        : idea
    ));
  };

  const stages = ['all', 'pre-seed', 'seed', 'pre-series-a', 'series-a', 'series-b'];
  const categories = ['all', 'agtech', 'healthtech', 'cleantech', 'edtech', 'fintech', 'smart-cities', 'e-commerce'];
  const sortOptions = [
    { value: 'trending', label: 'Trending' },
    { value: 'newest', label: 'Newest' },
    { value: 'most-funded', label: 'Most Funded' },
    { value: 'most-viewed', label: 'Most Viewed' }
  ];

  const filteredIdeas = ideas.filter(idea => {
    const matchesSearch = idea.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         idea.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         idea.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStage = selectedStage === 'all' || idea.stage.toLowerCase().replace(' ', '-') === selectedStage;
    const matchesCategory = selectedCategory === 'all' || idea.category.toLowerCase().replace(' ', '-') === selectedCategory;
    
    return matchesSearch && matchesStage && matchesCategory;
  });

  // Sort ideas
  const sortedIdeas = [...filteredIdeas].sort((a, b) => {
    switch (sortBy) {
      case 'trending':
        return b.upvotes - a.upvotes;
      case 'newest':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case 'most-funded':
        const aFunding = parseFloat(a.funding.replace(/[$M]/g, ''));
        const bFunding = parseFloat(b.funding.replace(/[$M]/g, ''));
        return bFunding - aFunding;
      case 'most-viewed':
        return b.views - a.views;
      default:
        return 0;
    }
  });

  const getStageColor = (stage: string) => {
    switch (stage.toLowerCase()) {
      case 'pre-seed': return 'bg-gray-100 text-gray-700 border-gray-200';
      case 'seed': return 'bg-green-100 text-green-700 border-green-200';
      case 'pre-series a': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'series a': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'series b': return 'bg-orange-100 text-orange-700 border-orange-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'Strong': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Moderate': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'Weak': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 py-8 pt-24 sm:pt-32 max-w-7xl">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-6">
          <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-4 rounded-full">
            <TrendingUp className="w-12 h-12 text-white" />
          </div>
        </div>
        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mb-4">
          Investment Opportunities
        </h1>
        <p className="text-xl text-gray-600">
          {userRole === 'investor' 
            ? 'Discover high-potential startups ready for funding'
            : 'Explore trending ideas and connect with the investment community'
          }
        </p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-2xl shadow-lg p-6 mb-8 border border-gray-100">
        <div className="grid md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search opportunities..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-400" />
            <select
              value={selectedStage}
              onChange={(e) => setSelectedStage(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none bg-white"
            >
              <option value="all">All Stages</option>
              {stages.slice(1).map(stage => (
                <option key={stage} value={stage}>
                  {stage.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </option>
              ))}
            </select>
          </div>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none bg-white"
          >
            <option value="all">All Categories</option>
            {categories.slice(1).map(category => (
              <option key={category} value={category}>
                {category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
              </option>
            ))}
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none bg-white"
          >
            {sortOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Results Summary */}
      <div className="flex items-center justify-between mb-6">
        <p className="text-gray-600">
          Showing {sortedIdeas.length} of {ideas.length} opportunities
          {searchTerm && ` for "${searchTerm}"`}
        </p>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <span>Sort by:</span>
          <span className="font-semibold text-emerald-600">
            {sortOptions.find(opt => opt.value === sortBy)?.label}
          </span>
        </div>
      </div>

      {/* Investment Opportunities Grid */}
      <div className="grid gap-8">
        {sortedIdeas.map((idea) => (
          <div key={idea.id} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100">
            <div className="p-6 sm:p-8">
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center text-white font-bold text-xl">
                    {idea.avatar}
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-2xl font-bold text-gray-800">{idea.name}</h3>
                      <span className={`px-3 py-1 rounded-full border font-medium text-sm ${getStrengthColor(idea.strength)}`}>
                        {idea.strength}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-2">Founded by {idea.author}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        <span>{idea.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(idea.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleBookmark(idea.id)}
                    className={`p-2 rounded-full transition-all duration-200 ${
                      idea.isBookmarked
                        ? 'bg-yellow-100 text-yellow-600'
                        : 'bg-gray-100 text-gray-400 hover:bg-yellow-50 hover:text-yellow-500'
                    }`}
                  >
                    <Star className={`w-5 h-5 ${idea.isBookmarked ? 'fill-current' : ''}`} />
                  </button>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-emerald-600 mb-1">
                      <TrendingUp className="w-4 h-4" />
                      <span className="font-bold">{idea.upvotes.toLocaleString()}</span>
                    </div>
                    <span className="text-xs text-gray-500">upvotes</span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <p className="text-gray-700 text-lg leading-relaxed mb-6">{idea.summary}</p>

              {/* Market Traction */}
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 p-4 rounded-xl mb-6 border border-emerald-100">
                <h4 className="font-semibold text-emerald-800 mb-2 flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Market Traction:
                </h4>
                <p className="text-emerald-700">{idea.marketTraction}</p>
              </div>

              {/* Key Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-gradient-to-r from-emerald-50 to-teal-50 p-4 rounded-xl text-center border border-emerald-100">
                  <DollarSign className="w-6 h-6 text-emerald-600 mx-auto mb-2" />
                  <div className="font-bold text-gray-800">{idea.funding}</div>
                  <div className="text-sm text-gray-600">Seeking</div>
                </div>
                
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-xl text-center border border-blue-100">
                  <Briefcase className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                  <div className={`font-bold px-2 py-1 rounded-full text-sm border ${getStageColor(idea.stage)}`}>
                    {idea.stage}
                  </div>
                  <div className="text-sm text-gray-600 mt-1">Stage</div>
                </div>
                
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-xl text-center border border-purple-100">
                  <Users className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                  <div className="font-bold text-gray-800">{idea.team}</div>
                  <div className="text-sm text-gray-600">Team Size</div>
                </div>
                
                <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-4 rounded-xl text-center border border-amber-100">
                  <Eye className="w-6 h-6 text-amber-600 mx-auto mb-2" />
                  <div className="font-bold text-gray-800">{idea.views.toLocaleString()}</div>
                  <div className="text-sm text-gray-600">Views</div>
                </div>
              </div>

              {/* Pitch Video (Only for Investors) */}
              {userRole === 'investor' && (
                <div className="mb-6">
                  <div className="bg-gray-900 rounded-xl p-8 text-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/20 to-teal-500/20"></div>
                    <div className="relative z-10">
                      <div className="bg-white/20 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                        <Users className="w-8 h-8 text-white" />
                      </div>
                      <p className="text-white font-semibold mb-2">🎥 AI-Generated Pitch Video</p>
                      <p className="text-white/80 text-sm">4-minute investor presentation • Powered by Tavus</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-6">
                <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                  {idea.category}
                </span>
                {idea.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-700 px-3 py-1 rounded-full text-sm font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between pt-6 border-t border-gray-100">
                <div className="flex items-center gap-4">
                  <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-600 hover:bg-emerald-50 hover:text-emerald-600 transition-all duration-200">
                    <Eye className="w-5 h-5" />
                    <span className="font-medium">View Details</span>
                  </button>
                  
                  <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition-all duration-200">
                    <Award className="w-5 h-5" />
                    <span className="font-medium">Due Diligence</span>
                  </button>
                </div>
                
                {/* Message Innovator Button - Only for Investors */}
                {userRole === 'investor' && (
                  <button className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-full font-semibold hover:from-emerald-600 hover:to-teal-700 transform hover:scale-105 transition-all duration-200 flex items-center gap-2">
                    <MessageCircle className="w-5 h-5" />
                    Message Innovator
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {sortedIdeas.length === 0 && (
        <div className="text-center py-12">
          <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Search className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-2">No opportunities found</h3>
          <p className="text-gray-600 mb-6">Try adjusting your search or filter criteria</p>
          <button 
            onClick={() => {
              setSearchTerm('');
              setSelectedStage('all');
              setSelectedCategory('all');
            }}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-emerald-600 hover:to-teal-700 transition-all duration-200"
          >
            Clear Filters
          </button>
        </div>
      )}

      {/* Load More */}
      {sortedIdeas.length > 0 && (
        <div className="text-center mt-12">
          <button className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-emerald-600 hover:to-teal-700 transform hover:scale-105 transition-all duration-200">
            Load More Opportunities
          </button>
        </div>
      )}
    </div>
  );
};

export default InvestorsPage;