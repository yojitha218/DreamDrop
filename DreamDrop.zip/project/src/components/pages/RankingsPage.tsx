import React, { useState } from 'react';
import { Trophy, Star, TrendingUp, Calendar, Medal, Crown, Award, Heart, Eye, MessageCircle, Filter, Users } from 'lucide-react';

interface RankedDream {
  id: string;
  rank: number;
  name: string;
  summary: string;
  upvotes: number;
  views: number;
  comments: number;
  author: string;
  avatar: string;
  tags: string[];
  trend: 'up' | 'down' | 'same';
  weeklyGrowth: number;
  category: string;
  strength: 'Strong' | 'Moderate' | 'Weak';
  createdAt: string;
}

const RankingsPage: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('weekly');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedMetric, setSelectedMetric] = useState('upvotes');

  const topDreams: RankedDream[] = [
    {
      id: '1',
      rank: 1,
      name: 'FarmBot Connect',
      summary: 'IoT-enabled smart farming with automated crop monitoring and yield optimization',
      upvotes: 1247,
      views: 8420,
      comments: 67,
      author: 'Emma Johnson',
      avatar: 'EJ',
      tags: ['Agriculture', 'IoT', 'Automation'],
      trend: 'up',
      weeklyGrowth: 23,
      category: 'AgTech',
      strength: 'Strong',
      createdAt: '2024-01-15'
    },
    {
      id: '2',
      rank: 2,
      name: 'MoodSpace VR',
      summary: 'Virtual reality therapy sessions with AI-guided meditation and stress relief',
      upvotes: 1156,
      views: 7890,
      comments: 52,
      author: 'Mike Rodriguez',
      avatar: 'MR',
      tags: ['VR', 'Mental Health', 'AI'],
      trend: 'up',
      weeklyGrowth: 18,
      category: 'HealthTech',
      strength: 'Strong',
      createdAt: '2024-01-20'
    },
    {
      id: '3',
      rank: 3,
      name: 'EcoTrack Pro',
      summary: 'AI-powered carbon footprint tracker with community challenges and gamified eco-goals',
      upvotes: 1089,
      views: 6540,
      comments: 45,
      author: 'Alex Chen',
      avatar: 'AC',
      tags: ['Environment', 'AI', 'Social'],
      trend: 'same',
      weeklyGrowth: 0,
      category: 'CleanTech',
      strength: 'Strong',
      createdAt: '2024-01-25'
    },
    {
      id: '4',
      rank: 4,
      name: 'PetPal Health',
      summary: 'Smart pet health monitoring with AI-powered symptom analysis and vet connections',
      upvotes: 967,
      views: 5210,
      comments: 38,
      author: 'Sarah Kim',
      avatar: 'SK',
      tags: ['HealthTech', 'Pets', 'AI'],
      trend: 'down',
      weeklyGrowth: -5,
      category: 'HealthTech',
      strength: 'Strong',
      createdAt: '2024-02-01'
    },
    {
      id: '5',
      rank: 5,
      name: 'StudySync AI',
      summary: 'Personalized learning platform with AI tutors and collaborative study sessions',
      upvotes: 834,
      views: 4320,
      comments: 29,
      author: 'David Park',
      avatar: 'DP',
      tags: ['EdTech', 'AI', 'Social'],
      trend: 'up',
      weeklyGrowth: 12,
      category: 'EdTech',
      strength: 'Moderate',
      createdAt: '2024-02-05'
    },
    {
      id: '6',
      rank: 6,
      name: 'WasteWise',
      summary: 'Smart waste management system for cities with predictive collection routes',
      upvotes: 756,
      views: 3890,
      comments: 24,
      author: 'Maria Santos',
      avatar: 'MS',
      tags: ['Smart Cities', 'Environment', 'AI'],
      trend: 'up',
      weeklyGrowth: 8,
      category: 'Smart Cities',
      strength: 'Strong',
      createdAt: '2024-02-10'
    },
    {
      id: '7',
      rank: 7,
      name: 'FitFuel AI',
      summary: 'AI-powered meal planning with personalized nutrition and fitness tracking',
      upvotes: 723,
      views: 3420,
      comments: 21,
      author: 'James Wilson',
      avatar: 'JW',
      tags: ['HealthTech', 'AI', 'Fitness'],
      trend: 'same',
      weeklyGrowth: 0,
      category: 'HealthTech',
      strength: 'Moderate',
      createdAt: '2024-02-12'
    },
    {
      id: '8',
      rank: 8,
      name: 'CraftConnect AR',
      summary: 'Marketplace for handmade goods with AR try-before-buy features',
      upvotes: 689,
      views: 2890,
      comments: 18,
      author: 'Lisa Zhang',
      avatar: 'LZ',
      tags: ['E-commerce', 'AR', 'Handmade'],
      trend: 'up',
      weeklyGrowth: 15,
      category: 'E-commerce',
      strength: 'Moderate',
      createdAt: '2024-02-15'
    },
    {
      id: '9',
      rank: 9,
      name: 'CodeMentor AI',
      summary: 'AI-powered coding assistant with real-time debugging and learning paths',
      upvotes: 612,
      views: 2540,
      comments: 16,
      author: 'Ryan Tech',
      avatar: 'RT',
      tags: ['EdTech', 'AI', 'Programming'],
      trend: 'up',
      weeklyGrowth: 22,
      category: 'EdTech',
      strength: 'Strong',
      createdAt: '2024-02-18'
    },
    {
      id: '10',
      rank: 10,
      name: 'GreenCommute',
      summary: 'Sustainable transportation app with carbon tracking and rewards',
      upvotes: 578,
      views: 2210,
      comments: 14,
      author: 'Eco Rider',
      avatar: 'ER',
      tags: ['Transport', 'Environment', 'Rewards'],
      trend: 'down',
      weeklyGrowth: -3,
      category: 'CleanTech',
      strength: 'Moderate',
      createdAt: '2024-02-20'
    }
  ];

  const periods = [
    { id: 'daily', label: 'Daily' },
    { id: 'weekly', label: 'Weekly' },
    { id: 'monthly', label: 'Monthly' },
    { id: 'all-time', label: 'All Time' }
  ];

  const categories = [
    { id: 'all', label: 'All Categories' },
    { id: 'agtech', label: 'AgTech' },
    { id: 'healthtech', label: 'HealthTech' },
    { id: 'cleantech', label: 'CleanTech' },
    { id: 'edtech', label: 'EdTech' },
    { id: 'smart-cities', label: 'Smart Cities' },
    { id: 'e-commerce', label: 'E-commerce' }
  ];

  const metrics = [
    { id: 'upvotes', label: 'Upvotes' },
    { id: 'views', label: 'Views' },
    { id: 'comments', label: 'Comments' },
    { id: 'engagement', label: 'Engagement' }
  ];

  // Filter dreams based on selected category
  const filteredDreams = selectedCategory === 'all' 
    ? topDreams 
    : topDreams.filter(dream => dream.category.toLowerCase().replace(' ', '-') === selectedCategory);

  // Sort dreams based on selected metric
  const sortedDreams = [...filteredDreams].sort((a, b) => {
    switch (selectedMetric) {
      case 'views':
        return b.views - a.views;
      case 'comments':
        return b.comments - a.comments;
      case 'engagement':
        return (b.upvotes + b.views + b.comments) - (a.upvotes + a.views + a.comments);
      default:
        return b.upvotes - a.upvotes;
    }
  });

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-8 h-8 text-yellow-500" />;
      case 2:
        return <Medal className="w-8 h-8 text-gray-400" />;
      case 3:
        return <Award className="w-8 h-8 text-amber-600" />;
      default:
        return <div className="w-8 h-8 flex items-center justify-center bg-gray-200 rounded-full text-gray-600 font-bold text-lg">#{rank}</div>;
    }
  };

  const getTrendIcon = (trend: string, growth: number) => {
    if (trend === 'up') {
      return <TrendingUp className="w-4 h-4 text-green-500" />;
    } else if (trend === 'down') {
      return <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />;
    }
    return <div className="w-4 h-4 bg-gray-300 rounded-full"></div>;
  };

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'Strong': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Moderate': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'Weak': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getMetricValue = (dream: RankedDream, metric: string) => {
    switch (metric) {
      case 'views':
        return dream.views.toLocaleString();
      case 'comments':
        return dream.comments.toString();
      case 'engagement':
        return (dream.upvotes + dream.views + dream.comments).toLocaleString();
      default:
        return dream.upvotes.toLocaleString();
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 py-8 pt-24 sm:pt-32 max-w-6xl">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-6">
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-4 rounded-full">
            <Trophy className="w-12 h-12 text-white" />
          </div>
        </div>
        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-yellow-500 to-orange-600 bg-clip-text text-transparent mb-4">
          Dream Rankings
        </h1>
        <p className="text-xl text-gray-600">
          Discover the most popular and trending startup ideas from our community
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-lg p-6 mb-8 border border-gray-100">
        <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
          <div className="flex items-center gap-4">
            <Calendar className="w-5 h-5 text-gray-600" />
            <div className="flex gap-2">
              {periods.map((period) => (
                <button
                  key={period.id}
                  onClick={() => setSelectedPeriod(period.id)}
                  className={`px-4 py-2 rounded-full font-medium transition-all duration-200 ${
                    selectedPeriod === period.id
                      ? 'bg-gradient-to-r from-yellow-500 to-orange-600 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {period.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Filter className="w-5 h-5 text-gray-600" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-orange-500 focus:outline-none bg-white"
            >
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.label}
                </option>
              ))}
            </select>

            <select
              value={selectedMetric}
              onChange={(e) => setSelectedMetric(e.target.value)}
              className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-orange-500 focus:outline-none bg-white"
            >
              {metrics.map((metric) => (
                <option key={metric.id} value={metric.id}>
                  {metric.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Top 3 Podium */}
      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {sortedDreams.slice(0, 3).map((dream, index) => {
          const positions = ['md:order-2', 'md:order-1', 'md:order-3'];
          const heights = ['h-72', 'h-64', 'h-56'];
          const gradients = [
            'from-yellow-400 to-yellow-600',
            'from-gray-300 to-gray-500',
            'from-amber-400 to-amber-600'
          ];
          
          return (
            <div key={dream.id} className={`${positions[index]} text-center`}>
              <div className={`bg-gradient-to-br ${gradients[index]} rounded-2xl ${heights[index]} p-6 flex flex-col justify-end text-white shadow-lg mb-4`}>
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full mx-auto mb-3 flex items-center justify-center text-white font-bold text-xl">
                    {dream.avatar}
                  </div>
                  <h3 className="font-bold text-lg mb-1">{dream.name}</h3>
                  <p className="text-sm opacity-90">by {dream.author}</p>
                  <div className="flex items-center justify-center gap-2 mt-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStrengthColor(dream.strength)}`}>
                      {dream.strength}
                    </span>
                  </div>
                </div>
                
                <div className="text-center">
                  {getRankIcon(dream.rank)}
                  <div className="mt-2">
                    <div className="text-3xl font-bold">{getMetricValue(dream, selectedMetric)}</div>
                    <div className="text-sm opacity-90">{selectedMetric}</div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Full Rankings List */}
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100">
        <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 border-b">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-800">Complete Rankings</h2>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>Showing {sortedDreams.length} dreams</span>
              <span>•</span>
              <span>Sorted by {metrics.find(m => m.id === selectedMetric)?.label}</span>
            </div>
          </div>
        </div>
        
        <div className="divide-y divide-gray-100">
          {sortedDreams.map((dream, index) => (
            <div key={dream.id} className="p-6 hover:bg-gray-50 transition-all duration-200">
              <div className="flex items-center gap-6">
                {/* Rank */}
                <div className="flex-shrink-0 w-16 text-center">
                  {getRankIcon(index + 1)}
                </div>

                {/* Avatar */}
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                    {dream.avatar}
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="text-xl font-bold text-gray-800">{dream.name}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStrengthColor(dream.strength)}`}>
                          {dream.strength}
                        </span>
                        <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-medium">
                          {dream.category}
                        </span>
                      </div>
                      <p className="text-gray-600 mb-2 line-clamp-2">{dream.summary}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span>by <span className="font-semibold">{dream.author}</span></span>
                        <span>•</span>
                        <div className="flex items-center gap-1">
                          <Heart className="w-4 h-4 text-pink-500" />
                          <span>{dream.upvotes.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="w-4 h-4 text-blue-500" />
                          <span>{dream.views.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MessageCircle className="w-4 h-4 text-green-500" />
                          <span>{dream.comments}</span>
                        </div>
                        <span>•</span>
                        <span>{new Date(dream.createdAt).toLocaleDateString()}</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {dream.tags.slice(0, 3).map((tag, tagIndex) => (
                          <span key={tagIndex} className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-3xl font-bold text-gray-800">{getMetricValue(dream, selectedMetric)}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm">
                        {getTrendIcon(dream.trend, dream.weeklyGrowth)}
                        <span className={`font-medium ${
                          dream.trend === 'up' ? 'text-green-600' : 
                          dream.trend === 'down' ? 'text-red-600' : 'text-gray-500'
                        }`}>
                          {dream.weeklyGrowth > 0 ? '+' : ''}{dream.weeklyGrowth}%
                        </span>
                      </div>
                      <div className="text-xs text-gray-500 mt-1">this week</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Load More */}
      {sortedDreams.length > 0 && (
        <div className="text-center mt-8">
          <button className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-200">
            Load More Rankings
          </button>
        </div>
      )}

      {/* Stats Summary */}
      <div className="mt-12 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl p-6 border border-yellow-200">
        <div className="text-center">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Community Stats</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">{topDreams.length}</div>
              <div className="text-sm text-gray-600">Total Dreams</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {topDreams.reduce((sum, dream) => sum + dream.upvotes, 0).toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Total Upvotes</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {topDreams.reduce((sum, dream) => sum + dream.views, 0).toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Total Views</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {topDreams.reduce((sum, dream) => sum + dream.comments, 0)}
              </div>
              <div className="text-sm text-gray-600">Total Comments</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RankingsPage;