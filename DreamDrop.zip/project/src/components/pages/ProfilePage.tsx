import React, { useState, useRef, useEffect } from 'react';
import { User, Settings, Heart, Bookmark, Trophy, TrendingUp, Calendar, MapPin, Mail, Globe, Edit3, Star, Award, Eye, MessageCircle, Share2, Save, X, Camera, Upload, Trash2, RotateCcw, Volume2, Palette, Play, Pause, Square } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface Dream {
  id: string;
  name: string;
  summary: string;
  upvotes: number;
  comments: number;
  tags: string[];
  createdAt: string;
  status: 'trending' | 'featured' | 'new';
  strength: 'Strong' | 'Moderate' | 'Weak';
  logoUrl?: string;
  audioSummaryUrl?: string;
  originalIdea?: string;
}

const ProfilePage: React.FC = () => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('dreams');
  const [isEditing, setIsEditing] = useState(false);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [playingAudio, setPlayingAudio] = useState<string | null>(null);
  const [pausedAudio, setPausedAudio] = useState<string | null>(null);
  const [editedProfile, setEditedProfile] = useState({
    fullName: '',
    email: '',
    website: '',
    location: '',
    bio: '',
    avatar: ''
  });

  React.useEffect(() => {
    if (user) {
      setEditedProfile({
        fullName: user.fullName,
        email: user.email,
        website: user.role === 'innovator' ? 'innovator.dev' : 'investor.com',
        location: 'San Francisco, CA',
        bio: user.role === 'innovator' 
          ? 'Passionate innovator turning dreams into reality through technology and creativity.'
          : 'Experienced investor helping startups scale and succeed in competitive markets.',
        avatar: user.avatar || ''
      });
    }
  }, [user]);

  // Load user dreams from localStorage
  const [myDreams, setMyDreams] = useState<Dream[]>([]);

  useEffect(() => {
    if (user) {
      const userDreams = JSON.parse(localStorage.getItem(`dreamdrop_user_dreams_${user.id}`) || '[]');
      setMyDreams(userDreams);
    }
  }, [user]);

  if (!user) {
    return (
      <div className="container mx-auto px-6 py-8 pt-24 sm:pt-32 max-w-6xl">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">Please log in to view your profile</h1>
        </div>
      </div>
    );
  }

  const userStats = {
    dreamsPosted: user.role === 'innovator' ? myDreams.length : 0,
    totalUpvotes: user.role === 'innovator' ? myDreams.reduce((sum, dream) => sum + (dream.upvotes || 0), 0) : 0,
    investmentsMade: user.role === 'investor' ? 8 : 0,
    portfolioValue: user.role === 'investor' ? '$2.4M' : '$0',
    rank: user.role === 'innovator' ? Math.max(1, 100 - myDreams.length * 5) : 12,
    joinedDate: new Date(user.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
  };

  const savedDreams: Dream[] = [
    {
      id: '4',
      name: 'FarmBot Connect',
      summary: 'IoT-enabled smart farming with automated crop monitoring and yield optimization',
      upvotes: 1247,
      comments: 67,
      tags: ['Agriculture', 'IoT', 'Automation'],
      createdAt: '2024-01-08',
      status: 'featured',
      strength: 'Strong'
    },
    {
      id: '5',
      name: 'MoodSpace',
      summary: 'Virtual reality therapy sessions with AI-guided meditation and stress relief',
      upvotes: 1156,
      comments: 52,
      tags: ['VR', 'Mental Health', 'AI'],
      createdAt: '2024-01-22',
      status: 'trending',
      strength: 'Strong'
    }
  ];

  const tabs = user.role === 'innovator' 
    ? [
        { id: 'dreams', label: 'My Dreams', icon: Heart, count: myDreams.length },
        { id: 'saved', label: 'Saved', icon: Bookmark, count: savedDreams.length },
        { id: 'settings', label: 'Settings', icon: Settings }
      ]
    : [
        { id: 'portfolio', label: 'Portfolio', icon: TrendingUp, count: userStats.investmentsMade },
        { id: 'saved', label: 'Saved', icon: Bookmark, count: savedDreams.length },
        { id: 'settings', label: 'Settings', icon: Settings }
      ];

  const handleEditToggle = () => {
    if (isEditing) {
      // Save changes logic would go here
      console.log('Saving profile changes:', editedProfile);
    }
    setIsEditing(!isEditing);
  };

  const handleInputChange = (field: string, value: string) => {
    setEditedProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        alert('Please select an image file');
        return;
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('File size must be less than 5MB');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setPhotoPreview(result);
        setShowPhotoModal(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePhotoSave = () => {
    if (photoPreview) {
      setEditedProfile(prev => ({
        ...prev,
        avatar: photoPreview
      }));
      setShowPhotoModal(false);
      setPhotoPreview(null);
    }
  };

  const handlePhotoRemove = () => {
    setEditedProfile(prev => ({
      ...prev,
      avatar: ''
    }));
    setShowPhotoModal(false);
    setPhotoPreview(null);
  };

  const handlePhotoCancel = () => {
    setShowPhotoModal(false);
    setPhotoPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleStartAudio = (dream: Dream) => {
    // Stop any currently playing audio
    if (playingAudio) {
      speechSynthesis.cancel();
      setPlayingAudio(null);
      setPausedAudio(null);
    }

    // If clicking the same dream that was playing, just stop
    if (playingAudio === dream.id) {
      return;
    }

    // Check if speech synthesis is supported
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported in your browser.');
      return;
    }

    setPlayingAudio(dream.id);
    setPausedAudio(null);

    // Create the audio summary text
    const audioText = `Introducing ${dream.name}. ${dream.summary.substring(0, 200)}. This innovative solution has received ${dream.upvotes} upvotes and ${dream.comments} comments from the community.`;

    const utterance = new SpeechSynthesisUtterance(audioText);
    
    // Configure voice settings
    utterance.rate = 0.9;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    
    // Try to use a professional-sounding voice
    const voices = speechSynthesis.getVoices();
    const preferredVoice = voices.find(voice => 
      voice.name.includes('Google') || 
      voice.name.includes('Microsoft') ||
      voice.name.includes('Alex') ||
      voice.name.includes('Samantha')
    ) || voices[0];
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }
    
    utterance.onend = () => {
      setPlayingAudio(null);
      setPausedAudio(null);
    };
    
    utterance.onerror = () => {
      setPlayingAudio(null);
      setPausedAudio(null);
      alert('Error playing audio. Please try again.');
    };
    
    // Start speaking
    speechSynthesis.speak(utterance);
  };

  const handlePauseAudio = (dreamId: string) => {
    if ('speechSynthesis' in window && speechSynthesis.speaking) {
      speechSynthesis.pause();
      setPausedAudio(dreamId);
    }
  };

  const handleResumeAudio = (dreamId: string) => {
    if ('speechSynthesis' in window && speechSynthesis.paused) {
      speechSynthesis.resume();
      setPausedAudio(null);
    }
  };

  const handleStopAudio = () => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
    }
    setPlayingAudio(null);
    setPausedAudio(null);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'trending': return 'bg-red-100 text-red-700 border-red-200';
      case 'featured': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'new': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'Strong': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Moderate': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'Weak': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const renderDreamCard = (dream: Dream) => (
    <div key={dream.id} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 border border-gray-100">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-xl font-bold text-gray-800">{dream.name}</h3>
            <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(dream.status)}`}>
              {dream.status}
            </span>
            <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStrengthColor(dream.strength)}`}>
              {dream.strength}
            </span>
          </div>
          <p className="text-gray-600 line-clamp-2 mb-4">{dream.summary}</p>
        </div>
      </div>

      {/* Logo and Audio Section */}
      {(dream.logoUrl || dream.audioSummaryUrl) && (
        <div className="grid grid-cols-2 gap-4 mb-4">
          {/* Logo Display */}
          {dream.logoUrl && (
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-3 text-center border border-indigo-100">
              <div className="flex items-center gap-2 mb-2">
                <Palette className="w-3 h-3 text-indigo-600" />
                <span className="text-indigo-800 font-semibold text-xs">Logo</span>
              </div>
              <img 
                src={dream.logoUrl} 
                alt={`${dream.name} Logo`}
                className="w-12 h-12 mx-auto rounded-lg shadow-sm"
              />
            </div>
          )}

          {/* Audio Summary */}
          {dream.audioSummaryUrl && (
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl p-3 text-center border border-emerald-100">
              <div className="flex items-center gap-2 mb-2">
                <Volume2 className="w-3 h-3 text-emerald-600" />
                <span className="text-emerald-800 font-semibold text-xs">Audio</span>
              </div>
              
              {/* Audio Control Buttons */}
              <div className="flex gap-1">
                {playingAudio !== dream.id ? (
                  <button
                    onClick={() => handleStartAudio(dream)}
                    className="flex-1 bg-emerald-500 text-white py-1 px-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-1 text-xs hover:bg-emerald-600"
                  >
                    <Play className="w-3 h-3" />
                    Start
                  </button>
                ) : (
                  <>
                    {pausedAudio !== dream.id ? (
                      <button
                        onClick={() => handlePauseAudio(dream.id)}
                        className="flex-1 bg-yellow-500 text-white py-1 px-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-1 text-xs hover:bg-yellow-600"
                      >
                        <Pause className="w-3 h-3" />
                        Pause
                      </button>
                    ) : (
                      <button
                        onClick={() => handleResumeAudio(dream.id)}
                        className="flex-1 bg-emerald-500 text-white py-1 px-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-1 text-xs hover:bg-emerald-600"
                      >
                        <Play className="w-3 h-3" />
                        Resume
                      </button>
                    )}
                    <button
                      onClick={handleStopAudio}
                      className="flex-1 bg-red-500 text-white py-1 px-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-1 text-xs hover:bg-red-600"
                    >
                      <Square className="w-3 h-3" />
                      Stop
                    </button>
                  </>
                )}
              </div>
              
              {/* Audio Status */}
              {playingAudio === dream.id && (
                <div className="mt-2 bg-emerald-100 border border-emerald-200 rounded-lg p-1">
                  <div className="flex items-center justify-center gap-1">
                    <div className="w-1 h-1 bg-emerald-500 rounded-full animate-pulse"></div>
                    <span className="text-emerald-700 text-xs font-medium">
                      {pausedAudio === dream.id ? 'Paused' : 'Playing...'}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
      
      <div className="flex flex-wrap gap-2 mb-4">
        {dream.tags.map((tag, index) => (
          <span key={index} className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
            {tag}
          </span>
        ))}
      </div>
      
      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
        <div className="flex items-center gap-4 text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <Heart className="w-4 h-4 text-pink-500" />
            <span className="font-semibold">{(dream.upvotes || 0).toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-1">
            <MessageCircle className="w-4 h-4 text-blue-500" />
            <span className="font-semibold">{dream.comments}</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar className="w-4 h-4" />
            <span>{new Date(dream.createdAt).toLocaleDateString()}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="text-purple-600 hover:text-purple-700 font-medium flex items-center gap-1">
            <Eye className="w-4 h-4" />
            View
          </button>
          <button className="text-gray-600 hover:text-gray-700 font-medium flex items-center gap-1">
            <Share2 className="w-4 h-4" />
            Share
          </button>
        </div>
      </div>
    </div>
  );

  const renderAvatar = () => {
    if (editedProfile.avatar) {
      return (
        <img
          src={editedProfile.avatar}
          alt="Profile"
          className="w-32 h-32 rounded-3xl object-cover"
        />
      );
    } else {
      return (
        <div className="w-32 h-32 bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center text-6xl font-bold">
          {user.fullName.split(' ').map(n => n[0]).join('')}
        </div>
      );
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 py-8 pt-24 sm:pt-32 max-w-6xl">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 rounded-3xl p-6 sm:p-8 md:p-12 text-white mb-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full translate-y-12 -translate-x-12"></div>
        
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row items-start gap-8">
            <div className="relative">
              {renderAvatar()}
              {activeTab === 'settings' && isEditing && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute -bottom-2 -right-2 bg-white text-purple-600 p-3 rounded-full shadow-lg hover:shadow-xl transform hover:scale-110 transition-all duration-200"
                  title="Change photo"
                >
                  <Camera className="w-5 h-5" />
                </button>
              )}
            </div>
            
            <div className="flex-1">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-4xl font-bold mb-2">{user.fullName}</h1>
                  <p className="text-xl text-white/90 mb-2">
                    {user.role === 'innovator' 
                      ? 'Innovation Enthusiast & Tech Entrepreneur' 
                      : 'Venture Capitalist & Startup Advisor'
                    }
                  </p>
                  <div className="flex items-center gap-4 text-white/80">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>{editedProfile.location}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>Joined {userStats.joinedDate}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('settings')}
                  className="bg-white/20 backdrop-blur-sm p-3 rounded-full hover:bg-white/30 transition-all duration-200"
                >
                  <Edit3 className="w-5 h-5" />
                </button>
              </div>
              
              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {user.role === 'innovator' ? (
                  <>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold">{userStats.dreamsPosted}</div>
                      <div className="text-sm text-white/80">Dreams Posted</div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold">{userStats.totalUpvotes.toLocaleString()}</div>
                      <div className="text-sm text-white/80">Total Upvotes</div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold">#{userStats.rank}</div>
                      <div className="text-sm text-white/80">Global Rank</div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold">4.8★</div>
                      <div className="text-sm text-white/80">Avg Rating</div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold">{userStats.investmentsMade}</div>
                      <div className="text-sm text-white/80">Investments</div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold">{userStats.portfolioValue}</div>
                      <div className="text-sm text-white/80">Portfolio Value</div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold">#{userStats.rank}</div>
                      <div className="text-sm text-white/80">Investor Rank</div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
                      <div className="text-2xl font-bold">92%</div>
                      <div className="text-sm text-white/80">Success Rate</div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handlePhotoUpload}
        className="hidden"
      />

      {/* Photo Upload Modal */}
      {showPhotoModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-800">Update Profile Photo</h3>
                <button
                  onClick={handlePhotoCancel}
                  className="p-2 rounded-full hover:bg-gray-100 transition-all duration-200"
                >
                  <X className="w-6 h-6 text-gray-600" />
                </button>
              </div>

              {photoPreview && (
                <div className="mb-6">
                  <div className="relative">
                    <img
                      src={photoPreview}
                      alt="Preview"
                      className="w-full h-64 object-cover rounded-2xl"
                    />
                    <div className="absolute inset-0 bg-black/20 rounded-2xl flex items-center justify-center">
                      <div className="bg-white/90 backdrop-blur-sm rounded-full p-4">
                        <Camera className="w-8 h-8 text-gray-800" />
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mt-3 text-center">
                    This photo will be used as your profile picture across DreamDrop
                  </p>
                </div>
              )}

              <div className="flex gap-3">
                <button
                  onClick={handlePhotoCancel}
                  className="flex-1 border-2 border-gray-300 text-gray-700 py-3 rounded-xl font-semibold hover:border-gray-400 hover:bg-gray-50 transition-all duration-200"
                >
                  Cancel
                </button>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-200 transition-all duration-200 flex items-center justify-center gap-2"
                >
                  <Upload className="w-5 h-5" />
                  Choose Different
                </button>
                <button
                  onClick={handlePhotoSave}
                  disabled={!photoPreview}
                  className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 text-white py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  Save Photo
                </button>
              </div>

              {editedProfile.avatar && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <button
                    onClick={handlePhotoRemove}
                    className="w-full flex items-center justify-center gap-2 text-red-600 hover:text-red-700 py-2 rounded-xl hover:bg-red-50 transition-all duration-200"
                  >
                    <Trash2 className="w-4 h-4" />
                    Remove Current Photo
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tabs Navigation */}
      <div className="bg-white rounded-2xl shadow-lg mb-8 border border-gray-100">
        <div className="flex border-b border-gray-100">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-4 font-medium transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'text-purple-600 border-b-2 border-purple-600 bg-purple-50'
                    : 'text-gray-600 hover:text-purple-600 hover:bg-purple-50'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-bold">
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div className="min-h-96">
        {activeTab === 'dreams' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-800">My Dreams</h2>
              <button className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-200 flex items-center gap-2">
                <Heart className="w-5 h-5" />
                Drop New Dream
              </button>
            </div>
            {myDreams.length > 0 ? (
              <div className="grid gap-6">
                {myDreams.map(renderDreamCard)}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">No dreams yet</h3>
                <p className="text-gray-600 mb-6">Start by dropping your first dream idea!</p>
                <button className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-200">
                  Drop Your First Dream
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'portfolio' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Investment Portfolio</h2>
              <button className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-emerald-600 hover:to-teal-700 transform hover:scale-105 transition-all duration-200 flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Explore Opportunities
              </button>
            </div>
            <div className="grid gap-6">
              {savedDreams.map(renderDreamCard)}
            </div>
          </div>
        )}

        {activeTab === 'saved' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Saved Dreams</h2>
            <div className="grid gap-6">
              {savedDreams.map(renderDreamCard)}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Profile Settings</h2>
              <div className="flex items-center gap-3">
                {isEditing && (
                  <button
                    onClick={() => setIsEditing(false)}
                    className="flex items-center gap-2 px-4 py-2 border-2 border-gray-300 rounded-xl text-gray-600 hover:border-gray-400 transition-all duration-200"
                  >
                    <X className="w-4 h-4" />
                    Cancel
                  </button>
                )}
                <button
                  onClick={handleEditToggle}
                  className={`flex items-center gap-2 px-6 py-2 rounded-xl font-semibold transition-all duration-200 ${
                    isEditing
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:from-emerald-600 hover:to-teal-700'
                      : 'bg-gradient-to-r from-pink-500 to-purple-600 text-white hover:from-pink-600 hover:to-purple-700'
                  }`}
                >
                  {isEditing ? <Save className="w-4 h-4" /> : <Edit3 className="w-4 h-4" />}
                  {isEditing ? 'Save Changes' : 'Edit Profile'}
                </button>
              </div>
            </div>
            
            <div className="space-y-6">
              {/* Profile Photo Section */}
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Profile Photo</h3>
                <div className="flex items-center gap-6">
                  <div className="relative">
                    {editedProfile.avatar ? (
                      <img
                        src={editedProfile.avatar}
                        alt="Profile"
                        className="w-24 h-24 rounded-2xl object-cover border-4 border-gray-200"
                      />
                    ) : (
                      <div className="w-24 h-24 bg-gradient-to-r from-pink-500 to-purple-600 rounded-2xl flex items-center justify-center text-white font-bold text-2xl border-4 border-gray-200">
                        {user.fullName.split(' ').map(n => n[0]).join('')}
                      </div>
                    )}
                    {isEditing && (
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="absolute -bottom-2 -right-2 bg-white text-purple-600 p-2 rounded-full shadow-lg hover:shadow-xl transform hover:scale-110 transition-all duration-200 border-2 border-purple-200"
                        title="Change photo"
                      >
                        <Camera className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-800 mb-2">Profile Picture</h4>
                    <p className="text-gray-600 text-sm mb-4">
                      Upload a photo to personalize your profile. Recommended size: 400x400px
                    </p>
                    {isEditing && (
                      <div className="flex gap-3">
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-all duration-200"
                        >
                          <Upload className="w-4 h-4" />
                          Upload Photo
                        </button>
                        {editedProfile.avatar && (
                          <button
                            onClick={handlePhotoRemove}
                            className="flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-all duration-200"
                          >
                            <Trash2 className="w-4 h-4" />
                            Remove
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Basic Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Basic Information</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                    <div className="flex items-center gap-2">
                      <User className="w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={editedProfile.fullName}
                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                        className={`flex-1 p-3 border-2 rounded-xl focus:outline-none transition-all duration-200 ${
                          isEditing 
                            ? 'border-gray-300 focus:border-purple-500 bg-white' 
                            : 'border-gray-200 bg-gray-50 cursor-not-allowed'
                        }`}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <div className="flex items-center gap-2">
                      <Mail className="w-5 h-5 text-gray-400" />
                      <input
                        type="email"
                        value={editedProfile.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className={`flex-1 p-3 border-2 rounded-xl focus:outline-none transition-all duration-200 ${
                          isEditing 
                            ? 'border-gray-300 focus:border-purple-500 bg-white' 
                            : 'border-gray-200 bg-gray-50 cursor-not-allowed'
                        }`}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Location & Website */}
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Location & Contact</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={editedProfile.location}
                        onChange={(e) => handleInputChange('location', e.target.value)}
                        placeholder="Enter your city, state/country"
                        className={`flex-1 p-3 border-2 rounded-xl focus:outline-none transition-all duration-200 ${
                          isEditing 
                            ? 'border-gray-300 focus:border-purple-500 bg-white' 
                            : 'border-gray-200 bg-gray-50 cursor-not-allowed'
                        }`}
                        disabled={!isEditing}
                      />
                    </div>
                    {isEditing && (
                      <p className="text-xs text-gray-500 mt-1">
                        This helps others in your area connect with you
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Website</label>
                    <div className="flex items-center gap-2">
                      <Globe className="w-5 h-5 text-gray-400" />
                      <input
                        type="url"
                        value={editedProfile.website}
                        onChange={(e) => handleInputChange('website', e.target.value)}
                        placeholder="https://yourwebsite.com"
                        className={`flex-1 p-3 border-2 rounded-xl focus:outline-none transition-all duration-200 ${
                          isEditing 
                            ? 'border-gray-300 focus:border-purple-500 bg-white' 
                            : 'border-gray-200 bg-gray-50 cursor-not-allowed'
                        }`}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Bio Section */}
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">About You</h3>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Bio</label>
                  <textarea
                    value={editedProfile.bio}
                    onChange={(e) => handleInputChange('bio', e.target.value)}
                    placeholder="Tell others about yourself, your interests, and what you're working on..."
                    rows={4}
                    maxLength={500}
                    className={`w-full p-3 border-2 rounded-xl focus:outline-none transition-all duration-200 resize-none ${
                      isEditing 
                        ? 'border-gray-300 focus:border-purple-500 bg-white' 
                        : 'border-gray-200 bg-gray-50 cursor-not-allowed'
                    }`}
                    disabled={!isEditing}
                  />
                  {isEditing && (
                    <p className="text-xs text-gray-500 mt-1">
                      {editedProfile.bio.length}/500 characters
                    </p>
                  )}
                </div>
              </div>
              
              {/* Account Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Account Information</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
                    <div className="flex items-center gap-2">
                      <Award className="w-5 h-5 text-gray-400" />
                      <select
                        value={user.role}
                        className="flex-1 p-3 border-2 border-gray-200 rounded-xl bg-gray-50 cursor-not-allowed"
                        disabled
                      >
                        <option value="innovator">Innovator</option>
                        <option value="investor">Investor</option>
                      </select>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      Contact support to change your role
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Member Since</label>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={new Date(user.createdAt).toLocaleDateString()}
                        className="flex-1 p-3 border-2 border-gray-200 rounded-xl bg-gray-50 cursor-not-allowed"
                        disabled
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Preferences */}
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Notification Preferences</h3>
                <div className="space-y-3">
                  <label className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" 
                      defaultChecked 
                      disabled={!isEditing}
                    />
                    <span className="text-sm text-gray-700">Email notifications for new messages</span>
                  </label>
                  <label className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" 
                      defaultChecked 
                      disabled={!isEditing}
                    />
                    <span className="text-sm text-gray-700">Weekly digest of trending dreams</span>
                  </label>
                  <label className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" 
                      disabled={!isEditing}
                    />
                    <span className="text-sm text-gray-700">Marketing updates and promotions</span>
                  </label>
                  <label className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      className="rounded border-gray-300 text-purple-600 focus:ring-purple-500" 
                      defaultChecked 
                      disabled={!isEditing}
                    />
                    <span className="text-sm text-gray-700">Show my location to other users</span>
                  </label>
                </div>
              </div>

              {/* Save Changes Notice */}
              {isEditing && (
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-500 p-2 rounded-full">
                      <Edit3 className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-blue-800">Editing Mode Active</h4>
                      <p className="text-blue-700 text-sm">Make your changes and click "Save Changes" to update your profile.</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;