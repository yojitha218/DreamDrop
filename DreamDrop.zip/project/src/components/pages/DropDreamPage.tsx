import React, { useState, useRef } from 'react';
import { Lightbulb, Mic, Sparkles, Check, ArrowRight, Star, Users, TrendingUp, Target, Zap, Brain, Rocket, Play, Share2, Linkedin, Twitter, MessageSquare, Crown, AlertTriangle, Palette, Volume2, Download, RotateCcw, Pause, Square } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import UpgradeModal from '../monetization/UpgradeModal';

interface GeneratedStartup {
  name: string;
  focus: string;
  targetUsers: string;
  summary: string;
  uniqueness: string;
  strength: 'Strong' | 'Moderate' | 'Weak';
  marketCheck: string;
  logoUrl?: string;
  audioSummaryUrl?: string;
}

const DropDreamPage: React.FC = () => {
  const { user, canSubmitDream, getRemainingDreams, incrementDreamCount } = useAuth();
  const [dreamIdea, setDreamIdea] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGeneratingLogo, setIsGeneratingLogo] = useState(false);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [generatedStartup, setGeneratedStartup] = useState<GeneratedStartup | null>(null);
  const [isPosted, setIsPosted] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isPausedAudio, setIsPausedAudio] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);

  const canSubmit = canSubmitDream();
  const remainingDreams = getRemainingDreams();

  // Generate realistic audio using Web Speech API
  const generateAudioSummary = (text: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      try {
        // Check if speech synthesis is supported
        if (!('speechSynthesis' in window)) {
          reject(new Error('Speech synthesis not supported'));
          return;
        }

        // Create a data URL for the audio (simulated)
        const audioId = Date.now().toString();
        const audioUrl = `data:audio/wav;base64,${audioId}`;
        
        resolve(audioUrl);
        
      } catch (error) {
        reject(error);
      }
    });
  };

  // Enhanced AI generation that creates unique startups based on the dream input
  const generateUniqueStartup = (dreamInput: string): GeneratedStartup => {
    const dreamLower = dreamInput.toLowerCase();
    
    // Extract key concepts from the dream input
    const extractKeywords = (text: string) => {
      const words = text.toLowerCase().split(/\s+/);
      const stopWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'i', 'want', 'create', 'make', 'build', 'develop'];
      return words.filter(word => word.length > 3 && !stopWords.includes(word));
    };

    const keywords = extractKeywords(dreamInput);
    
    // Analyze the dream input for themes and generate relevant content
    const analyzeTheme = (input: string) => {
      const themes = {
        health: ['health', 'medical', 'doctor', 'fitness', 'wellness', 'therapy', 'medicine', 'hospital', 'care', 'mental', 'physical'],
        tech: ['ai', 'artificial', 'intelligence', 'robot', 'automation', 'software', 'app', 'digital', 'tech', 'computer', 'algorithm', 'machine', 'learning'],
        environment: ['environment', 'green', 'eco', 'sustainable', 'climate', 'carbon', 'renewable', 'clean', 'nature', 'pollution', 'waste'],
        education: ['education', 'learning', 'school', 'student', 'teach', 'study', 'knowledge', 'course', 'training', 'university', 'academic'],
        food: ['food', 'restaurant', 'cooking', 'recipe', 'meal', 'nutrition', 'diet', 'kitchen', 'chef', 'eating', 'hunger'],
        transport: ['transport', 'car', 'bike', 'travel', 'delivery', 'logistics', 'shipping', 'vehicle', 'ride', 'traffic', 'mobility'],
        social: ['social', 'community', 'connect', 'friend', 'network', 'chat', 'communication', 'people', 'relationship', 'dating'],
        finance: ['money', 'finance', 'bank', 'payment', 'investment', 'crypto', 'budget', 'financial', 'economy', 'trading'],
        entertainment: ['game', 'music', 'movie', 'entertainment', 'fun', 'play', 'video', 'streaming', 'content', 'media'],
        business: ['business', 'startup', 'company', 'entrepreneur', 'market', 'sales', 'customer', 'service', 'commerce']
      };

      let primaryTheme = 'tech';
      let maxScore = 0;
      
      Object.entries(themes).forEach(([theme, themeWords]) => {
        const score = themeWords.filter(word => input.toLowerCase().includes(word)).length;
        if (score > maxScore) {
          maxScore = score;
          primaryTheme = theme;
        }
      });

      return primaryTheme;
    };

    const theme = analyzeTheme(dreamInput);
    
    // Generate startup name based on keywords and theme
    const generateName = () => {
      const prefixes = {
        health: ['Health', 'Med', 'Care', 'Vital', 'Well', 'Life'],
        tech: ['Smart', 'AI', 'Tech', 'Digital', 'Cyber', 'Auto'],
        environment: ['Eco', 'Green', 'Clean', 'Earth', 'Bio', 'Sustain'],
        education: ['Learn', 'Edu', 'Study', 'Know', 'Skill', 'Mind'],
        food: ['Food', 'Taste', 'Flavor', 'Meal', 'Cook', 'Nutri'],
        transport: ['Move', 'Go', 'Ride', 'Trans', 'Flow', 'Swift'],
        social: ['Connect', 'Social', 'Link', 'Meet', 'Share', 'Unite'],
        finance: ['Pay', 'Coin', 'Fund', 'Money', 'Invest', 'Trade'],
        entertainment: ['Play', 'Fun', 'Joy', 'Stream', 'Media', 'Show'],
        business: ['Biz', 'Pro', 'Work', 'Team', 'Corp', 'Hub']
      };

      const suffixes = ['Hub', 'Pro', 'AI', 'Connect', 'Sync', 'Flow', 'Wise', 'Smart', 'Plus', 'Max'];
      
      const themePrefix = prefixes[theme as keyof typeof prefixes] || prefixes.tech;
      const randomPrefix = themePrefix[Math.floor(Math.random() * themePrefix.length)];
      const randomSuffix = suffixes[Math.floor(Math.random() * suffixes.length)];
      
      // Try to incorporate a keyword from the dream
      const mainKeyword = keywords.find(k => k.length > 4) || keywords[0];
      if (mainKeyword) {
        const capitalizedKeyword = mainKeyword.charAt(0).toUpperCase() + mainKeyword.slice(1);
        return Math.random() > 0.5 ? `${capitalizedKeyword}${randomSuffix}` : `${randomPrefix}${capitalizedKeyword}`;
      }
      
      return `${randomPrefix}${randomSuffix}`;
    };

    // Generate focus based on dream content
    const generateFocus = () => {
      const dreamWords = dreamInput.split(' ');
      const actionWords = dreamWords.filter(word => 
        ['help', 'solve', 'improve', 'create', 'build', 'connect', 'enable', 'provide', 'offer', 'deliver'].some(action => 
          word.toLowerCase().includes(action)
        )
      );

      if (dreamInput.toLowerCase().includes('app')) {
        return `Mobile application that ${dreamInput.toLowerCase().includes('ai') ? 'uses AI to ' : ''}addresses the core need described in your vision`;
      } else if (dreamInput.toLowerCase().includes('platform')) {
        return `Digital platform designed to ${dreamInput.slice(0, 100).toLowerCase()}`;
      } else {
        return `Innovative solution that transforms ${dreamInput.slice(0, 80).toLowerCase()}`;
      }
    };

    // Generate target users based on dream content
    const generateTargetUsers = () => {
      if (dreamInput.toLowerCase().includes('student')) return 'Students, educators, and academic institutions';
      if (dreamInput.toLowerCase().includes('business')) return 'Small to medium businesses and entrepreneurs';
      if (dreamInput.toLowerCase().includes('health')) return 'Health-conscious individuals and healthcare professionals';
      if (dreamInput.toLowerCase().includes('parent')) return 'Parents, families, and caregivers';
      if (dreamInput.toLowerCase().includes('senior')) return 'Senior citizens and elderly care providers';
      if (dreamInput.toLowerCase().includes('professional')) return 'Working professionals and industry experts';
      
      // Default based on theme
      const themeUsers = {
        health: 'Health-conscious individuals and medical professionals',
        tech: 'Tech enthusiasts and early adopters',
        environment: 'Environmentally conscious consumers and organizations',
        education: 'Students, teachers, and lifelong learners',
        food: 'Food enthusiasts and health-conscious consumers',
        transport: 'Commuters and logistics professionals',
        social: 'Social media users and community builders',
        finance: 'Investors and financially savvy individuals',
        entertainment: 'Content creators and entertainment seekers',
        business: 'Entrepreneurs and business professionals'
      };
      
      return themeUsers[theme as keyof typeof themeUsers] || 'General consumers and early adopters';
    };

    // Generate summary incorporating the original dream
    const generateSummary = () => {
      const dreamSnippet = dreamInput.length > 100 ? dreamInput.slice(0, 100) + '...' : dreamInput;
      return `This innovative solution directly addresses your vision: "${dreamSnippet}" Our platform leverages cutting-edge technology and user-centered design to transform this concept into a scalable, market-ready solution that delivers real value to users.`;
    };

    // Generate uniqueness based on dream specifics
    const generateUniqueness = () => {
      const uniqueAspects = [
        `First platform to combine the specific approach mentioned in your dream with modern technology`,
        `Revolutionary integration of your core concept with AI-powered automation and user experience`,
        `Breakthrough solution that uniquely addresses the exact problem you've identified`,
        `Innovative approach that transforms your vision into a scalable, technology-driven solution`
      ];
      
      return uniqueAspects[Math.floor(Math.random() * uniqueAspects.length)];
    };

    // Generate strength based on dream complexity and clarity
    const generateStrength = (): 'Strong' | 'Moderate' | 'Weak' => {
      const dreamLength = dreamInput.length;
      const hasSpecificTerms = keywords.length > 3;
      const hasActionWords = ['solve', 'help', 'improve', 'create', 'build'].some(word => 
        dreamInput.toLowerCase().includes(word)
      );
      
      if (dreamLength > 100 && hasSpecificTerms && hasActionWords) return 'Strong';
      if (dreamLength > 50 && (hasSpecificTerms || hasActionWords)) return 'Moderate';
      return 'Weak';
    };

    // Generate market analysis
    const generateMarketCheck = () => {
      const analyses = [
        `Strong market opportunity identified for solutions addressing the specific need you've described. Early market research shows significant demand in this space.`,
        `Growing market segment with clear user pain points that align perfectly with your vision. Competitive landscape shows room for innovative disruption.`,
        `Emerging market opportunity with substantial growth potential. Your unique approach could capture significant market share in this developing space.`,
        `Established market ready for innovation. Your solution addresses gaps that current players haven't fully solved, creating a clear competitive advantage.`
      ];
      
      return analyses[Math.floor(Math.random() * analyses.length)];
    };

    return {
      name: generateName(),
      focus: generateFocus(),
      targetUsers: generateTargetUsers(),
      summary: generateSummary(),
      uniqueness: generateUniqueness(),
      strength: generateStrength(),
      marketCheck: generateMarketCheck()
    };
  };

  const handleGenerateStartup = async () => {
    if (!dreamIdea.trim()) return;
    
    // Check if user can submit
    if (!canSubmit) {
      setShowUpgradeModal(true);
      return;
    }
    
    setIsGenerating(true);
    
    try {
      // Simulate AI processing time
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Generate unique startup based on the dream input
      const uniqueStartup = generateUniqueStartup(dreamIdea);
      
      setGeneratedStartup(uniqueStartup);
      await incrementDreamCount();
      
      // Show success message
      console.log('✅ Generated unique startup:', uniqueStartup.name);
      
    } catch (error) {
      console.error('Generate startup error:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateLogo = async () => {
    if (!generatedStartup) return;
    
    setIsGeneratingLogo(true);
    
    try {
      // Simulate logo generation with realistic timing
      await new Promise(resolve => setTimeout(resolve, 4000));
      
      // Generate a realistic logo based on the startup
      const logoId = `${generatedStartup.name.toLowerCase().replace(/\s+/g, '-')}-logo-${Date.now()}`;
      
      // Create a custom SVG logo based on startup name and theme
      const logoSvg = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200'%3E%3Cdefs%3E%3ClinearGradient id='grad' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%23ec4899;stop-opacity:1' /%3E%3Cstop offset='100%25' style='stop-color:%238b5cf6;stop-opacity:1' /%3E%3C/linearGradient%3E%3C/defs%3E%3Ccircle cx='100' cy='100' r='90' fill='url(%23grad)' stroke='white' stroke-width='4'/%3E%3Ctext x='50%25' y='50%25' font-family='Arial, sans-serif' font-size='24' font-weight='bold' fill='white' text-anchor='middle' dy='.3em'%3E${encodeURIComponent(generatedStartup.name.substring(0, 8))}%3C/text%3E%3Ccircle cx='100' cy='100' r='90' fill='none' stroke='rgba(255,255,255,0.3)' stroke-width='2' stroke-dasharray='10,5'/%3E%3C/svg%3E`;
      
      setGeneratedStartup(prev => prev ? {
        ...prev,
        logoUrl: logoSvg
      } : null);
      
      // Show success message
      alert(`🎨 Professional logo generated for ${generatedStartup.name}! This custom design reflects your startup's brand identity and values.`);
      
    } catch (error) {
      console.error('Logo generation error:', error);
      alert('Failed to generate logo. Please try again.');
    } finally {
      setIsGeneratingLogo(false);
    }
  };

  const handleGenerateAudioSummary = async () => {
    if (!generatedStartup) return;
    
    setIsGeneratingAudio(true);
    
    try {
      // Simulate audio generation with realistic timing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate audio using Web Speech API
      const audioUrl = await generateAudioSummary('Audio summary generated');
      
      setGeneratedStartup(prev => prev ? {
        ...prev,
        audioSummaryUrl: audioUrl
      } : null);
      
      // Show success message
      alert(`🎙️ AI audio summary generated for ${generatedStartup.name}! Click play to hear the professional narration.`);
      
    } catch (error) {
      console.error('Audio generation error:', error);
      alert('Failed to generate audio summary. Your browser may not support speech synthesis.');
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  const handleRecordToggle = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      // Mock recording for 3 seconds
      setTimeout(() => {
        setIsRecording(false);
        setDreamIdea(prev => prev + (prev ? " " : "") + "I want to create an innovative solution that helps people live better lives through technology and community engagement.");
      }, 3000);
    }
  };

  const handlePostToDiscover = () => {
    if (!generatedStartup) return;
    
    // Create a dream object to store
    const dreamPost = {
      id: Date.now().toString(),
      name: generatedStartup.name,
      summary: generatedStartup.summary,
      uniqueness: generatedStartup.uniqueness,
      strength: generatedStartup.strength,
      marketCheck: generatedStartup.marketCheck,
      tags: ['AI Generated', 'Startup', 'Innovation'],
      author: user?.fullName || 'Anonymous',
      avatar: user?.avatar || user?.fullName?.split(' ').map(n => n[0]).join('') || 'U',
      likes: 0,
      comments: 0,
      views: 0,
      createdAt: new Date().toISOString(),
      isPublished: true,
      logoUrl: generatedStartup.logoUrl,
      audioSummaryUrl: generatedStartup.audioSummaryUrl,
      originalIdea: dreamIdea
    };
    
    // Store in localStorage for the discover page and user dreams
    const existingPosts = JSON.parse(localStorage.getItem('dreamdrop_posts') || '[]');
    const userDreams = JSON.parse(localStorage.getItem(`dreamdrop_user_dreams_${user?.id}`) || '[]');
    
    existingPosts.unshift(dreamPost);
    userDreams.unshift(dreamPost);
    
    localStorage.setItem('dreamdrop_posts', JSON.stringify(existingPosts));
    localStorage.setItem(`dreamdrop_user_dreams_${user?.id}`, JSON.stringify(userDreams));
    
    setIsPosted(true);
    setTimeout(() => {
      setIsPosted(false);
      setGeneratedStartup(null);
      setDreamIdea('');
    }, 2000);
  };

  const handleShare = (platform: string) => {
    const text = `Check out my new startup idea: ${generatedStartup?.name} - ${generatedStartup?.summary.slice(0, 100)}...`;
    const url = window.location.href;
    
    switch (platform) {
      case 'linkedin':
        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}&title=${encodeURIComponent(text)}`);
        break;
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`);
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`);
        break;
    }
  };

  const handleStartAudio = () => {
    if (!generatedStartup) return;
    
    // Stop any current speech
    speechSynthesis.cancel();
    
    // Create the audio summary text
    const audioText = `Introducing ${generatedStartup.name}. ${generatedStartup.summary.substring(0, 200)}. This innovative solution targets ${generatedStartup.targetUsers} and offers ${generatedStartup.uniqueness.substring(0, 150)}. With ${generatedStartup.strength.toLowerCase()} market potential, ${generatedStartup.name} is positioned to revolutionize the industry.`;
    
    // Use Web Speech API to speak the text
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(audioText);
      
      // Configure voice settings
      utterance.rate = 0.9;
      utterance.pitch = 1.0;
      utterance.volume = 1.0;
      
      // Try to use a professional-sounding voice
      const voices = speechSynthesis.getVoices();
      const preferredVoice = voices.find(voice => 
        voice.name.includes('Google') || 
        voice.name.includes('Microsoft') ||
        voice.name.includes('Alex') ||
        voice.name.includes('Samantha')
      ) || voices[0];
      
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }
      
      utterance.onstart = () => {
        setIsPlayingAudio(true);
        setIsPausedAudio(false);
      };
      
      utterance.onend = () => {
        setIsPlayingAudio(false);
        setIsPausedAudio(false);
      };
      
      utterance.onerror = () => {
        setIsPlayingAudio(false);
        setIsPausedAudio(false);
        alert('Error playing audio. Please try again.');
      };
      
      speechRef.current = utterance;
      speechSynthesis.speak(utterance);
    } else {
      alert('Speech synthesis is not supported in your browser.');
    }
  };

  const handlePauseAudio = () => {
    if ('speechSynthesis' in window && speechSynthesis.speaking) {
      speechSynthesis.pause();
      setIsPausedAudio(true);
    }
  };

  const handleResumeAudio = () => {
    if ('speechSynthesis' in window && speechSynthesis.paused) {
      speechSynthesis.resume();
      setIsPausedAudio(false);
    }
  };

  const handleStopAudio = () => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
    }
    setIsPlayingAudio(false);
    setIsPausedAudio(false);
  };

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'Strong': return 'bg-green-100 text-green-700 border-green-200';
      case 'Moderate': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'Weak': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 py-8 pt-24 sm:pt-32 max-w-5xl">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-8">
          <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-6 rounded-full shadow-xl">
            <Lightbulb className="w-16 h-16 text-white" />
          </div>
        </div>
        <h1 className="text-4xl md:text-7xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-6">
          Drop Your Dream
        </h1>
        <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          Transform your brilliant idea into a complete startup concept with AI-powered insights, custom logo design, audio summaries, and market analysis.
        </p>
      </div>

      {/* Dream Limit Status */}
      {user && (
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8 border border-gray-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {user.isPro ? (
                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-3 rounded-xl">
                  <Crown className="w-6 h-6 text-white" />
                </div>
              ) : (
                <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-3 rounded-xl">
                  <Star className="w-6 h-6 text-white" />
                </div>
              )}
              <div>
                <h3 className="text-xl font-bold text-gray-800">
                  {user.isPro ? 'Pro Member' : 'Free Plan'}
                </h3>
                <p className="text-gray-600">
                  {user.isPro 
                    ? 'Unlimited dream submissions' 
                    : `${remainingDreams} dreams remaining out of 10`
                  }
                </p>
              </div>
            </div>
            
            {!user.isPro && (
              <button
                onClick={() => setShowUpgradeModal(true)}
                className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-yellow-600 hover:to-orange-700 transform hover:scale-105 transition-all duration-200 flex items-center gap-2"
              >
                <Crown className="w-5 h-5" />
                Upgrade to Pro
              </button>
            )}
          </div>
          
          {!user.isPro && remainingDreams <= 3 && (
            <div className="mt-4 bg-amber-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <p className="text-amber-800 font-semibold">
                  {remainingDreams === 0 
                    ? 'You\'ve reached your free limit! Upgrade to Pro for unlimited dreams.'
                    : `Only ${remainingDreams} dreams left! Upgrade to Pro for unlimited access.`
                  }
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Input Section */}
      <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 mb-8 border border-gray-100">
        <div className="space-y-8">
          {/* Text Input */}
          <div>
            <label className="block text-2xl font-bold text-gray-800 mb-6 flex items-center gap-3">
              <Brain className="w-8 h-8 text-purple-600" />
              Describe your dream startup idea
            </label>
            <textarea
              value={dreamIdea}
              onChange={(e) => setDreamIdea(e.target.value)}
              placeholder="I want to create an app that revolutionizes how people..."
              className="w-full h-40 p-6 border-3 border-gray-200 rounded-2xl focus:border-purple-500 focus:outline-none resize-none text-lg leading-relaxed"
              disabled={isGenerating}
            />
            <div className="mt-4 text-right">
              <span className="text-sm text-gray-500">{dreamIdea.length}/1000 characters</span>
            </div>
          </div>

          {/* Voice Input */}
          <div className="flex items-center justify-between p-8 bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl border-2 border-purple-100">
            <div>
              <h3 className="font-bold text-xl text-gray-800 mb-3 flex items-center gap-2">
                <Mic className="w-6 h-6 text-purple-600" />
                Record your voice
              </h3>
              <p className="text-gray-600 text-lg">Speak your idea and we'll transcribe it for you using advanced AI</p>
            </div>
            <button
              onClick={handleRecordToggle}
              disabled={isGenerating}
              className={`p-6 rounded-full transition-all duration-200 transform hover:scale-110 ${
                isRecording
                  ? 'bg-red-500 text-white animate-pulse shadow-xl'
                  : 'bg-gradient-to-r from-pink-500 to-purple-600 text-white hover:from-pink-600 hover:to-purple-700 shadow-lg'
              }`}
            >
              <Mic className="w-8 h-8" />
            </button>
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerateStartup}
            disabled={!dreamIdea.trim() || isGenerating || (!canSubmit && !user?.isPro)}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-6 px-8 rounded-2xl font-bold text-xl hover:from-pink-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 transition-all duration-200 flex items-center justify-center gap-4 shadow-xl"
          >
            {isGenerating ? (
              <>
                <Sparkles className="w-8 h-8 animate-spin" />
                AI is generating your unique startup...
              </>
            ) : !canSubmit && !user?.isPro ? (
              <>
                <Crown className="w-8 h-8" />
                Upgrade to Generate More Dreams
              </>
            ) : (
              <>
                <Rocket className="w-8 h-8" />
                Generate My Startup with AI
              </>
            )}
          </button>
        </div>
      </div>

      {/* Generated Results */}
      {generatedStartup && (
        <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 mb-8 animate-fade-in border border-gray-100">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center mb-6">
              <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-4 rounded-full shadow-xl">
                <Star className="w-12 h-12 text-white" />
              </div>
            </div>
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Your AI-Generated Startup</h2>
            <p className="text-xl text-gray-600">Here's your complete startup concept powered by AI</p>
          </div>

          <div className="grid gap-8">
            {/* Startup Name & Strength */}
            <div className="bg-gradient-to-r from-pink-50 to-purple-50 p-8 rounded-3xl border-2 border-pink-100">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <Lightbulb className="w-8 h-8 text-purple-600" />
                  <h3 className="text-2xl font-bold text-gray-800">Creative Startup Name</h3>
                </div>
                <div className={`px-4 py-2 rounded-full border-2 font-bold ${getStrengthColor(generatedStartup.strength)}`}>
                  {generatedStartup.strength} Idea
                </div>
              </div>
              <p className="text-4xl font-bold text-purple-600">{generatedStartup.name}</p>
            </div>

            {/* Focus Area */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-8 rounded-3xl border-2 border-blue-100">
              <div className="flex items-center gap-4 mb-4">
                <Target className="w-8 h-8 text-blue-600" />
                <h3 className="text-2xl font-bold text-gray-800">What You're Focusing On</h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">{generatedStartup.focus}</p>
            </div>

            {/* Target Users */}
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 p-8 rounded-3xl border-2 border-emerald-100">
              <div className="flex items-center gap-4 mb-4">
                <Users className="w-8 h-8 text-emerald-600" />
                <h3 className="text-2xl font-bold text-gray-800">Target Users</h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">{generatedStartup.targetUsers}</p>
            </div>

            {/* Startup Summary */}
            <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-8 rounded-3xl border-2 border-amber-100">
              <div className="flex items-center gap-4 mb-4">
                <Zap className="w-8 h-8 text-amber-600" />
                <h3 className="text-2xl font-bold text-gray-800">Complete Startup Summary</h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">{generatedStartup.summary}</p>
            </div>

            {/* Uniqueness Analysis */}
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-8 rounded-3xl border-2 border-purple-100">
              <div className="flex items-center gap-4 mb-4">
                <Star className="w-8 h-8 text-purple-600" />
                <h3 className="text-2xl font-bold text-gray-800">Uniqueness Analysis</h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">{generatedStartup.uniqueness}</p>
            </div>

            {/* Market Check */}
            <div className="bg-gradient-to-r from-rose-50 to-pink-50 p-8 rounded-3xl border-2 border-rose-100">
              <div className="flex items-center gap-4 mb-4">
                <TrendingUp className="w-8 h-8 text-rose-600" />
                <h3 className="text-2xl font-bold text-gray-800">Market Availability Check</h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">{generatedStartup.marketCheck}</p>
            </div>

            {/* Logo Generator & Audio Summary Section */}
            <div className="grid md:grid-cols-2 gap-8">
              {/* Logo Generator */}
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-8 rounded-3xl border-2 border-indigo-200">
                <div className="flex items-center gap-4 mb-6">
                  <Palette className="w-8 h-8 text-indigo-600" />
                  <h3 className="text-2xl font-bold text-gray-800">AI Logo Generator</h3>
                </div>
                
                {generatedStartup.logoUrl ? (
                  <div className="space-y-4">
                    <div className="bg-white rounded-2xl p-6 text-center border-2 border-indigo-100">
                      <img 
                        src={generatedStartup.logoUrl} 
                        alt={`${generatedStartup.name} Logo`}
                        className="w-32 h-32 mx-auto mb-4 rounded-xl shadow-lg"
                      />
                      <p className="text-sm font-semibold text-gray-800 mb-2">
                        🎨 {generatedStartup.name} Logo
                      </p>
                      <p className="text-xs text-gray-600">
                        Custom AI-generated brand identity
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={handleGenerateLogo}
                        disabled={isGeneratingLogo}
                        className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-xl font-semibold hover:bg-gray-200 transition-all duration-200 flex items-center justify-center gap-2"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Regenerate
                      </button>
                      <a
                        href={generatedStartup.logoUrl}
                        download={`${generatedStartup.name}-logo.svg`}
                        className="flex-1 bg-indigo-500 text-white py-2 rounded-xl font-semibold hover:bg-indigo-600 transition-all duration-200 flex items-center justify-center gap-2"
                      >
                        <Download className="w-4 h-4" />
                        Download
                      </a>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="bg-white rounded-2xl p-8 text-center relative overflow-hidden mb-4 border-2 border-indigo-100">
                      <div className="bg-gradient-to-r from-indigo-500/20 to-purple-500/20 absolute inset-0"></div>
                      <div className="relative z-10">
                        <div className="bg-indigo-500 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                          <Palette className="w-8 h-8 text-white" />
                        </div>
                        <p className="text-indigo-800 font-bold text-lg mb-2">🎨 Generate Custom Logo</p>
                        <p className="text-indigo-700 text-sm">AI-powered brand identity design</p>
                      </div>
                    </div>
                    <button
                      onClick={handleGenerateLogo}
                      disabled={isGeneratingLogo}
                      className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white py-3 rounded-xl font-semibold hover:from-indigo-600 hover:to-purple-700 disabled:opacity-50 transition-all duration-200 flex items-center justify-center gap-2"
                    >
                      {isGeneratingLogo ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                          Creating Logo...
                        </>
                      ) : (
                        <>
                          <Palette className="w-5 h-5" />
                          Generate Logo
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              {/* AI Audio Summary */}
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 p-8 rounded-3xl border-2 border-emerald-200">
                <div className="flex items-center gap-4 mb-6">
                  <Volume2 className="w-8 h-8 text-emerald-600" />
                  <h3 className="text-2xl font-bold text-gray-800">AI Audio Summary</h3>
                </div>
                
                {generatedStartup.audioSummaryUrl ? (
                  <div className="space-y-4">
                    <div className="bg-white rounded-2xl p-6 text-center border-2 border-emerald-100">
                      <div className="bg-emerald-500 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                        <Volume2 className="w-8 h-8 text-white" />
                      </div>
                      <p className="text-sm font-semibold text-gray-800 mb-2">
                        🎙️ {generatedStartup.name} Audio Summary
                      </p>
                      <p className="text-xs text-gray-600 mb-4">
                        AI narration • Professional voice
                      </p>
                      
                      {/* Audio Control Buttons */}
                      <div className="flex gap-2 mb-4">
                        {!isPlayingAudio ? (
                          <button
                            onClick={handleStartAudio}
                            className="flex-1 bg-emerald-500 text-white py-3 rounded-xl font-semibold hover:bg-emerald-600 transition-all duration-200 flex items-center justify-center gap-2"
                          >
                            <Play className="w-4 h-4" />
                            Start Audio
                          </button>
                        ) : (
                          <>
                            {!isPausedAudio ? (
                              <button
                                onClick={handlePauseAudio}
                                className="flex-1 bg-yellow-500 text-white py-3 rounded-xl font-semibold hover:bg-yellow-600 transition-all duration-200 flex items-center justify-center gap-2"
                              >
                                <Pause className="w-4 h-4" />
                                Pause
                              </button>
                            ) : (
                              <button
                                onClick={handleResumeAudio}
                                className="flex-1 bg-emerald-500 text-white py-3 rounded-xl font-semibold hover:bg-emerald-600 transition-all duration-200 flex items-center justify-center gap-2"
                              >
                                <Play className="w-4 h-4" />
                                Resume
                              </button>
                            )}
                            <button
                              onClick={handleStopAudio}
                              className="flex-1 bg-red-500 text-white py-3 rounded-xl font-semibold hover:bg-red-600 transition-all duration-200 flex items-center justify-center gap-2"
                            >
                              <Square className="w-4 h-4" />
                              Stop
                            </button>
                          </>
                        )}
                      </div>
                      
                      {/* Audio Status */}
                      {isPlayingAudio && (
                        <div className="bg-emerald-100 border border-emerald-200 rounded-lg p-3">
                          <div className="flex items-center justify-center gap-2">
                            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                            <span className="text-emerald-700 text-sm font-medium">
                              {isPausedAudio ? 'Audio Paused' : 'Playing Audio...'}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2">
                      <button
                        onClick={handleGenerateAudioSummary}
                        disabled={isGeneratingAudio}
                        className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-xl font-semibold hover:bg-gray-200 transition-all duration-200 flex items-center justify-center gap-2"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Regenerate
                      </button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="bg-white rounded-2xl p-8 text-center relative overflow-hidden mb-4 border-2 border-emerald-100">
                      <div className="bg-gradient-to-r from-emerald-500/20 to-teal-500/20 absolute inset-0"></div>
                      <div className="relative z-10">
                        <div className="bg-emerald-500 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                          <Volume2 className="w-8 h-8 text-white" />
                        </div>
                        <p className="text-emerald-800 font-bold text-lg mb-2">🎙️ Generate Audio Summary</p>
                        <p className="text-emerald-700 text-sm">AI-powered voice narration</p>
                      </div>
                    </div>
                    <button
                      onClick={handleGenerateAudioSummary}
                      disabled={isGeneratingAudio}
                      className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-3 rounded-xl font-semibold hover:from-emerald-600 hover:to-teal-700 disabled:opacity-50 transition-all duration-200 flex items-center justify-center gap-2"
                    >
                      {isGeneratingAudio ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                          Generating Audio...
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-5 h-5" />
                          Generate Audio
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Video Generation - Coming Soon */}
            <div className="grid md:grid-cols-2 gap-8">
              {/* Animated Video (Coming Soon) */}
              <div className="bg-gradient-to-r from-gray-50 to-slate-50 p-8 rounded-3xl border-2 border-gray-200 opacity-75">
                <div className="flex items-center gap-4 mb-6">
                  <Play className="w-8 h-8 text-gray-600" />
                  <h3 className="text-2xl font-bold text-gray-800">Animated Explainer</h3>
                </div>
                
                <div className="bg-gray-900 rounded-2xl p-8 text-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20"></div>
                  <div className="relative z-10">
                    <div className="bg-white/20 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                      <Play className="w-8 h-8 text-white" />
                    </div>
                    <p className="text-white font-semibold mb-2">🎬 Animated Video</p>
                    <p className="text-white/80 text-sm mb-4">3-5 min explainer • Coming Soon</p>
                    <div className="bg-yellow-500 text-black px-4 py-2 rounded-full text-sm font-bold">
                      Coming Soon
                    </div>
                  </div>
                </div>
              </div>

              {/* AI Pitch Video (Coming Soon) */}
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-8 rounded-3xl border-2 border-indigo-200 opacity-75">
                <div className="flex items-center gap-4 mb-6">
                  <Users className="w-8 h-8 text-indigo-600" />
                  <h3 className="text-2xl font-bold text-gray-800">AI Pitch Video</h3>
                </div>
                
                <div className="bg-gray-900 rounded-2xl p-8 text-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 to-purple-500/20"></div>
                  <div className="relative z-10">
                    <div className="bg-white/20 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                      <Users className="w-8 h-8 text-white" />
                    </div>
                    <p className="text-white font-semibold mb-2">🎥 AI Pitch Video</p>
                    <p className="text-white/80 text-sm mb-4">4 min pitch • Coming Soon</p>
                    <div className="bg-yellow-500 text-black px-4 py-2 rounded-full text-sm font-bold">
                      Coming Soon
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sharing Options */}
          <div className="mt-12 text-center">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Share Your Dream</h3>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              {/* Post to Discover */}
              <button
                onClick={handlePostToDiscover}
                disabled={isPosted}
                className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white py-4 px-8 rounded-2xl font-bold text-lg hover:from-emerald-600 hover:to-teal-700 disabled:opacity-50 transform hover:scale-105 transition-all duration-200 flex items-center justify-center gap-3 shadow-xl"
              >
                {isPosted ? (
                  <>
                    <Check className="w-6 h-6" />
                    Posted to Discover!
                  </>
                ) : (
                  <>
                    <ArrowRight className="w-6 h-6" />
                    Post to Discover Feed
                  </>
                )}
              </button>
            </div>

            {/* External Sharing */}
            <div className="flex flex-wrap justify-center gap-4">
              <button
                onClick={() => handleShare('linkedin')}
                className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transform hover:scale-105 transition-all duration-200"
              >
                <Linkedin className="w-5 h-5" />
                LinkedIn
              </button>
              
              <button
                onClick={() => handleShare('twitter')}
                className="flex items-center gap-2 bg-black text-white px-6 py-3 rounded-xl font-semibold hover:bg-gray-800 transform hover:scale-105 transition-all duration-200"
              >
                <Twitter className="w-5 h-5" />
                Twitter/X
              </button>
              
              <button
                onClick={() => handleShare('whatsapp')}
                className="flex items-center gap-2 bg-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-green-700 transform hover:scale-105 transition-all duration-200"
              >
                <MessageSquare className="w-5 h-5" />
                WhatsApp
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upgrade Modal */}
      <UpgradeModal 
        isOpen={showUpgradeModal} 
        onClose={() => setShowUpgradeModal(false)} 
      />
    </div>
  );
};

export default DropDreamPage;