"use client";

import { useState } from "react";

export default function HomePage() {
  const [dream, setDream] = useState("");
  const [idea, setIdea] = useState("");
  const [videoURL, setVideoURL] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    try {
      setLoading(true);

      const res1 = await fetch("/api/generateStartup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dream }),
      });
      const data1 = await res1.json();
      setIdea(data1.idea);

      const res2 = await fetch("/api/generateVideo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ script: data1.idea }),
      });
      const data2 = await res2.json();
      setVideoURL(data2.videoURL);
    } catch (err) {
      console.error("Something went wrong", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Drop Your Dream ✨</h1>
      <input
        value={dream}
        onChange={(e) => setDream(e.target.value)}
        placeholder="Describe your dream startup..."
        className="p-2 border rounded w-full"
      />
      <button
        onClick={handleSubmit}
        disabled={loading}
        className="mt-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
      >
        {loading ? "Generating..." : "Generate Startup"}
      </button>

      {idea && (
        <div className="mt-6">
          <h2 className="text-xl font-semibold">AI-Generated Idea:</h2>
          <p className="mt-2">{idea}</p>
        </div>
      )}

      {videoURL && (
        <div className="mt-6">
          <h2 className="text-xl font-semibold">Pitch Video:</h2>
          <video src={videoURL} controls className="w-full mt-2 rounded shadow" />
        </div>
      )}
    </div>
  );
}
