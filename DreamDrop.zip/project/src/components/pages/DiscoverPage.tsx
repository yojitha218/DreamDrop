import React, { useState, useEffect } from 'react';
import { Heart, MessageCircle, Share2, Play, Tag, User, Filter, Search, Star, Eye, Bookmark, TrendingUp, Volume2, Palette, Pause, Square } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import MessagingDrawer from '../MessagingDrawer';

interface DiscoverPost {
  id: string;
  name: string;
  summary: string;
  uniqueness: string;
  strength: 'Strong' | 'Moderate' | 'Weak';
  likes: number;
  comments: number;
  views: number;
  tags: string[];
  author: string;
  avatar: string;
  hasAnimatedVideo: boolean;
  hasPitchVideo: boolean;
  isLiked: boolean;
  isBookmarked: boolean;
  isFollowing: boolean;
  createdAt: string;
  category: string;
  logoUrl?: string;
  audioSummaryUrl?: string;
  originalIdea?: string;
}

interface DiscoverPageProps {
  userRole: 'innovator' | 'investor';
}

const DiscoverPage: React.FC<DiscoverPageProps> = ({ userRole }) => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [sortBy, setSortBy] = useState('trending');
  const [isMessagingOpen, setIsMessagingOpen] = useState(false);
  const [posts, setPosts] = useState<DiscoverPost[]>([]);
  const [playingAudio, setPlayingAudio] = useState<string | null>(null);
  const [pausedAudio, setPausedAudio] = useState<string | null>(null);

  // Load posts from localStorage and merge with default posts
  useEffect(() => {
    const defaultPosts: DiscoverPost[] = [
      {
        id: '1',
        name: 'EcoTrack Pro',
        summary: 'AI-powered carbon footprint tracker with community challenges and gamified eco-goals that helps users reduce their environmental impact through smart recommendations and social engagement.',
        uniqueness: 'First app to combine real-time environmental impact tracking with social gaming mechanics and AI-powered personalized sustainability recommendations.',
        strength: 'Strong',
        likes: 1247,
        comments: 89,
        views: 5420,
        tags: ['Environment', 'AI', 'Social', 'Sustainability'],
        author: 'Alex Chen',
        avatar: 'AC',
        hasAnimatedVideo: true,
        hasPitchVideo: true,
        isLiked: false,
        isBookmarked: false,
        isFollowing: false,
        createdAt: '2024-01-15',
        category: 'CleanTech'
      },
      {
        id: '2',
        name: 'PetPal Health',
        summary: 'Smart pet health monitoring platform with AI-powered symptom analysis, vet connections, and comprehensive health tracking for beloved pets.',
        uniqueness: 'Only platform combining wearable pet technology with telemedicine for animals and AI-driven health insights for preventive care.',
        strength: 'Strong',
        likes: 1156,
        comments: 67,
        views: 4890,
        tags: ['HealthTech', 'Pets', 'AI', 'Telemedicine'],
        author: 'Sarah Kim',
        avatar: 'SK',
        hasAnimatedVideo: true,
        hasPitchVideo: true,
        isLiked: true,
        isBookmarked: true,
        isFollowing: true,
        createdAt: '2024-01-20',
        category: 'HealthTech'
      },
      {
        id: '3',
        name: 'MoodSpace VR',
        summary: 'Virtual reality therapy platform with AI-guided meditation, stress relief programs, and personalized mental health protocols for modern wellness.',
        uniqueness: 'First VR mental health platform with personalized AI therapy protocols and immersive healing environments designed by psychologists.',
        strength: 'Strong',
        likes: 1089,
        comments: 54,
        views: 4320,
        tags: ['VR', 'Mental Health', 'AI', 'Wellness'],
        author: 'Mike Rodriguez',
        avatar: 'MR',
        hasAnimatedVideo: true,
        hasPitchVideo: true,
        isLiked: false,
        isBookmarked: false,
        isFollowing: false,
        createdAt: '2024-01-25',
        category: 'HealthTech'
      },
      {
        id: '4',
        name: 'FarmBot Connect',
        summary: 'IoT-enabled smart farming platform with automated crop monitoring, yield optimization, and sustainable agriculture management tools.',
        uniqueness: 'Revolutionary integration of drone surveillance with ground-based IoT sensors and AI-powered crop health analysis for precision farming.',
        strength: 'Moderate',
        likes: 967,
        comments: 42,
        views: 3890,
        tags: ['Agriculture', 'IoT', 'Automation', 'Sustainability'],
        author: 'Emma Johnson',
        avatar: 'EJ',
        hasAnimatedVideo: true,
        hasPitchVideo: true,
        isLiked: false,
        isBookmarked: false,
        isFollowing: false,
        createdAt: '2024-02-01',
        category: 'AgTech'
      },
      {
        id: '5',
        name: 'StudySync AI',
        summary: 'Personalized learning platform with AI tutors, collaborative study sessions, and adaptive curriculum for students and professionals.',
        uniqueness: 'First AI tutor that adapts to individual learning styles with real-time collaboration features and gamified progress tracking.',
        strength: 'Strong',
        likes: 834,
        comments: 38,
        views: 3210,
        tags: ['EdTech', 'AI', 'Collaboration', 'Learning'],
        author: 'David Park',
        avatar: 'DP',
        hasAnimatedVideo: true,
        hasPitchVideo: false,
        isLiked: false,
        isBookmarked: true,
        isFollowing: false,
        createdAt: '2024-02-05',
        category: 'EdTech'
      },
      {
        id: '6',
        name: 'WasteWise',
        summary: 'Smart waste management system for cities with predictive collection routes, IoT sensors, and sustainability analytics for municipal efficiency.',
        uniqueness: 'First smart city solution combining predictive analytics with IoT waste sensors and citizen engagement for optimal waste management.',
        strength: 'Moderate',
        likes: 756,
        comments: 29,
        views: 2890,
        tags: ['Smart Cities', 'IoT', 'Sustainability', 'Analytics'],
        author: 'Maria Santos',
        avatar: 'MS',
        hasAnimatedVideo: false,
        hasPitchVideo: true,
        isLiked: false,
        isBookmarked: false,
        isFollowing: false,
        createdAt: '2024-02-10',
        category: 'Smart Cities'
      }
    ];

    // Load user-posted dreams from localStorage
    const userPosts = JSON.parse(localStorage.getItem('dreamdrop_posts') || '[]');
    
    // Merge user posts with default posts, user posts first
    const allPosts = [...userPosts, ...defaultPosts];
    setPosts(allPosts);
  }, []);

  const handleLike = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { ...post, likes: post.isLiked ? post.likes - 1 : post.likes + 1, isLiked: !post.isLiked }
        : post
    ));
  };

  const handleBookmark = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { ...post, isBookmarked: !post.isBookmarked }
        : post
    ));
  };

  const handleFollow = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { ...post, isFollowing: !post.isFollowing }
        : post
    ));
  };

  const handleMessageClick = () => {
    setIsMessagingOpen(true);
  };

  const handleStartAudio = (post: DiscoverPost) => {
    // Stop any currently playing audio
    if (playingAudio) {
      speechSynthesis.cancel();
      setPlayingAudio(null);
      setPausedAudio(null);
    }

    // If clicking the same post that was playing, just stop
    if (playingAudio === post.id) {
      return;
    }

    // Check if speech synthesis is supported
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported in your browser.');
      return;
    }

    setPlayingAudio(post.id);
    setPausedAudio(null);

    // Create the audio summary text
    const audioText = `Introducing ${post.name}. ${post.summary.substring(0, 200)}. This innovative solution offers ${post.uniqueness.substring(0, 150)}. With ${post.strength.toLowerCase()} market potential, ${post.name} is positioned to make a significant impact.`;

    const utterance = new SpeechSynthesisUtterance(audioText);
    
    // Configure voice settings
    utterance.rate = 0.9;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    
    // Try to use a professional-sounding voice
    const voices = speechSynthesis.getVoices();
    const preferredVoice = voices.find(voice => 
      voice.name.includes('Google') || 
      voice.name.includes('Microsoft') ||
      voice.name.includes('Alex') ||
      voice.name.includes('Samantha')
    ) || voices[0];
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }
    
    utterance.onend = () => {
      setPlayingAudio(null);
      setPausedAudio(null);
    };
    
    utterance.onerror = () => {
      setPlayingAudio(null);
      setPausedAudio(null);
      alert('Error playing audio. Please try again.');
    };
    
    // Start speaking
    speechSynthesis.speak(utterance);
  };

  const handlePauseAudio = (postId: string) => {
    if ('speechSynthesis' in window && speechSynthesis.speaking) {
      speechSynthesis.pause();
      setPausedAudio(postId);
    }
  };

  const handleResumeAudio = (postId: string) => {
    if ('speechSynthesis' in window && speechSynthesis.paused) {
      speechSynthesis.resume();
      setPausedAudio(null);
    }
  };

  const handleStopAudio = () => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
    }
    setPlayingAudio(null);
    setPausedAudio(null);
  };

  const getStrengthColor = (strength: string) => {
    switch (strength) {
      case 'Strong': return 'bg-green-100 text-green-700 border-green-200';
      case 'Moderate': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'Weak': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())) ||
                         post.author.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (selectedFilter === 'all') return matchesSearch;
    return matchesSearch && post.tags.some(tag => tag.toLowerCase() === selectedFilter.toLowerCase());
  });

  // Sort posts
  const sortedPosts = [...filteredPosts].sort((a, b) => {
    switch (sortBy) {
      case 'trending':
        return b.likes - a.likes;
      case 'newest':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case 'most-liked':
        return b.likes - a.likes;
      case 'most-viewed':
        return b.views - a.views;
      default:
        return 0;
    }
  });

  const filters = ['all', 'ai', 'healthtech', 'environment', 'edtech', 'iot', 'vr'];
  const sortOptions = [
    { value: 'trending', label: 'Trending' },
    { value: 'newest', label: 'Newest' },
    { value: 'most-liked', label: 'Most Liked' },
    { value: 'most-viewed', label: 'Most Viewed' }
  ];

  return (
    <>
      <div className="container mx-auto px-4 sm:px-6 py-8 pt-24 sm:pt-32 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8 sm:mb-12">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-4">
            {userRole === 'investor' ? 'Investment Opportunities' : 'Discover Dreams'}
          </h1>
          <p className="text-lg sm:text-xl text-gray-600 px-4">
            {userRole === 'investor' 
              ? 'Find your next investment opportunity among innovative startup ideas'
              : 'Explore amazing startup concepts from fellow innovators'
            }
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-2xl shadow-lg p-4 sm:p-6 mb-6 sm:mb-8 border border-gray-100">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search dreams, tags, or innovators..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={selectedFilter}
                onChange={(e) => setSelectedFilter(e.target.value)}
                className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none bg-white"
              >
                {filters.map(filter => (
                  <option key={filter} value={filter}>
                    {filter === 'all' ? 'All Categories' : filter.toUpperCase()}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-gray-400" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none bg-white"
              >
                {sortOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Results Summary */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-gray-600">
            Showing {sortedPosts.length} of {posts.length} dreams
            {searchTerm && ` for "${searchTerm}"`}
          </p>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <span>Sort by:</span>
            <span className="font-semibold text-purple-600">
              {sortOptions.find(opt => opt.value === sortBy)?.label}
            </span>
          </div>
        </div>

        {/* Posts Grid */}
        <div className="grid gap-6 sm:gap-8">
          {sortedPosts.map((post) => (
            <div key={post.id} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden relative border border-gray-100">
              {/* Floating Action Buttons */}
              <div className="absolute top-4 right-4 z-10 flex gap-2">
                <button
                  onClick={() => handleBookmark(post.id)}
                  className={`p-3 rounded-full shadow-lg hover:shadow-xl transform hover:scale-110 transition-all duration-200 ${
                    post.isBookmarked ? 'bg-yellow-500 text-white' : 'bg-white text-gray-600 hover:text-yellow-500'
                  }`}
                  title="Bookmark"
                >
                  <Bookmark className={`w-5 h-5 ${post.isBookmarked ? 'fill-current' : ''}`} />
                </button>
                <button
                  onClick={handleMessageClick}
                  className="bg-gradient-to-r from-pink-500 to-purple-600 text-white p-3 rounded-full shadow-lg hover:shadow-xl transform hover:scale-110 transition-all duration-200"
                  title="Start conversation"
                >
                  <MessageCircle className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 sm:p-8">
                {/* Header */}
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-4 flex-1 min-w-0">
                    <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">
                      {post.avatar}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-3 mb-2 flex-wrap">
                        <h3 className="text-xl sm:text-2xl font-bold text-gray-800 break-words">{post.name}</h3>
                        <div className={`px-3 py-1 rounded-full border font-bold text-sm ${getStrengthColor(post.strength)}`}>
                          {post.strength}
                        </div>
                        <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
                          {post.category}
                        </span>
                      </div>
                      <p className="text-gray-600">by {post.author}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 flex-shrink-0 ml-4">
                    <div className="text-center">
                      <div className="flex items-center gap-1 text-pink-500 mb-1">
                        <Heart className={`w-5 h-5 ${post.isLiked ? 'fill-current' : ''}`} />
                        <span className="font-semibold">{post.likes.toLocaleString()}</span>
                      </div>
                      <div className="text-xs text-gray-500">likes</div>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center gap-1 text-blue-500 mb-1">
                        <Eye className="w-5 h-5" />
                        <span className="font-semibold">{post.views.toLocaleString()}</span>
                      </div>
                      <div className="text-xs text-gray-500">views</div>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="mb-6">
                  <p className="text-gray-700 text-base sm:text-lg leading-relaxed mb-4 break-words">{post.summary}</p>
                  <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-xl border border-purple-100">
                    <h4 className="font-semibold text-purple-800 mb-2 flex items-center gap-2">
                      <Star className="w-4 h-4" />
                      What makes it unique:
                    </h4>
                    <p className="text-purple-700 break-words">{post.uniqueness}</p>
                  </div>
                </div>

                {/* Logo and Audio Section */}
                {(post.logoUrl || post.audioSummaryUrl) && (
                  <div className="grid md:grid-cols-2 gap-4 mb-6">
                    {/* Logo Display */}
                    {post.logoUrl && (
                      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-4 text-center border border-indigo-100">
                        <div className="flex items-center gap-2 mb-3">
                          <Palette className="w-4 h-4 text-indigo-600" />
                          <span className="text-indigo-800 font-semibold text-sm">Custom Logo</span>
                        </div>
                        <img 
                          src={post.logoUrl} 
                          alt={`${post.name} Logo`}
                          className="w-16 h-16 mx-auto rounded-lg shadow-sm"
                        />
                      </div>
                    )}

                    {/* Audio Summary */}
                    {post.audioSummaryUrl && (
                      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl p-4 text-center border border-emerald-100">
                        <div className="flex items-center gap-2 mb-3">
                          <Volume2 className="w-4 h-4 text-emerald-600" />
                          <span className="text-emerald-800 font-semibold text-sm">AI Audio Summary</span>
                        </div>
                        
                        {/* Audio Control Buttons */}
                        <div className="flex gap-1">
                          {playingAudio !== post.id ? (
                            <button
                              onClick={() => handleStartAudio(post)}
                              className="flex-1 bg-emerald-500 text-white py-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-1 text-sm hover:bg-emerald-600"
                            >
                              <Play className="w-3 h-3" />
                              Start
                            </button>
                          ) : (
                            <>
                              {pausedAudio !== post.id ? (
                                <button
                                  onClick={() => handlePauseAudio(post.id)}
                                  className="flex-1 bg-yellow-500 text-white py-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-1 text-sm hover:bg-yellow-600"
                                >
                                  <Pause className="w-3 h-3" />
                                  Pause
                                </button>
                              ) : (
                                <button
                                  onClick={() => handleResumeAudio(post.id)}
                                  className="flex-1 bg-emerald-500 text-white py-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-1 text-sm hover:bg-emerald-600"
                                >
                                  <Play className="w-3 h-3" />
                                  Resume
                                </button>
                              )}
                              <button
                                onClick={handleStopAudio}
                                className="flex-1 bg-red-500 text-white py-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-1 text-sm hover:bg-red-600"
                              >
                                <Square className="w-3 h-3" />
                                Stop
                              </button>
                            </>
                          )}
                        </div>
                        
                        {/* Audio Status */}
                        {playingAudio === post.id && (
                          <div className="mt-2 bg-emerald-100 border border-emerald-200 rounded-lg p-2">
                            <div className="flex items-center justify-center gap-1">
                              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                              <span className="text-emerald-700 text-xs font-medium">
                                {pausedAudio === post.id ? 'Paused' : 'Playing...'}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Videos Section */}
                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  {/* Animated Video (Coming Soon) */}
                  {post.hasAnimatedVideo && (
                    <div className="bg-gray-900 rounded-xl p-6 text-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20"></div>
                      <div className="relative z-10">
                        <div className="bg-white/20 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                          <Play className="w-6 h-6 text-white" />
                        </div>
                        <p className="text-white font-semibold mb-1">🎬 Animated Explainer</p>
                        <p className="text-white/80 text-sm mb-2">3-5 min • Coming Soon</p>
                        <div className="bg-yellow-500 text-black px-3 py-1 rounded-full text-xs font-bold">
                          Coming Soon
                        </div>
                      </div>
                    </div>
                  )}

                  {/* AI Pitch Video (Coming Soon) - Only for Investors */}
                  {userRole === 'investor' && post.hasPitchVideo && (
                    <div className="bg-gray-900 rounded-xl p-6 text-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 to-purple-500/20"></div>
                      <div className="relative z-10">
                        <div className="bg-white/20 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                          <User className="w-6 h-6 text-white" />
                        </div>
                        <p className="text-white font-semibold mb-1">🎥 AI Pitch Video</p>
                        <p className="text-white/80 text-sm mb-2">4 min • Coming Soon</p>
                        <div className="bg-yellow-500 text-black px-3 py-1 rounded-full text-xs font-bold">
                          Coming Soon
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {post.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="bg-gradient-to-r from-pink-100 to-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1 hover:from-pink-200 hover:to-purple-200 transition-all duration-200 cursor-pointer"
                    >
                      <Tag className="w-3 h-3" />
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-6 border-t border-gray-100 flex-wrap gap-4">
                  <div className="flex items-center gap-4 flex-wrap">
                    <button
                      onClick={() => handleLike(post.id)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-200 ${
                        post.isLiked
                          ? 'bg-pink-100 text-pink-600'
                          : 'bg-gray-100 text-gray-600 hover:bg-pink-50 hover:text-pink-600'
                      }`}
                    >
                      <Heart className={`w-5 h-5 ${post.isLiked ? 'fill-current' : ''}`} />
                      <span className="font-medium">{post.isLiked ? 'Liked' : 'Like'}</span>
                    </button>
                    
                    <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition-all duration-200">
                      <MessageCircle className="w-5 h-5" />
                      <span className="font-medium">Comment ({post.comments})</span>
                    </button>
                    
                    <button
                      onClick={() => handleFollow(post.id)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-200 ${
                        post.isFollowing
                          ? 'bg-purple-100 text-purple-600'
                          : 'bg-gray-100 text-gray-600 hover:bg-purple-50 hover:text-purple-600'
                      }`}
                    >
                      <User className="w-5 h-5" />
                      <span className="font-medium">{post.isFollowing ? 'Following' : 'Follow'}</span>
                    </button>
                    
                    <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-600 hover:bg-green-50 hover:text-green-600 transition-all duration-200">
                      <Share2 className="w-5 h-5" />
                      <span className="font-medium">Share</span>
                    </button>
                  </div>

                  <div className="text-sm text-gray-500">
                    {new Date(post.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {sortedPosts.length === 0 && (
          <div className="text-center py-12">
            <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Search className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">No dreams found</h3>
            <p className="text-gray-600 mb-6">Try adjusting your search or filter criteria</p>
            <button 
              onClick={() => {
                setSearchTerm('');
                setSelectedFilter('all');
              }}
              className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-purple-700 transition-all duration-200"
            >
              Clear Filters
            </button>
          </div>
        )}

        {/* Load More */}
        {sortedPosts.length > 0 && (
          <div className="text-center mt-12">
            <button className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-pink-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-200">
              Load More Dreams
            </button>
          </div>
        )}
      </div>

      {/* Messaging Drawer */}
      <MessagingDrawer 
        isOpen={isMessagingOpen} 
        onClose={() => setIsMessagingOpen(false)} 
      />
    </>
  );
};

export default DiscoverPage;