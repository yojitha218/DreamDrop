import React from 'react';
import { Lightbulb, TrendingUp, Users, Zap, Star, Heart, ArrowRight, Sparkles, Rocket, Target, Award, Gamepad2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Page } from '../MainApp';

interface HomePageProps {
  userRole: 'innovator' | 'investor';
  onPageChange: (page: Page) => void;
}

const HomePage: React.FC<HomePageProps> = ({ userRole, onPageChange }) => {
  const { user } = useAuth();

  const stats = [
    { label: 'Dreams Dropped', value: '12,450', icon: Lightbulb, color: 'from-pink-500 to-rose-500' },
    { label: 'Active Investors', value: '3,280', icon: TrendingUp, color: 'from-purple-500 to-indigo-500' },
    { label: 'Successful Matches', value: '892', icon: Users, color: 'from-blue-500 to-cyan-500' },
    { label: 'Ideas Funded', value: '156', icon: Star, color: 'from-emerald-500 to-teal-500' },
  ];

  const recentActivity = [
    { user: 'Alex Chen', action: 'dropped a new dream', idea: 'AI-powered plant care assistant', time: '2 hours ago', type: 'dream' },
    { user: 'Sarah Johnson', action: 'invested in', idea: 'Sustainable packaging solution', time: '4 hours ago', type: 'investment' },
    { user: 'Mike Rodriguez', action: 'ranked #1 with', idea: 'Virtual reality fitness platform', time: '6 hours ago', type: 'ranking' },
    { user: 'Emma Thompson', action: 'dropped a new dream', idea: 'Pet health monitoring app', time: '8 hours ago', type: 'dream' },
  ];

  // Technology tools used in the platform
  const techStack = [
    { name: 'OpenAI', description: 'AI startup generation', icon: '🤖', color: 'from-green-500 to-emerald-600' },
    { name: 'Tavus', description: 'AI pitch videos', icon: '🎥', color: 'from-blue-500 to-indigo-600' },
    { name: 'Pica Labs', description: 'Animated videos', icon: '🎬', color: 'from-purple-500 to-violet-600' },
    { name: 'Supabase', description: 'Database & auth', icon: '🗄️', color: 'from-emerald-500 to-teal-600' },
    { name: 'RevenueCat', description: 'Subscriptions', icon: '💳', color: 'from-orange-500 to-red-600' },
    { name: 'React', description: 'Modern UI', icon: '⚛️', color: 'from-cyan-500 to-blue-600' }
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'dream': return <Lightbulb className="w-5 h-5 text-pink-500" />;
      case 'investment': return <TrendingUp className="w-5 h-5 text-emerald-500" />;
      case 'ranking': return <Award className="w-5 h-5 text-yellow-500" />;
      default: return <Star className="w-5 h-5 text-purple-500" />;
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 py-8 pt-24 sm:pt-32">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 rounded-3xl p-6 sm:p-8 md:p-12 text-white mb-8 sm:mb-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 sm:w-40 h-32 sm:h-40 bg-white/10 rounded-full -translate-y-16 sm:-translate-y-20 translate-x-16 sm:translate-x-20"></div>
        <div className="absolute bottom-0 left-0 w-24 sm:w-32 h-24 sm:h-32 bg-white/10 rounded-full translate-y-12 sm:translate-y-16 -translate-x-12 sm:-translate-x-16"></div>
        <div className="absolute top-1/2 right-6 sm:right-10 opacity-30">
          <Rocket className="w-12 h-12 sm:w-16 sm:h-16 text-white animate-pulse" />
        </div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 sm:gap-4 mb-4 sm:mb-6">
            <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 animate-pulse" />
            <h1 className="text-2xl sm:text-3xl md:text-6xl font-bold">
              Welcome back, {user?.fullName || (userRole === 'innovator' ? 'Innovator' : 'Investor')}!
            </h1>
          </div>
          
          <p className="text-lg sm:text-xl md:text-2xl text-white/90 mb-6 sm:mb-8 max-w-3xl leading-relaxed">
            {userRole === 'innovator' 
              ? "Ready to turn your next brilliant idea into a startup? The world is waiting for your innovation. Let's make dreams reality."
              : "Discover the next unicorn startup. Connect with brilliant innovators and fuel the future of technology and innovation."
            }
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
            {userRole === 'innovator' && (
              <button 
                onClick={() => onPageChange('drop-dream')}
                className="bg-white text-purple-600 px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-base sm:text-lg hover:bg-gray-50 transform hover:scale-105 transition-all duration-200 flex items-center justify-center gap-3 shadow-xl group"
              >
                <Lightbulb className="w-5 h-5 sm:w-6 sm:h-6 group-hover:animate-pulse" />
                Drop Your Dream
                <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            )}
            <button 
              onClick={() => onPageChange('discover')}
              className="border-3 border-white text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-base sm:text-lg hover:bg-white hover:text-purple-600 transform hover:scale-105 transition-all duration-200 flex items-center justify-center gap-3 shadow-xl group"
            >
              <Target className="w-5 h-5 sm:w-6 sm:h-6 group-hover:animate-pulse" />
              {userRole === 'innovator' ? 'Explore Community' : 'Explore Opportunities'}
            </button>
            <button 
              onClick={() => onPageChange('fun-zone')}
              className="bg-white/20 backdrop-blur-sm text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-base sm:text-lg hover:bg-white/30 transform hover:scale-105 transition-all duration-200 flex items-center justify-center gap-3 shadow-xl group"
            >
              <Gamepad2 className="w-5 h-5 sm:w-6 sm:h-6 group-hover:animate-pulse" />
              Fun Zone
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8 sm:mb-12">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 lg:p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100">
              <div className={`bg-gradient-to-r ${stat.color} p-3 sm:p-4 rounded-2xl w-fit mb-4 sm:mb-6`}>
                <Icon className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
              </div>
              <div className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-800 mb-2">{stat.value}</div>
              <div className="text-gray-600 font-semibold text-sm sm:text-base lg:text-lg">{stat.label}</div>
            </div>
          );
        })}
      </div>

      {/* Recent Activity & Quick Actions */}
      <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 mb-8 sm:mb-12">
        <div className="bg-white rounded-2xl sm:rounded-3xl shadow-xl p-6 sm:p-8 border border-gray-100">
          <div className="flex items-center gap-3 sm:gap-4 mb-6 sm:mb-8">
            <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-3 rounded-2xl">
              <Zap className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">Recent Activity</h2>
          </div>
          
          <div className="space-y-4 sm:space-y-6">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start gap-3 sm:gap-4 p-4 sm:p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl hover:from-purple-100 hover:to-pink-100 transition-all duration-200 border border-purple-100">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm sm:text-lg flex-shrink-0">
                  {activity.user.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    {getActivityIcon(activity.type)}
                    <p className="text-gray-800 font-semibold text-sm sm:text-base">
                      <span className="font-bold">{activity.user}</span> {activity.action}
                    </p>
                  </div>
                  <p className="text-purple-600 font-bold text-base sm:text-lg mb-1 break-words">"{activity.idea}"</p>
                  <p className="text-xs sm:text-sm text-gray-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-2xl sm:rounded-3xl shadow-xl p-6 sm:p-8 border border-gray-100">
          <div className="flex items-center gap-3 sm:gap-4 mb-6 sm:mb-8">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-3 rounded-2xl">
              <Heart className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">Quick Actions</h2>
          </div>
          
          <div className="space-y-4 sm:space-y-6">
            {userRole === 'innovator' ? (
              <>
                <button 
                  onClick={() => onPageChange('drop-dream')}
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white p-4 sm:p-6 rounded-2xl font-bold text-base sm:text-lg hover:from-pink-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-200 text-left flex items-center gap-3 sm:gap-4 shadow-lg"
                >
                  <Lightbulb className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0" />
                  <div>
                    <div className="text-lg sm:text-xl">💡 Drop a New Dream</div>
                    <div className="text-sm opacity-90">Transform your idea into a startup</div>
                  </div>
                </button>
                <button 
                  onClick={() => onPageChange('discover')}
                  className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white p-4 sm:p-6 rounded-2xl font-bold text-base sm:text-lg hover:from-blue-600 hover:to-indigo-700 transform hover:scale-105 transition-all duration-200 text-left flex items-center gap-3 sm:gap-4 shadow-lg"
                >
                  <Users className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0" />
                  <div>
                    <div className="text-lg sm:text-xl">🔍 Browse Community</div>
                    <div className="text-sm opacity-90">Discover amazing ideas</div>
                  </div>
                </button>
                <button 
                  onClick={() => onPageChange('fun-zone')}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white p-4 sm:p-6 rounded-2xl font-bold text-base sm:text-lg hover:from-purple-600 hover:to-pink-700 transform hover:scale-105 transition-all duration-200 text-left flex items-center gap-3 sm:gap-4 shadow-lg"
                >
                  <Gamepad2 className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0" />
                  <div>
                    <div className="text-lg sm:text-xl">🎮 Fun Zone</div>
                    <div className="text-sm opacity-90">Play games & create memes</div>
                  </div>
                </button>
                <button 
                  onClick={() => onPageChange('rankings')}
                  className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white p-4 sm:p-6 rounded-2xl font-bold text-base sm:text-lg hover:from-emerald-600 hover:to-teal-700 transform hover:scale-105 transition-all duration-200 text-left flex items-center gap-3 sm:gap-4 shadow-lg"
                >
                  <Award className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0" />
                  <div>
                    <div className="text-lg sm:text-xl">🏆 Check Rankings</div>
                    <div className="text-sm opacity-90">See how you rank</div>
                  </div>
                </button>
              </>
            ) : (
              <>
                <button 
                  onClick={() => onPageChange('discover')}
                  className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 text-white p-4 sm:p-6 rounded-2xl font-bold text-base sm:text-lg hover:from-purple-600 hover:to-indigo-700 transform hover:scale-105 transition-all duration-200 text-left flex items-center gap-3 sm:gap-4 shadow-lg"
                >
                  <Rocket className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0" />
                  <div>
                    <div className="text-lg sm:text-xl">🚀 Explore Top Ideas</div>
                    <div className="text-sm opacity-90">Find your next investment</div>
                  </div>
                </button>
                <button 
                  onClick={() => onPageChange('investors')}
                  className="w-full bg-gradient-to-r from-pink-500 to-rose-600 text-white p-4 sm:p-6 rounded-2xl font-bold text-base sm:text-lg hover:from-pink-600 hover:to-rose-700 transform hover:scale-105 transition-all duration-200 text-left flex items-center gap-3 sm:gap-4 shadow-lg"
                >
                  <TrendingUp className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0" />
                  <div>
                    <div className="text-lg sm:text-xl">💼 Investment Portal</div>
                    <div className="text-sm opacity-90">Browse opportunities</div>
                  </div>
                </button>
                <button 
                  onClick={() => onPageChange('fun-zone')}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white p-4 sm:p-6 rounded-2xl font-bold text-base sm:text-lg hover:from-purple-600 hover:to-pink-700 transform hover:scale-105 transition-all duration-200 text-left flex items-center gap-3 sm:gap-4 shadow-lg"
                >
                  <Gamepad2 className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0" />
                  <div>
                    <div className="text-lg sm:text-xl">🎮 Fun Zone</div>
                    <div className="text-sm opacity-90">Games & community fun</div>
                  </div>
                </button>
                <button 
                  onClick={() => onPageChange('rankings')}
                  className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white p-4 sm:p-6 rounded-2xl font-bold text-base sm:text-lg hover:from-amber-600 hover:to-orange-700 transform hover:scale-105 transition-all duration-200 text-left flex items-center gap-3 sm:gap-4 shadow-lg"
                >
                  <Star className="w-6 h-6 sm:w-8 sm:h-8 flex-shrink-0" />
                  <div>
                    <div className="text-lg sm:text-xl">📊 Market Trends</div>
                    <div className="text-sm opacity-90">Analyze top performers</div>
                  </div>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Technology Stack */}
      <div className="text-center">
        <div className="flex items-center justify-center gap-3 mb-6 sm:mb-8">
          <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" />
          <p className="text-gray-600 text-lg sm:text-xl font-bold">Built with Modern Technology</p>
          <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6 max-w-6xl mx-auto">
          {techStack.map((tech, index) => (
            <div
              key={tech.name}
              className="bg-white rounded-2xl p-4 sm:p-6 lg:p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 flex flex-col items-center justify-center border border-gray-100 group"
            >
              <div className={`bg-gradient-to-r ${tech.color} p-3 rounded-xl mb-3 group-hover:scale-110 transition-transform duration-200`}>
                <span className="text-2xl">{tech.icon}</span>
              </div>
              <span className="text-gray-700 font-bold text-base sm:text-lg lg:text-xl mb-1">{tech.name}</span>
              <span className="text-gray-500 text-xs sm:text-sm text-center">{tech.description}</span>
            </div>
          ))}
        </div>
        <div className="mt-6">
          <p className="text-gray-500 text-sm">
            Powered by cutting-edge AI and development tools for the best user experience
          </p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;