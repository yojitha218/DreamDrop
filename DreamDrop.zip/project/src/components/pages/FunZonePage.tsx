import React, { useState, useEffect } from 'react';
import { Gamepad2, Trophy, Users, Star, ArrowLeft, Play, Shuffle, Lightbulb, Brain, Smile, Volume2, VolumeX, Share2, Heart, RotateCcw, HelpCircle, Zap, Target, Award, Crown, Sparkles } from 'lucide-react';

interface FunZonePageProps {
  userRole: 'innovator' | 'investor';
}

interface Joke {
  id: number;
  setup: string;
  punchline: string;
  category: 'startup' | 'tech' | 'business' | 'general';
  rating: number;
  author: string;
  isFavorite: boolean;
}

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  category: string;
}

interface WordScramble {
  id: number;
  word: string;
  scrambled: string;
  hint: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

const FunZonePage: React.FC<FunZonePageProps> = ({ userRole }) => {
  const [currentGame, setCurrentGame] = useState<string>('home');
  const [soundEnabled, setSoundEnabled] = useState(true);
  
  // Joke state
  const [jokes, setJokes] = useState<Joke[]>([]);
  const [currentJoke, setCurrentJoke] = useState<Joke | null>(null);
  const [jokeCategory, setJokeCategory] = useState<string>('all');
  const [showPunchline, setShowPunchline] = useState(false);
  
  // Quiz state
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<QuizQuestion | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  
  // Word Scramble state
  const [wordScrambles, setWordScrambles] = useState<WordScramble[]>([]);
  const [currentScramble, setCurrentScramble] = useState<WordScramble | null>(null);
  const [userAnswer, setUserAnswer] = useState('');
  const [showHint, setShowHint] = useState(false);
  const [scrambleScore, setScrambleScore] = useState(0);
  const [wordsCompleted, setWordsCompleted] = useState(0);

  // Initialize data
  useEffect(() => {
    initializeJokes();
    initializeQuizQuestions();
    initializeWordScrambles();
  }, []);

  const initializeJokes = () => {
    const jokeData: Joke[] = [
      {
        id: 1,
        setup: "Why did the startup founder break up with their MVP?",
        punchline: "Because it wasn't scalable enough for their relationship!",
        category: 'startup',
        rating: 4.2,
        author: 'TechHumor',
        isFavorite: false
      },
      {
        id: 2,
        setup: "What's the difference between a startup and a pizza?",
        punchline: "A pizza can actually feed a family of four!",
        category: 'startup',
        rating: 4.5,
        author: 'StartupJokes',
        isFavorite: false
      },
      {
        id: 3,
        setup: "Why don't AI developers ever get lonely?",
        punchline: "Because they always have their neural networks to talk to!",
        category: 'tech',
        rating: 4.1,
        author: 'CodeComedy',
        isFavorite: false
      },
      {
        id: 4,
        setup: "How many venture capitalists does it take to change a light bulb?",
        punchline: "None. They just pivot to candles and call it 'disrupting the lighting industry'!",
        category: 'business',
        rating: 4.7,
        author: 'VCHumor',
        isFavorite: false
      },
      {
        id: 5,
        setup: "Why did the programmer quit their job?",
        punchline: "Because they didn't get arrays! (a raise)",
        category: 'tech',
        rating: 3.9,
        author: 'DevJokes',
        isFavorite: false
      },
      {
        id: 6,
        setup: "What do you call a startup that sells trampolines?",
        punchline: "A bounce house with a business model!",
        category: 'startup',
        rating: 4.0,
        author: 'BizHumor',
        isFavorite: false
      },
      {
        id: 7,
        setup: "Why don't entrepreneurs ever get tired?",
        punchline: "Because they're always pivoting!",
        category: 'business',
        rating: 4.3,
        author: 'EntrepreneurJokes',
        isFavorite: false
      },
      {
        id: 8,
        setup: "What's a developer's favorite type of music?",
        punchline: "Algo-rhythms!",
        category: 'tech',
        rating: 4.4,
        author: 'TechPuns',
        isFavorite: false
      }
    ];
    setJokes(jokeData);
  };

  const initializeQuizQuestions = () => {
    const questions: QuizQuestion[] = [
      {
        id: 1,
        question: "What does MVP stand for in startup terminology?",
        options: ["Most Valuable Player", "Minimum Viable Product", "Maximum Value Proposition", "Major Venture Partner"],
        correctAnswer: 1,
        explanation: "MVP stands for Minimum Viable Product - a basic version of a product with just enough features to satisfy early customers.",
        category: "Startup Basics"
      },
      {
        id: 2,
        question: "Which company was originally called 'BackRub'?",
        options: ["Facebook", "Google", "Twitter", "Amazon"],
        correctAnswer: 1,
        explanation: "Google was originally called 'BackRub' when it was developed by Larry Page and Sergey Brin at Stanford University.",
        category: "Tech History"
      },
      {
        id: 3,
        question: "What does B2B stand for?",
        options: ["Business to Business", "Back to Basics", "Buy to Build", "Brand to Brand"],
        correctAnswer: 0,
        explanation: "B2B stands for Business to Business, referring to transactions between companies rather than between a company and individual consumers.",
        category: "Business Terms"
      },
      {
        id: 4,
        question: "Which programming language was created by Guido van Rossum?",
        options: ["Java", "Python", "JavaScript", "Ruby"],
        correctAnswer: 1,
        explanation: "Python was created by Guido van Rossum and first released in 1991. It's known for its simple, readable syntax.",
        category: "Programming"
      },
      {
        id: 5,
        question: "What does SaaS stand for?",
        options: ["Software as a Service", "System as a Solution", "Security as a Standard", "Storage as a Service"],
        correctAnswer: 0,
        explanation: "SaaS stands for Software as a Service, a software distribution model where applications are hosted by a service provider.",
        category: "Tech Business"
      },
      {
        id: 6,
        question: "Which company's slogan is 'Think Different'?",
        options: ["Microsoft", "IBM", "Apple", "Intel"],
        correctAnswer: 2,
        explanation: "Apple's famous slogan 'Think Different' was used in their advertising campaign from 1997 to 2002.",
        category: "Tech Companies"
      }
    ];
    setQuizQuestions(questions);
  };

  const initializeWordScrambles = () => {
    const scrambles: WordScramble[] = [
      {
        id: 1,
        word: "STARTUP",
        scrambled: "TPURATS",
        hint: "A newly established business",
        category: "Business",
        difficulty: "easy"
      },
      {
        id: 2,
        word: "INNOVATION",
        scrambled: "NOITAVONNI",
        hint: "The process of creating something new",
        category: "Business",
        difficulty: "medium"
      },
      {
        id: 3,
        word: "ALGORITHM",
        scrambled: "MHTIROGLA",
        hint: "A set of rules for solving problems",
        category: "Technology",
        difficulty: "medium"
      },
      {
        id: 4,
        word: "ENTREPRENEUR",
        scrambled: "RUENERPERTNE",
        hint: "Someone who starts a business",
        category: "Business",
        difficulty: "hard"
      },
      {
        id: 5,
        word: "PROTOTYPE",
        scrambled: "EPYTOTORP",
        hint: "An early model of a product",
        category: "Development",
        difficulty: "medium"
      },
      {
        id: 6,
        word: "INVESTMENT",
        scrambled: "TNEMTSEVNI",
        hint: "Money put into a business for profit",
        category: "Finance",
        difficulty: "medium"
      },
      {
        id: 7,
        word: "REVENUE",
        scrambled: "EUNEVER",
        hint: "Income generated by a business",
        category: "Finance",
        difficulty: "easy"
      },
      {
        id: 8,
        word: "MARKETING",
        scrambled: "GNITEKRAM",
        hint: "Promoting and selling products",
        category: "Business",
        difficulty: "easy"
      }
    ];
    setWordScrambles(scrambles);
  };

  const playSound = (type: 'success' | 'error' | 'click') => {
    if (!soundEnabled) return;
    
    // In a real app, you would play actual sound files
    console.log(`Playing ${type} sound`);
  };

  // Joke functions
  const getRandomJoke = () => {
    const filteredJokes = jokeCategory === 'all' 
      ? jokes 
      : jokes.filter(joke => joke.category === jokeCategory);
    
    if (filteredJokes.length === 0) return;
    
    const randomJoke = filteredJokes[Math.floor(Math.random() * filteredJokes.length)];
    setCurrentJoke(randomJoke);
    setShowPunchline(false);
    playSound('click');
  };

  const revealPunchline = () => {
    setShowPunchline(true);
    playSound('success');
  };

  const rateJoke = (rating: number) => {
    if (!currentJoke) return;
    
    setJokes(jokes.map(joke => 
      joke.id === currentJoke.id 
        ? { ...joke, rating: (joke.rating + rating) / 2 }
        : joke
    ));
    playSound('success');
  };

  const toggleFavoriteJoke = () => {
    if (!currentJoke) return;
    
    setJokes(jokes.map(joke => 
      joke.id === currentJoke.id 
        ? { ...joke, isFavorite: !joke.isFavorite }
        : joke
    ));
    
    setCurrentJoke({ ...currentJoke, isFavorite: !currentJoke.isFavorite });
    playSound('success');
  };

  // Quiz functions
  const getRandomQuestion = () => {
    if (quizQuestions.length === 0) return;
    
    const randomQuestion = quizQuestions[Math.floor(Math.random() * quizQuestions.length)];
    setCurrentQuestion(randomQuestion);
    setSelectedAnswer(null);
    setShowAnswer(false);
    playSound('click');
  };

  const selectAnswer = (answerIndex: number) => {
    if (showAnswer) return;
    
    setSelectedAnswer(answerIndex);
    setShowAnswer(true);
    
    if (answerIndex === currentQuestion?.correctAnswer) {
      setQuizScore(quizScore + 1);
      playSound('success');
    } else {
      playSound('error');
    }
    
    setQuestionsAnswered(questionsAnswered + 1);
  };

  // Word Scramble functions
  const getRandomScramble = () => {
    if (wordScrambles.length === 0) return;
    
    const randomScramble = wordScrambles[Math.floor(Math.random() * wordScrambles.length)];
    setCurrentScramble(randomScramble);
    setUserAnswer('');
    setShowHint(false);
    playSound('click');
  };

  const checkScrambleAnswer = () => {
    if (!currentScramble) return;
    
    if (userAnswer.toUpperCase() === currentScramble.word) {
      setScrambleScore(scrambleScore + 1);
      setWordsCompleted(wordsCompleted + 1);
      playSound('success');
      
      // Auto-generate new scramble after success
      setTimeout(() => {
        getRandomScramble();
      }, 1500);
    } else {
      playSound('error');
    }
  };

  const handleScrambleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      checkScrambleAnswer();
    }
  };

  // Leaderboard data
  const leaderboardData = [
    { name: 'Alex Chen', score: 2840, games: 156, avatar: 'AC', badge: 'Quiz Master' },
    { name: 'Sarah Kim', score: 2650, games: 142, avatar: 'SK', badge: 'Joke Expert' },
    { name: 'Mike Rodriguez', score: 2420, games: 128, avatar: 'MR', badge: 'Word Wizard' },
    { name: 'Emma Johnson', score: 2180, games: 115, avatar: 'EJ', badge: 'Fun Champion' },
    { name: 'David Park', score: 1950, games: 98, avatar: 'DP', badge: 'Rising Star' }
  ];

  const renderGameHome = () => (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-6">
          <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-6 rounded-full shadow-xl">
            <Gamepad2 className="w-16 h-16 text-white" />
          </div>
        </div>
        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
          Fun Zone
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Take a break and have some fun! Play games, share laughs, and connect with the community.
        </p>
      </div>

      {/* Sound Toggle */}
      <div className="flex justify-center mb-8">
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-200 ${
            soundEnabled 
              ? 'bg-green-100 text-green-700 hover:bg-green-200' 
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          <span className="font-medium">Sound {soundEnabled ? 'On' : 'Off'}</span>
        </button>
      </div>

      {/* Games Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {/* Tell a Joke */}
        <div 
          onClick={() => setCurrentGame('jokes')}
          className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border border-gray-100"
        >
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-4">
            <Smile className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Tell a Joke</h3>
          <p className="text-gray-600 mb-4">Enjoy startup and tech humor. Rate jokes and save your favorites!</p>
          <div className="flex items-center gap-2 text-sm text-purple-600 font-medium">
            <Play className="w-4 h-4" />
            Start Laughing
          </div>
        </div>

        {/* Startup Quiz */}
        <div 
          onClick={() => setCurrentGame('quiz')}
          className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border border-gray-100"
        >
          <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-4">
            <Brain className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Startup Quiz</h3>
          <p className="text-gray-600 mb-4">Test your knowledge about startups, tech, and business!</p>
          <div className="flex items-center gap-2 text-sm text-purple-600 font-medium">
            <Zap className="w-4 h-4" />
            Start Quiz
          </div>
        </div>

        {/* Word Scramble */}
        <div 
          onClick={() => setCurrentGame('scramble')}
          className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border border-gray-100"
        >
          <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-4">
            <Shuffle className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Word Scramble</h3>
          <p className="text-gray-600 mb-4">Unscramble business and tech terms. Learn while you play!</p>
          <div className="flex items-center gap-2 text-sm text-purple-600 font-medium">
            <Target className="w-4 h-4" />
            Start Game
          </div>
        </div>

        {/* Memory Game - Coming Soon */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 opacity-75">
          <div className="bg-gradient-to-r from-purple-400 to-pink-500 p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-4">
            <Brain className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Memory Game</h3>
          <p className="text-gray-600 mb-4">Match startup logos and terms. Challenge your memory!</p>
          <div className="flex items-center gap-2 text-sm text-gray-500 font-medium">
            <Sparkles className="w-4 h-4" />
            Coming Soon
          </div>
        </div>

        {/* Meme Creator - Coming Soon */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 opacity-75">
          <div className="bg-gradient-to-r from-pink-400 to-rose-500 p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-4">
            <Smile className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Meme Creator</h3>
          <p className="text-gray-600 mb-4">Create and share startup memes with the community!</p>
          <div className="flex items-center gap-2 text-sm text-gray-500 font-medium">
            <Sparkles className="w-4 h-4" />
            Coming Soon
          </div>
        </div>

        {/* Brain Teasers - Coming Soon */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 opacity-75">
          <div className="bg-gradient-to-r from-indigo-400 to-purple-500 p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-4">
            <Lightbulb className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">Brain Teasers</h3>
          <p className="text-gray-600 mb-4">Solve puzzles and riddles to sharpen your mind!</p>
          <div className="flex items-center gap-2 text-sm text-gray-500 font-medium">
            <Sparkles className="w-4 h-4" />
            Coming Soon
          </div>
        </div>
      </div>

      {/* Leaderboard */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-3 rounded-xl">
            <Trophy className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Community Leaderboard</h2>
        </div>
        
        <div className="space-y-4">
          {leaderboardData.map((player, index) => (
            <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-all duration-200">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                  index === 0 ? 'bg-yellow-500' : 
                  index === 1 ? 'bg-gray-400' : 
                  index === 2 ? 'bg-amber-600' : 'bg-purple-500'
                }`}>
                  {index < 3 ? <Crown className="w-4 h-4" /> : index + 1}
                </div>
                <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                  {player.avatar}
                </div>
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-bold text-gray-800">{player.name}</h3>
                  <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-medium">
                    {player.badge}
                  </span>
                </div>
                <p className="text-sm text-gray-600">{player.games} games played</p>
              </div>
              
              <div className="text-right">
                <div className="text-2xl font-bold text-purple-600">{player.score.toLocaleString()}</div>
                <div className="text-sm text-gray-500">points</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderJokesGame = () => (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setCurrentGame('home')}
          className="flex items-center gap-2 text-gray-600 hover:text-purple-600 transition-all duration-200"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Games</span>
        </button>
        
        <div className="flex items-center gap-4">
          <select
            value={jokeCategory}
            onChange={(e) => setJokeCategory(e.target.value)}
            className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none bg-white"
          >
            <option value="all">All Categories</option>
            <option value="startup">Startup</option>
            <option value="tech">Tech</option>
            <option value="business">Business</option>
            <option value="general">General</option>
          </select>
          
          <button
            onClick={getRandomJoke}
            className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white px-6 py-2 rounded-xl font-semibold hover:from-yellow-600 hover:to-orange-700 transition-all duration-200 flex items-center gap-2"
          >
            <Shuffle className="w-5 h-5" />
            Random Joke
          </button>
        </div>
      </div>

      {/* Joke Display */}
      {currentJoke ? (
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
          <div className="text-center mb-6">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Smile className="w-8 h-8 text-white" />
            </div>
            <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium capitalize">
              {currentJoke.category}
            </span>
          </div>
          
          <div className="text-center mb-8">
            <p className="text-xl text-gray-800 mb-6 leading-relaxed">{currentJoke.setup}</p>
            
            {!showPunchline ? (
              <button
                onClick={revealPunchline}
                className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-700 transition-all duration-200 transform hover:scale-105"
              >
                Reveal Punchline 🎭
              </button>
            ) : (
              <div className="space-y-6">
                <p className="text-2xl font-bold text-purple-600 leading-relaxed">{currentJoke.punchline}</p>
                
                {/* Rating */}
                <div className="flex items-center justify-center gap-4">
                  <span className="text-gray-600">Rate this joke:</span>
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <button
                      key={rating}
                      onClick={() => rateJoke(rating)}
                      className="text-yellow-400 hover:text-yellow-500 transition-all duration-200 transform hover:scale-110"
                    >
                      <Star className="w-6 h-6 fill-current" />
                    </button>
                  ))}
                </div>
                
                {/* Actions */}
                <div className="flex items-center justify-center gap-4">
                  <button
                    onClick={toggleFavoriteJoke}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-200 ${
                      currentJoke.isFavorite
                        ? 'bg-red-100 text-red-600'
                        : 'bg-gray-100 text-gray-600 hover:bg-red-50 hover:text-red-600'
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${currentJoke.isFavorite ? 'fill-current' : ''}`} />
                    <span>{currentJoke.isFavorite ? 'Favorited' : 'Favorite'}</span>
                  </button>
                  
                  <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition-all duration-200">
                    <Share2 className="w-5 h-5" />
                    <span>Share</span>
                  </button>
                </div>
              </div>
            )}
          </div>
          
          <div className="text-center text-sm text-gray-500">
            by {currentJoke.author} • Rating: {currentJoke.rating.toFixed(1)}/5
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-lg p-12 border border-gray-100 text-center">
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Smile className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-4">Ready for Some Laughs?</h3>
          <p className="text-gray-600 mb-6">Click "Random Joke" to get started with some startup and tech humor!</p>
          <button
            onClick={getRandomJoke}
            className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-yellow-600 hover:to-orange-700 transition-all duration-200"
          >
            Get First Joke
          </button>
        </div>
      )}
    </div>
  );

  const renderQuizGame = () => (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setCurrentGame('home')}
          className="flex items-center gap-2 text-gray-600 hover:text-purple-600 transition-all duration-200"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Games</span>
        </button>
        
        <div className="flex items-center gap-4">
          <div className="bg-white rounded-xl px-4 py-2 shadow-lg border border-gray-100">
            <span className="text-sm text-gray-600">Score: </span>
            <span className="font-bold text-purple-600">{quizScore}/{questionsAnswered}</span>
          </div>
          
          <button
            onClick={getRandomQuestion}
            className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-6 py-2 rounded-xl font-semibold hover:from-blue-600 hover:to-indigo-700 transition-all duration-200 flex items-center gap-2"
          >
            <Shuffle className="w-5 h-5" />
            New Question
          </button>
        </div>
      </div>

      {/* Quiz Display */}
      {currentQuestion ? (
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
          <div className="text-center mb-6">
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Brain className="w-8 h-8 text-white" />
            </div>
            <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
              {currentQuestion.category}
            </span>
          </div>
          
          <div className="mb-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center leading-relaxed">
              {currentQuestion.question}
            </h3>
            
            <div className="grid gap-4">
              {currentQuestion.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => selectAnswer(index)}
                  disabled={showAnswer}
                  className={`p-4 rounded-xl text-left transition-all duration-200 border-2 ${
                    showAnswer
                      ? index === currentQuestion.correctAnswer
                        ? 'bg-green-100 border-green-500 text-green-700'
                        : index === selectedAnswer
                        ? 'bg-red-100 border-red-500 text-red-700'
                        : 'bg-gray-50 border-gray-200 text-gray-600'
                      : 'bg-gray-50 border-gray-200 hover:bg-purple-50 hover:border-purple-300 text-gray-700'
                  }`}
                >
                  <span className="font-semibold mr-3">{String.fromCharCode(65 + index)}.</span>
                  {option}
                </button>
              ))}
            </div>
          </div>
          
          {showAnswer && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
              <h4 className="font-bold text-blue-800 mb-2 flex items-center gap-2">
                <Lightbulb className="w-5 h-5" />
                Explanation:
              </h4>
              <p className="text-blue-700">{currentQuestion.explanation}</p>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-lg p-12 border border-gray-100 text-center">
          <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Brain className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-4">Test Your Knowledge!</h3>
          <p className="text-gray-600 mb-6">Answer questions about startups, technology, and business to improve your score!</p>
          <button
            onClick={getRandomQuestion}
            className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-blue-600 hover:to-indigo-700 transition-all duration-200"
          >
            Start Quiz
          </button>
        </div>
      )}
    </div>
  );

  const renderScrambleGame = () => (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setCurrentGame('home')}
          className="flex items-center gap-2 text-gray-600 hover:text-purple-600 transition-all duration-200"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Games</span>
        </button>
        
        <div className="flex items-center gap-4">
          <div className="bg-white rounded-xl px-4 py-2 shadow-lg border border-gray-100">
            <span className="text-sm text-gray-600">Score: </span>
            <span className="font-bold text-emerald-600">{scrambleScore}/{wordsCompleted}</span>
          </div>
          
          <button
            onClick={getRandomScramble}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-2 rounded-xl font-semibold hover:from-emerald-600 hover:to-teal-700 transition-all duration-200 flex items-center gap-2"
          >
            <Shuffle className="w-5 h-5" />
            New Word
          </button>
        </div>
      </div>

      {/* Scramble Display */}
      {currentScramble ? (
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
          <div className="text-center mb-6">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Shuffle className="w-8 h-8 text-white" />
            </div>
            <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-sm font-medium">
              {currentScramble.category}
            </span>
          </div>
          
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-gray-800 mb-6 tracking-wider">
              {currentScramble.scrambled}
            </h3>
            
            <div className="space-y-4">
              <input
                type="text"
                value={userAnswer}
                onChange={(e) => setUserAnswer(e.target.value)}
                onKeyPress={handleScrambleKeyPress}
                placeholder="Enter your answer..."
                className="w-full max-w-md mx-auto px-6 py-3 border-2 border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-none text-center text-xl font-semibold"
              />
              
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={checkScrambleAnswer}
                  disabled={!userAnswer.trim()}
                  className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-emerald-600 hover:to-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  Check Answer
                </button>
                
                <button
                  onClick={() => setShowHint(!showHint)}
                  className="flex items-center gap-2 px-4 py-3 rounded-xl bg-gray-100 text-gray-600 hover:bg-yellow-50 hover:text-yellow-600 transition-all duration-200"
                >
                  <HelpCircle className="w-5 h-5" />
                  {showHint ? 'Hide' : 'Show'} Hint
                </button>
              </div>
            </div>
          </div>
          
          {showHint && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 text-center">
              <h4 className="font-bold text-yellow-800 mb-2 flex items-center justify-center gap-2">
                <Lightbulb className="w-5 h-5" />
                Hint:
              </h4>
              <p className="text-yellow-700">{currentScramble.hint}</p>
            </div>
          )}
          
          {userAnswer.toUpperCase() === currentScramble.word && (
            <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-center mt-6">
              <h4 className="font-bold text-green-800 mb-2 flex items-center justify-center gap-2">
                <Award className="w-5 h-5" />
                Correct! 🎉
              </h4>
              <p className="text-green-700">Great job! The word was "{currentScramble.word}"</p>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-lg p-12 border border-gray-100 text-center">
          <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Shuffle className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 mb-4">Word Scramble Challenge!</h3>
          <p className="text-gray-600 mb-6">Unscramble business and technology terms to test your vocabulary!</p>
          <button
            onClick={getRandomScramble}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-8 py-3 rounded-xl font-semibold hover:from-emerald-600 hover:to-teal-700 transition-all duration-200"
          >
            Start Game
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className="container mx-auto px-4 sm:px-6 py-8 pt-24 sm:pt-32 max-w-6xl">
      {currentGame === 'home' && renderGameHome()}
      {currentGame === 'jokes' && renderJokesGame()}
      {currentGame === 'quiz' && renderQuizGame()}
      {currentGame === 'scramble' && renderScrambleGame()}
    </div>
  );
};

export default FunZonePage;