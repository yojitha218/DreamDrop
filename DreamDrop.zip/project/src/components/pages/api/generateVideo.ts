// src/pages/api/generateStartup.ts
import type { NextApiRequest, NextApiResponse } from "next";
import generateStartup from "@/backend/generateVideo.ts";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const body = req.body;
  const result = await generateStartup(body);
  res.status(200).json(result);
}
