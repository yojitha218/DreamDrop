import React, { useState } from 'react';
import { X, MessageCircle, Send, Search, User, Phone, Video, MoreHorizontal } from 'lucide-react';

interface MessagingDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const MessagingDrawer: React.FC<MessagingDrawerProps> = ({ isOpen, onClose }) => {
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');

  const conversations = [
    {
      id: '1',
      name: 'Sarah Kim',
      avatar: 'SK',
      lastMessage: 'Great idea about the pet health app! Would love to discuss potential collaboration.',
      time: '2h ago',
      unread: 2,
      online: true
    },
    {
      id: '2',
      name: 'Mike Rodriguez',
      avatar: 'MR',
      lastMessage: 'Would love to collaborate on VR project. When can we schedule a call?',
      time: '5h ago',
      unread: 0,
      online: false
    },
    {
      id: '3',
      name: 'Emma Johnson',
      avatar: 'EJ',
      lastMessage: 'Thanks for the feedback on my farming idea!',
      time: '1d ago',
      unread: 1,
      online: true
    },
    {
      id: '4',
      name: 'David Park',
      avatar: 'DP',
      lastMessage: 'The AI mentor feature sounds amazing. Let\'s connect!',
      time: '2d ago',
      unread: 0,
      online: false
    }
  ];

  const messages = [
    {
      id: '1',
      sender: 'Sarah Kim',
      message: 'Hey! I saw your pet health monitoring idea. It\'s brilliant!',
      time: '2:30 PM',
      isMe: false
    },
    {
      id: '2',
      sender: 'Me',
      message: 'Thank you! I\'d love to hear your thoughts on it.',
      time: '2:32 PM',
      isMe: true
    },
    {
      id: '3',
      sender: 'Sarah Kim',
      message: 'I think there\'s huge potential for collaboration. I have experience in IoT sensors.',
      time: '2:35 PM',
      isMe: false
    }
  ];

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // Mock sending message
      setNewMessage('');
    }
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 z-40 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Drawer */}
      <div className="fixed right-0 top-0 h-full w-full sm:w-96 bg-white shadow-2xl z-50 transform transition-transform duration-300 flex flex-col">
        {selectedConversation ? (
          // Chat View
          <>
            {/* Chat Header */}
            <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 sm:p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <button
                  onClick={() => setSelectedConversation(null)}
                  className="p-2 rounded-full hover:bg-white/20 transition-all duration-200"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center font-bold">
                    SK
                  </div>
                  <div>
                    <h3 className="font-bold">Sarah Kim</h3>
                    <p className="text-sm text-white/80">Online</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 rounded-full hover:bg-white/20 transition-all duration-200">
                    <Phone className="w-5 h-5" />
                  </button>
                  <button className="p-2 rounded-full hover:bg-white/20 transition-all duration-200">
                    <Video className="w-5 h-5" />
                  </button>
                  <button className="p-2 rounded-full hover:bg-white/20 transition-all duration-200">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isMe ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs px-4 py-3 rounded-2xl break-words ${
                      message.isMe
                        ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    <p className="text-sm">{message.message}</p>
                    <p className={`text-xs mt-1 ${message.isMe ? 'text-white/80' : 'text-gray-500'}`}>
                      {message.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-100">
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-full focus:border-purple-500 focus:outline-none"
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                />
                <button
                  onClick={handleSendMessage}
                  className="bg-gradient-to-r from-pink-500 to-purple-600 text-white p-3 rounded-full hover:from-pink-600 hover:to-purple-700 transition-all duration-200"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </>
        ) : (
          // Conversations List
          <>
            {/* Header */}
            <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-4 sm:p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <MessageCircle className="w-8 h-8" />
                  <h2 className="text-xl sm:text-2xl font-bold">Messages</h2>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 rounded-full hover:bg-white/20 transition-all duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/70 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search conversations..."
                  className="w-full pl-10 pr-4 py-3 bg-white/20 backdrop-blur-sm rounded-xl text-white placeholder-white/70 focus:outline-none focus:bg-white/30 border border-white/30"
                />
              </div>
            </div>

            {/* Conversations List */}
            <div className="flex-1 overflow-y-auto">
              {conversations.map((conversation) => (
                <div
                  key={conversation.id}
                  onClick={() => setSelectedConversation(conversation.id)}
                  className="p-4 sm:p-6 border-b border-gray-100 hover:bg-purple-50 cursor-pointer transition-all duration-200"
                >
                  <div className="flex items-start gap-4">
                    <div className="relative">
                      <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                        {conversation.avatar}
                      </div>
                      {conversation.online && (
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-bold text-gray-800 text-lg truncate">{conversation.name}</h3>
                        <span className="text-sm text-gray-500 flex-shrink-0">{conversation.time}</span>
                      </div>
                      <p className="text-gray-600 line-clamp-2 text-sm leading-relaxed break-words">{conversation.lastMessage}</p>
                    </div>
                    {conversation.unread > 0 && (
                      <div className="w-6 h-6 bg-pink-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-xs text-white font-bold">{conversation.unread}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* New Conversation Button */}
            <div className="p-4 sm:p-6 border-t border-gray-100">
              <button className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-4 rounded-2xl font-bold text-lg hover:from-pink-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-200 flex items-center justify-center gap-3 shadow-lg">
                <User className="w-6 h-6" />
                Start New Conversation
              </button>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default MessagingDrawer;