import React, { useState, useEffect } from 'react';
import { ArrowUp, Menu, Sparkles } from 'lucide-react';

interface NavbarHintProps {
  onDismiss: () => void;
  onManualShow: () => void;
}

const NavbarHint: React.FC<NavbarHintProps> = ({ onDismiss, onManualShow }) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Auto-hide after 6 seconds (increased from 4 seconds)
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onDismiss, 500);
    }, 6000);

    return () => clearTimeout(timer);
  }, [onDismiss]);

  const handleClick = () => {
    onManualShow();
    setIsVisible(false);
    setTimeout(onDismiss, 300);
  };

  if (!isVisible) return null;

  return (
    <div className={`fixed top-8 left-1/2 transform -translate-x-1/2 z-40 transition-all duration-500 ${
      isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
    }`}>
      {/* Main hint container */}
      <div 
        className="flex items-center gap-4 bg-white/95 backdrop-blur-xl rounded-3xl px-6 py-4 shadow-2xl border border-white/50 cursor-pointer hover:scale-105 transition-all duration-300 group"
        onClick={handleClick}
      >
        {/* Animated pointing arrow */}
        <div className="relative">
          <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-3 rounded-full shadow-lg animate-pulse">
            <ArrowUp className="w-5 h-5 text-white animate-bounce" />
          </div>
          {/* Pulsing glow effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full opacity-30 animate-ping"></div>
        </div>

        {/* Text with icons */}
        <div className="flex items-center gap-3">
          <Sparkles className="w-4 h-4 text-pink-500 animate-sparkle" />
          <div className="text-center">
            <div className="font-bold text-gray-800 text-base">↑ Explore Menu</div>
            <div className="text-xs text-gray-600">Hover at the top edge (stays 10s)</div>
          </div>
          <Menu className="w-4 h-4 text-purple-600" />
        </div>

        {/* Floating sparkles around the hint */}
        <div className="absolute -top-1 -right-1 w-2 h-2 bg-pink-400 rounded-full animate-ping opacity-75"></div>
        <div className="absolute -bottom-1 -left-1 w-1.5 h-1.5 bg-purple-400 rounded-full animate-pulse opacity-60"></div>
      </div>

      {/* Animated line pointing to top edge */}
      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
        <div className="w-0.5 h-4 bg-gradient-to-t from-pink-500 to-transparent animate-pulse"></div>
      </div>
    </div>
  );
};

export default NavbarHint;