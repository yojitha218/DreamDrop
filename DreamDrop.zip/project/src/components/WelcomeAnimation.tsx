import React, { useEffect, useState } from 'react';
import { Sparkles, Star, Heart, Zap, Rocket, TrendingUp, Lightbulb } from 'lucide-react';
import { UserRole } from '../App';

interface WelcomeAnimationProps {
  userRole: UserRole;
  onComplete: () => void;
}

const WelcomeAnimation: React.FC<WelcomeAnimationProps> = ({ userRole, onComplete }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [confettiPieces, setConfettiPieces] = useState<Array<{
    id: number;
    x: number;
    y: number;
    rotation: number;
    color: string;
    size: number;
    delay: number;
    type: 'circle' | 'square' | 'triangle' | 'star';
    velocity: number;
  }>>([]);

  useEffect(() => {
    // Generate enhanced confetti pieces with physics
    const pieces = Array.from({ length: 60 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: -10 - Math.random() * 20, // Start above screen
      rotation: Math.random() * 360,
      color: userRole === 'innovator' 
        ? ['#ec4899', '#8b5cf6', '#f97316', '#eab308', '#ef4444'][Math.floor(Math.random() * 5)]
        : ['#3b82f6', '#1d4ed8', '#fbbf24', '#f59e0b', '#10b981'][Math.floor(Math.random() * 5)],
      size: Math.random() * 12 + 6,
      delay: Math.random() * 1,
      type: ['circle', 'square', 'triangle', 'star'][Math.floor(Math.random() * 4)] as any,
      velocity: Math.random() * 2 + 1
    }));
    setConfettiPieces(pieces);

    // Auto fade out after 2 seconds
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onComplete, 800); // Wait for fade out animation
    }, 2000);

    return () => clearTimeout(timer);
  }, [userRole, onComplete]);

  const renderConfettiPiece = (piece: typeof confettiPieces[0]) => {
    const baseClasses = "absolute animate-confetti-fall opacity-90 shadow-lg";
    const style = {
      left: `${piece.x}%`,
      top: `${piece.y}%`,
      backgroundColor: piece.color,
      width: `${piece.size}px`,
      height: `${piece.size}px`,
      transform: `rotate(${piece.rotation}deg)`,
      animationDelay: `${piece.delay}s`,
      animationDuration: `${2 + piece.velocity}s`,
      filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.2))'
    };

    switch (piece.type) {
      case 'circle':
        return (
          <div
            key={piece.id}
            className={`${baseClasses} rounded-full`}
            style={style}
          />
        );
      case 'square':
        return (
          <div
            key={piece.id}
            className={`${baseClasses} rounded-lg`}
            style={style}
          />
        );
      case 'triangle':
        return (
          <div
            key={piece.id}
            className={`${baseClasses}`}
            style={{
              ...style,
              width: 0,
              height: 0,
              backgroundColor: 'transparent',
              borderLeft: `${piece.size/2}px solid transparent`,
              borderRight: `${piece.size/2}px solid transparent`,
              borderBottom: `${piece.size}px solid ${piece.color}`,
              filter: `drop-shadow(0 2px 4px rgba(0,0,0,0.2))`
            }}
          />
        );
      case 'star':
        return (
          <Star
            key={piece.id}
            className={`${baseClasses} text-yellow-400`}
            style={{
              left: `${piece.x}%`,
              top: `${piece.y}%`,
              width: `${piece.size}px`,
              height: `${piece.size}px`,
              animationDelay: `${piece.delay}s`,
              animationDuration: `${2 + piece.velocity}s`,
              filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.2))'
            }}
            fill="currentColor"
          />
        );
      default:
        return null;
    }
  };

  const getMessage = () => {
    if (userRole === 'innovator') {
      return {
        emoji: '🎉',
        title: 'Welcome, Innovator!',
        subtitle: "Let's bring dreams to life!",
        gradient: 'from-pink-500 via-purple-600 to-indigo-600',
        icon: <Lightbulb className="w-16 h-16 text-white animate-pulse" />
      };
    } else {
      return {
        emoji: '🚀',
        title: 'Welcome, Investor!',
        subtitle: 'Discover your next unicorn idea!',
        gradient: 'from-blue-500 via-indigo-600 to-purple-600',
        icon: <TrendingUp className="w-16 h-16 text-white animate-pulse" />
      };
    }
  };

  const message = getMessage();

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-lg transition-all duration-800 ${
      isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
    }`}>
      {/* Enhanced Confetti Layer */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {confettiPieces.map(renderConfettiPiece)}
        
        {/* Additional floating celebration elements */}
        <div className="absolute top-1/4 left-1/4 animate-float">
          <Sparkles className="w-10 h-10 text-yellow-400 animate-spin" style={{ animationDuration: '3s' }} />
        </div>
        <div className="absolute top-1/3 right-1/4 animate-float" style={{ animationDelay: '0.5s' }}>
          <Heart className="w-8 h-8 text-pink-400 animate-pulse" fill="currentColor" />
        </div>
        <div className="absolute bottom-1/3 left-1/3 animate-float" style={{ animationDelay: '1s' }}>
          <Zap className="w-9 h-9 text-purple-400 animate-bounce" />
        </div>
        <div className="absolute bottom-1/4 right-1/3 animate-float" style={{ animationDelay: '1.5s' }}>
          <Rocket className="w-10 h-10 text-blue-400 animate-pulse" />
        </div>
        <div className="absolute top-1/2 left-1/6 animate-float" style={{ animationDelay: '0.8s' }}>
          <Star className="w-7 h-7 text-amber-400 animate-spin" fill="currentColor" style={{ animationDuration: '4s' }} />
        </div>
        <div className="absolute top-3/4 right-1/6 animate-float" style={{ animationDelay: '1.2s' }}>
          <Sparkles className="w-8 h-8 text-emerald-400 animate-pulse" />
        </div>
      </div>

      {/* Enhanced Welcome Message */}
      <div className={`relative z-10 text-center transform transition-all duration-1000 welcome-container ${
        isVisible ? 'scale-100 opacity-100 translate-y-0' : 'scale-75 opacity-0 translate-y-8'
      }`}>
        <div className={`bg-gradient-to-r ${message.gradient} rounded-3xl p-12 md:p-16 shadow-2xl border border-white/30 backdrop-blur-xl max-w-2xl mx-auto relative overflow-hidden`}>
          {/* Animated background pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white/20 to-transparent"></div>
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-white/10 rounded-full"></div>
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-white/10 rounded-full"></div>
          </div>

          {/* Icon Container */}
          <div className="relative bg-white/20 p-8 rounded-full w-32 h-32 mx-auto mb-8 flex items-center justify-center backdrop-blur-sm shadow-xl animate-celebration-bounce">
            {userRole === 'innovator' ? (
              <Lightbulb className="w-16 h-16 text-white animate-pulse" />
            ) : (
              <TrendingUp className="w-16 h-16 text-white animate-pulse" />
            )}
            {/* Glow effect */}
            <div className="absolute inset-0 rounded-full bg-white/20 animate-ping"></div>
          </div>

          {/* Emoji with enhanced animation */}
          <div className="text-7xl md:text-8xl mb-8 animate-celebration-bounce" style={{ animationDelay: '0.2s' }}>
            {message.emoji}
          </div>

          {/* Title with staggered animation */}
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in leading-tight">
            {message.title}
          </h1>

          {/* Subtitle with staggered animation */}
          <p className="text-xl md:text-3xl text-white/95 font-medium animate-fade-in leading-relaxed" style={{ animationDelay: '0.4s' }}>
            {message.subtitle}
          </p>

          {/* Enhanced decorative elements */}
          <div className="flex justify-center gap-6 mt-10" style={{ animationDelay: '0.6s' }}>
            <div className="w-4 h-4 bg-white/50 rounded-full animate-pulse shadow-lg"></div>
            <div className="w-4 h-4 bg-white/70 rounded-full animate-pulse shadow-lg" style={{ animationDelay: '0.3s' }}></div>
            <div className="w-4 h-4 bg-white/50 rounded-full animate-pulse shadow-lg" style={{ animationDelay: '0.6s' }}></div>
          </div>

          {/* Progress indicator */}
          <div className="mt-8 w-32 h-1 bg-white/30 rounded-full mx-auto overflow-hidden">
            <div className="h-full bg-white/80 rounded-full animate-pulse" style={{ width: '100%', animationDuration: '2s' }}></div>
          </div>
        </div>

        {/* Enhanced floating sparkles around the message */}
        <div className="absolute -top-6 -left-6 animate-float">
          <Sparkles className="w-8 h-8 text-yellow-300 animate-spin" style={{ animationDuration: '3s' }} />
        </div>
        <div className="absolute -top-6 -right-6 animate-float" style={{ animationDelay: '0.5s' }}>
          <Star className="w-7 h-7 text-pink-300 animate-pulse" fill="currentColor" />
        </div>
        <div className="absolute -bottom-6 -left-6 animate-float" style={{ animationDelay: '1s' }}>
          <Heart className="w-7 h-7 text-red-300 animate-bounce" fill="currentColor" />
        </div>
        <div className="absolute -bottom-6 -right-6 animate-float" style={{ animationDelay: '1.5s' }}>
          <Zap className="w-8 h-8 text-blue-300 animate-pulse" />
        </div>
        <div className="absolute top-1/2 -left-8 animate-float" style={{ animationDelay: '0.8s' }}>
          <Rocket className="w-6 h-6 text-emerald-300 animate-bounce" />
        </div>
        <div className="absolute top-1/2 -right-8 animate-float" style={{ animationDelay: '1.2s' }}>
          <Sparkles className="w-6 h-6 text-purple-300 animate-spin" style={{ animationDuration: '4s' }} />
        </div>
      </div>
    </div>
  );
};

export default WelcomeAnimation;