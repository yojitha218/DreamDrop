import React from 'react';
import { X, Bell, Heart, MessageCircle, Star, TrendingUp, User, Clock } from 'lucide-react';

interface NotificationsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const NotificationsDrawer: React.FC<NotificationsDrawerProps> = ({ isOpen, onClose }) => {
  const notifications = [
    {
      id: '1',
      type: 'like',
      title: 'Sarah Kim liked your dream',
      message: 'EcoTrack Pro received a new like',
      time: '2 minutes ago',
      unread: true,
      avatar: 'SK'
    },
    {
      id: '2',
      type: 'message',
      title: 'New message from Mike Rodriguez',
      message: 'Interested in collaborating on your VR project',
      time: '1 hour ago',
      unread: true,
      avatar: 'MR'
    },
    {
      id: '3',
      type: 'comment',
      title: 'Emma Johnson commented',
      message: 'Great idea! Would love to see this implemented',
      time: '3 hours ago',
      unread: false,
      avatar: 'EJ'
    },
    {
      id: '4',
      type: 'follow',
      title: 'David Park started following you',
      message: 'Check out their profile and latest dreams',
      time: '1 day ago',
      unread: false,
      avatar: 'DP'
    },
    {
      id: '5',
      type: 'trending',
      title: 'Your dream is trending!',
      message: 'PetPal Health is now #3 in rankings',
      time: '2 days ago',
      unread: false,
      avatar: null
    }
  ];

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like': return <Heart className="w-5 h-5 text-pink-500" fill="currentColor" />;
      case 'message': return <MessageCircle className="w-5 h-5 text-blue-500" />;
      case 'comment': return <MessageCircle className="w-5 h-5 text-green-500" />;
      case 'follow': return <User className="w-5 h-5 text-purple-500" />;
      case 'trending': return <TrendingUp className="w-5 h-5 text-orange-500" />;
      default: return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 z-40 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Drawer */}
      <div className="fixed right-0 top-0 h-full w-full sm:w-96 bg-white shadow-2xl z-50 transform transition-transform duration-300 flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-500 to-indigo-600 p-4 sm:p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Bell className="w-8 h-8" />
              <h2 className="text-xl sm:text-2xl font-bold">Notifications</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-white/20 transition-all duration-200"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-white/80">2 unread notifications</span>
            <button className="text-sm text-white/80 hover:text-white transition-all duration-200">
              Mark all as read
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-4 sm:p-6 border-b border-gray-100 hover:bg-purple-50 cursor-pointer transition-all duration-200 ${
                notification.unread ? 'bg-purple-25 border-l-4 border-l-purple-500' : ''
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="relative flex-shrink-0">
                  {notification.avatar ? (
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold">
                      {notification.avatar}
                    </div>
                  ) : (
                    <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                  )}
                  <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-1">
                    {getNotificationIcon(notification.type)}
                  </div>
                  {notification.unread && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-purple-500 rounded-full"></div>
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-gray-800 mb-1 break-words">{notification.title}</h3>
                  <p className="text-gray-600 text-sm mb-2 break-words">{notification.message}</p>
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span>{notification.time}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-6 border-t border-gray-100 bg-gray-50">
          <button className="w-full bg-gradient-to-r from-purple-500 to-indigo-600 text-white py-3 rounded-2xl font-bold hover:from-purple-600 hover:to-indigo-700 transform hover:scale-105 transition-all duration-200">
            View All Notifications
          </button>
        </div>
      </div>
    </>
  );
};

export default NotificationsDrawer;