import { supabase } from '../lib/supabase';

export interface Dream {
  id: string;
  userId: string;
  title: string;
  description: string;
  aiSummary?: string;
  aiName?: string;
  strength?: 'Strong' | 'Moderate' | 'Weak';
  uniqueness?: string;
  marketCheck?: string;
  picaVideoUrl?: string;
  tavusVideoUrl?: string;
  tags: string[];
  likesCount: number;
  commentsCount: number;
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SaveDreamData {
  userId: string;
  title: string;
  description: string;
  aiSummary?: string;
  aiName?: string;
  strength?: 'Strong' | 'Moderate' | 'Weak';
  uniqueness?: string;
  marketCheck?: string;
  tags?: string[];
}

export interface GeneratedStartup {
  name: string;
  focus: string;
  targetUsers: string;
  summary: string;
  uniqueness: string;
  strength: 'Strong' | 'Moderate' | 'Weak';
  marketCheck: string;
}

class DreamService {
  async generateStartup(dream: string, userId: string): Promise<GeneratedStartup> {
    try {
      const { data, error } = await supabase.functions.invoke('generate-startup', {
        body: { dream, userId }
      });

      if (error) {
        console.error('Supabase function error:', error);
        
        // Provide more specific error messages based on the error
        if (error.message?.includes('OpenAI API key')) {
          throw new Error('AI service configuration issue. The OpenAI API key needs to be configured in the Supabase project settings.');
        } else if (error.message?.includes('rate limit')) {
          throw new Error('AI service is temporarily busy due to high demand. Please try again in a few minutes.');
        } else if (error.message?.includes('quota')) {
          throw new Error('AI service quota has been exceeded. Please try again later or contact support.');
        } else {
          throw new Error('The AI service is currently unavailable. This could be due to API configuration issues or service limits. Please try again later or contact support.');
        }
      }

      if (!data) {
        throw new Error('No data received from the AI service. Please try again.');
      }

      // Validate the response structure
      if (!data.name || !data.summary || !data.strength) {
        console.warn('Incomplete data from AI service:', data);
        throw new Error('Received incomplete data from AI service. Please try again.');
      }

      return data;
    } catch (error) {
      console.error('Dream service error:', error);
      
      // Re-throw the error with the original message if it's already user-friendly
      if (error instanceof Error && error.message.includes('AI service')) {
        throw error;
      }
      
      // Generic fallback error
      throw new Error('Failed to generate startup idea. Please check your internet connection and try again.');
    }
  }

  async saveDream(dreamData: SaveDreamData): Promise<Dream> {
    try {
      const { data, error } = await supabase
        .from('dreams')
        .insert({
          user_id: dreamData.userId,
          title: dreamData.title,
          description: dreamData.description,
          ai_summary: dreamData.aiSummary,
          ai_name: dreamData.aiName,
          strength: dreamData.strength,
          uniqueness: dreamData.uniqueness,
          market_check: dreamData.marketCheck,
          tags: dreamData.tags || [],
          is_published: false
        })
        .select()
        .single();

      if (error) {
        console.error('Error saving dream:', error);
        throw new Error('Failed to save dream. Please try again.');
      }

      return {
        id: data.id,
        userId: data.user_id,
        title: data.title,
        description: data.description,
        aiSummary: data.ai_summary,
        aiName: data.ai_name,
        strength: data.strength,
        uniqueness: data.uniqueness,
        marketCheck: data.market_check,
        picaVideoUrl: data.pica_video_url,
        tavusVideoUrl: data.tavus_video_url,
        tags: data.tags,
        likesCount: data.likes_count,
        commentsCount: data.comments_count,
        isPublished: data.is_published,
        createdAt: data.created_at,
        updatedAt: data.updated_at
      };
    } catch (error) {
      console.error('Save dream error:', error);
      throw error instanceof Error ? error : new Error('Failed to save dream');
    }
  }

  async publishDream(dreamId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('dreams')
        .update({ is_published: true })
        .eq('id', dreamId);

      if (error) {
        console.error('Error publishing dream:', error);
        throw new Error('Failed to publish dream. Please try again.');
      }
    } catch (error) {
      console.error('Publish dream error:', error);
      throw error instanceof Error ? error : new Error('Failed to publish dream');
    }
  }

  async getPublishedDreams(): Promise<Dream[]> {
    try {
      const { data, error } = await supabase
        .from('dreams')
        .select('*')
        .eq('is_published', true)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching dreams:', error);
        throw new Error('Failed to load dreams. Please try again.');
      }

      return data.map(dream => ({
        id: dream.id,
        userId: dream.user_id,
        title: dream.title,
        description: dream.description,
        aiSummary: dream.ai_summary,
        aiName: dream.ai_name,
        strength: dream.strength,
        uniqueness: dream.uniqueness,
        marketCheck: dream.market_check,
        picaVideoUrl: dream.pica_video_url,
        tavusVideoUrl: dream.tavus_video_url,
        tags: dream.tags,
        likesCount: dream.likes_count,
        commentsCount: dream.comments_count,
        isPublished: dream.is_published,
        createdAt: dream.created_at,
        updatedAt: dream.updated_at
      }));
    } catch (error) {
      console.error('Get dreams error:', error);
      throw error instanceof Error ? error : new Error('Failed to load dreams');
    }
  }

  async getUserDreams(userId: string): Promise<Dream[]> {
    try {
      const { data, error } = await supabase
        .from('dreams')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching user dreams:', error);
        throw new Error('Failed to load your dreams. Please try again.');
      }

      return data.map(dream => ({
        id: dream.id,
        userId: dream.user_id,
        title: dream.title,
        description: dream.description,
        aiSummary: dream.ai_summary,
        aiName: dream.ai_name,
        strength: dream.strength,
        uniqueness: dream.uniqueness,
        marketCheck: dream.market_check,
        picaVideoUrl: dream.pica_video_url,
        tavusVideoUrl: dream.tavus_video_url,
        tags: dream.tags,
        likesCount: dream.likes_count,
        commentsCount: dream.comments_count,
        isPublished: dream.is_published,
        createdAt: dream.created_at,
        updatedAt: dream.updated_at
      }));
    } catch (error) {
      console.error('Get user dreams error:', error);
      throw error instanceof Error ? error : new Error('Failed to load your dreams');
    }
  }
}

export const dreamService = new DreamService();