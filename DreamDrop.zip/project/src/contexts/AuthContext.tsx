import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { User, AuthState, LoginCredentials, SignUpData } from '../types/auth';

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  signUp: (data: SignUpData) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  incrementDreamCount: () => Promise<void>;
  upgradeToPro: () => Promise<void>;
  canSubmitDream: () => boolean;
  getRemainingDreams: () => number;
  purchasePro: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

type AuthAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'UPDATE_USER'; payload: Partial<User> };

const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_USER':
      return {
        ...state,
        user: action.payload,
        isAuthenticated: !!action.payload,
        error: null,
        isLoading: false
      };
    case 'SET_ERROR':
      return { ...state, error: action.payload, isLoading: false };
    case 'UPDATE_USER':
      return {
        ...state,
        user: state.user ? { ...state.user, ...action.payload } : null
      };
    default:
      return state;
  }
};

const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  error: null
};

// Simple local storage auth service
class SimpleAuthService {
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  async signUp(data: SignUpData): Promise<User> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    const newUser: User = {
      id: this.generateId(),
      fullName: data.fullName,
      email: data.email,
      dateOfBirth: data.dateOfBirth,
      role: data.role,
      dreamCount: 0,
      isPro: false,
      createdAt: new Date().toISOString(),
      avatar: data.fullName.split(' ').map(n => n[0]).join('').toUpperCase()
    };

    // Store user
    localStorage.setItem('dreamdrop_user', JSON.stringify(newUser));
    return newUser;
  }

  async login(credentials: LoginCredentials): Promise<User> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Demo accounts
    const demoUsers: Record<string, User> = {
      'innovator@demo.com': {
        id: 'demo-innovator',
        fullName: 'Demo Innovator',
        email: 'innovator@demo.com',
        dateOfBirth: '1990-01-01',
        role: 'innovator',
        dreamCount: 3,
        isPro: false,
        createdAt: '2024-01-01T00:00:00Z',
        avatar: 'DI'
      },
      'investor@demo.com': {
        id: 'demo-investor',
        fullName: 'Demo Investor',
        email: 'investor@demo.com',
        dateOfBirth: '1985-01-01',
        role: 'investor',
        dreamCount: 0,
        isPro: true,
        createdAt: '2024-01-01T00:00:00Z',
        avatar: 'DI'
      }
    };

    // Check if it's a demo user
    const demoUser = demoUsers[credentials.email];
    if (demoUser) {
      localStorage.setItem('dreamdrop_user', JSON.stringify(demoUser));
      return demoUser;
    }

    // For non-demo users, check if they exist in localStorage from previous signup
    const existingUsers = JSON.parse(localStorage.getItem('dreamdrop_users') || '{}');
    const existingUser = existingUsers[credentials.email];
    
    if (existingUser) {
      // Validate password (in a real app, this would be hashed)
      if (existingUser.password === credentials.password) {
        const { password, ...userWithoutPassword } = existingUser;
        localStorage.setItem('dreamdrop_user', JSON.stringify(userWithoutPassword));
        return userWithoutPassword;
      } else {
        throw new Error('Invalid email or password');
      }
    }

    // If no existing user found, create a new one for demo purposes
    // This allows any email/password combination to work
    const newUser: User = {
      id: this.generateId(),
      fullName: credentials.email.split('@')[0].replace(/[^a-zA-Z]/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      email: credentials.email,
      dateOfBirth: '1990-01-01',
      role: 'innovator', // Default role
      dreamCount: 0,
      isPro: false,
      createdAt: new Date().toISOString(),
      avatar: credentials.email.substring(0, 2).toUpperCase()
    };

    // Store the new user
    const updatedUsers = {
      ...existingUsers,
      [credentials.email]: { ...newUser, password: credentials.password }
    };
    localStorage.setItem('dreamdrop_users', JSON.stringify(updatedUsers));
    localStorage.setItem('dreamdrop_user', JSON.stringify(newUser));
    
    return newUser;
  }

  getCurrentUser(): User | null {
    const userData = localStorage.getItem('dreamdrop_user');
    return userData ? JSON.parse(userData) : null;
  }

  async logout(): Promise<void> {
    localStorage.removeItem('dreamdrop_user');
  }

  async updateUser(updates: Partial<User>): Promise<User> {
    const currentUser = this.getCurrentUser();
    if (!currentUser) throw new Error('No user logged in');

    const updatedUser = { ...currentUser, ...updates };
    localStorage.setItem('dreamdrop_user', JSON.stringify(updatedUser));
    
    // Also update in the users storage
    const existingUsers = JSON.parse(localStorage.getItem('dreamdrop_users') || '{}');
    if (existingUsers[currentUser.email]) {
      existingUsers[currentUser.email] = { ...existingUsers[currentUser.email], ...updates };
      localStorage.setItem('dreamdrop_users', JSON.stringify(existingUsers));
    }
    
    return updatedUser;
  }
}

const authService = new SimpleAuthService();

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  useEffect(() => {
    // Check for existing user on load
    const currentUser = authService.getCurrentUser();
    dispatch({ type: 'SET_USER', payload: currentUser });
  }, []);

  const signUp = async (data: SignUpData) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      dispatch({ type: 'SET_ERROR', payload: null });

      const user = await authService.signUp(data);
      dispatch({ type: 'SET_USER', payload: user });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to create account';
      dispatch({ type: 'SET_ERROR', payload: errorMessage });
      throw error;
    }
  };

  const login = async (credentials: LoginCredentials) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      dispatch({ type: 'SET_ERROR', payload: null });

      const user = await authService.login(credentials);
      dispatch({ type: 'SET_USER', payload: user });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Invalid email or password';
      dispatch({ type: 'SET_ERROR', payload: errorMessage });
      throw error;
    }
  };

  const logout = async () => {
    try {
      await authService.logout();
      dispatch({ type: 'SET_USER', payload: null });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: (error as Error).message });
    }
  };

  const updateUser = async (updates: Partial<User>) => {
    try {
      const updatedUser = await authService.updateUser(updates);
      dispatch({ type: 'SET_USER', payload: updatedUser });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: (error as Error).message });
    }
  };

  const incrementDreamCount = async () => {
    if (!state.user) return;
    
    try {
      const newCount = state.user.dreamCount + 1;
      await updateUser({ dreamCount: newCount });
    } catch (error) {
      console.error('Increment dream count error:', error);
      throw error;
    }
  };

  const upgradeToPro = async () => {
    try {
      await updateUser({ isPro: true });
    } catch (error) {
      console.error('Upgrade to pro error:', error);
      throw error;
    }
  };

  const purchasePro = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      // Simulate purchase
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const confirmed = window.confirm(
        'Upgrade to DreamDrop Pro for unlimited dreams?\n\nThis is a demo - no actual payment will be processed.'
      );

      if (confirmed) {
        await upgradeToPro();
      } else {
        throw new Error('Purchase cancelled');
      }
      
      dispatch({ type: 'SET_LOADING', payload: false });
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: (error as Error).message });
      throw error;
    }
  };

  const canSubmitDream = (): boolean => {
    return state.user ? (state.user.isPro || state.user.dreamCount < 10) : false;
  };

  const getRemainingDreams = (): number => {
    if (!state.user) return 0;
    if (state.user.isPro) return Infinity;
    return Math.max(0, 10 - state.user.dreamCount);
  };

  const value: AuthContextType = {
    ...state,
    signUp,
    login,
    logout,
    updateUser,
    incrementDreamCount,
    upgradeToPro,
    canSubmitDream,
    getRemainingDreams,
    purchasePro
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};