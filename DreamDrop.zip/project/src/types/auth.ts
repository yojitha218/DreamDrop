export interface User {
  id: string;
  fullName: string;
  email: string;
  dateOfBirth: string;
  role: 'innovator' | 'investor';
  dreamCount: number;
  isPro: boolean;
  createdAt: string;
  avatar?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe: boolean;
}

export interface SignUpData {
  fullName: string;
  email: string;
  password: string;
  dateOfBirth: string;
  role: 'innovator' | 'investor';
  rememberMe: boolean;
}