import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import ProtectedRoute from './components/auth/ProtectedRoute';
import SignUpPage from './components/auth/SignUpPage';
import LoginPage from './components/auth/LoginPage';
import LandingPage from './components/LandingPage';
import MainApp from './components/MainApp';
import InitialWelcome from './components/InitialWelcome';

type AuthView = 'landing' | 'signup' | 'login';

function AppContent() {
  const { isAuthenticated, user } = useAuth();
  const [authView, setAuthView] = useState<AuthView>('landing');
  const [showInitialWelcome, setShowInitialWelcome] = useState(false);

  // Check if this is the first visit
  React.useEffect(() => {
    const hasVisited = localStorage.getItem('dreamdrop-visited');
    if (!hasVisited && !isAuthenticated) {
      setShowInitialWelcome(true);
      localStorage.setItem('dreamdrop-visited', 'true');
    }
  }, [isAuthenticated]);

  const handleInitialWelcomeComplete = () => {
    setShowInitialWelcome(false);
  };

  const handleRoleSelect = (role: 'innovator' | 'investor') => {
    // For demo purposes, we'll redirect to signup
    setAuthView('signup');
  };

  const handleLogout = () => {
    setAuthView('landing');
  };

  // Show initial welcome animation on first visit
  if (showInitialWelcome) {
    return <InitialWelcome onComplete={handleInitialWelcomeComplete} />;
  }

  // Show auth pages if not authenticated
  if (!isAuthenticated) {
    switch (authView) {
      case 'signup':
        return (
          <SignUpPage
            onBackToLanding={() => setAuthView('landing')}
            onSwitchToLogin={() => setAuthView('login')}
          />
        );
      case 'login':
        return (
          <LoginPage
            onBackToLanding={() => setAuthView('landing')}
            onSwitchToSignUp={() => setAuthView('signup')}
          />
        );
      default:
        return (
          <LandingPage
            onRoleSelect={handleRoleSelect}
            onSignIn={() => setAuthView('login')}
            onSignUp={() => setAuthView('signup')}
          />
        );
    }
  }

  // Show main app if authenticated
  return (
    <ProtectedRoute>
      <MainApp userRole={user?.role || 'innovator'} onLogout={handleLogout} />
    </ProtectedRoute>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;